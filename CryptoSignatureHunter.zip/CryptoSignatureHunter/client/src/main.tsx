import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add extra CSS for font families
const style = document.createElement('style');
style.textContent = `
  body {
    font-family: 'Inter', sans-serif;
    background-color: #FAFBFC;
    color: #2D2D2D;
  }
  .crypto-data {
    font-family: 'JetBrains Mono', monospace;
  }
`;
document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
