import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import InputPanel, { AnalysisParams } from '@/components/InputPanel';
import AnalysisProgressPanel, { AnalysisStep } from '@/components/AnalysisProgressPanel';
import PatternsPanel, { PatternGroup } from '@/components/PatternsPanel';
import DiscoveredKeysPanel, { DiscoveredKey } from '@/components/DiscoveredKeysPanel';
import TransactionAnalysisPanel, { Transaction } from '@/components/TransactionAnalysisPanel';
import SignatureFlowVisualization from '@/components/SignatureFlowVisualization';
import SignatureGraphVisualization from '@/components/SignatureGraphVisualization';
import SignatureHeatmapVisualization from '@/components/SignatureHeatmapVisualization';
import AnonymityScoreCard from '@/components/AnonymityScoreCard';
import SignatureRiskAssessment from '@/components/SignatureRiskAssessment';
import SignatureClusterAnalysis from '@/components/SignatureClusterAnalysis';
import AdaptiveLearningPanel from '@/components/AdaptiveLearningPanel';
import { useToast } from '@/hooks/use-toast';
import { formatTimeAgo } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Home: React.FC = () => {
  const { toast } = useToast();
  const [analysisRunning, setAnalysisRunning] = useState(false);
  const [analysisId, setAnalysisId] = useState<string | null>(null);
  const [steps, setSteps] = useState<AnalysisStep[]>([
    { id: '1', name: 'Transaction data parsing', status: 'waiting', details: 'Waiting to start...' },
    { id: '2', name: 'Pattern recognition', status: 'waiting', details: 'Waiting for data parsing...' },
    { id: '3', name: 'Nonce reconstruction', status: 'waiting', details: 'Waiting for pattern recognition...' },
    { id: '4', name: 'Private key derivation', status: 'waiting', details: 'Waiting for nonce reconstruction...' }
  ]);
  const [overallProgress, setOverallProgress] = useState(0);
  const [currentStatus, setCurrentStatus] = useState('Ready to analyze');
  const [transactionPage, setTransactionPage] = useState(1);
  const [transactionFilter, setTransactionFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Query for analysis status
  const { data: analysisData, refetch: refetchAnalysis } = useQuery<{
    progress: number;
    status: string;
    completed: boolean;
    error?: boolean;
    keysFound?: number;
    steps: Array<{
      id: string;
      status: 'completed' | 'in-progress' | 'waiting';
      name: string;
      details: string;
    }>;
  }>({
    queryKey: ['/api/analysis/status', analysisId],
    enabled: !!analysisId && analysisRunning,
    refetchInterval: analysisRunning ? 2000 : false,
  });

  // Query for patterns
  const { data: patternsData, refetch: refetchPatterns } = useQuery<{
    patterns: Array<{
      id: string;
      name: string;
      confidence: number;
      transactionCount: number;
      characteristics: string;
      affectedAddresses: string[];
      discoveredAt: string;
      nonceReconstructed?: boolean;
      nonceValue?: string | null;
      partialNonce?: string | null;
      bruteForcedNonces?: string[] | null;
      reconstructionProgress?: number;
      bruteForcingProgress?: number;
    }>;
  }>({
    queryKey: ['/api/patterns'],
  });

  // Query for discovered keys
  const { data: keysData, refetch: refetchKeys } = useQuery<{
    keys: Array<{
      id: string;
      privateKey: string;
      address: string;
      verification: string;
      discoveredAt: string;
      patternId: string;
    }>;
  }>({
    queryKey: ['/api/keys'],
  });

  // Query for transactions
  const { data: transactionsData, refetch: refetchTransactions } = useQuery<{
    transactions: Array<{
      id: string;
      txid: string;
      address: string;
      patternId: string | null;
      patternName: string | null;
      confidence: number;
      status: string;
    }>;
    total: number;
  }>({
    queryKey: ['/api/transactions', transactionPage, transactionFilter, searchTerm],
  });

  // Update UI based on analysis status
  useEffect(() => {
    if (analysisData) {
      setOverallProgress(analysisData.progress);
      setCurrentStatus(analysisData.status);
      
      const updatedSteps = [...steps];
      
      // Update steps based on analysis data
      if (analysisData.steps) {
        analysisData.steps.forEach((stepData: any) => {
          const stepIndex = updatedSteps.findIndex(s => s.id === stepData.id);
          if (stepIndex !== -1) {
            updatedSteps[stepIndex] = {
              ...updatedSteps[stepIndex],
              status: stepData.status,
              details: stepData.details
            };
          }
        });
      }
      
      setSteps(updatedSteps);
      
      if (analysisData.completed) {
        setAnalysisRunning(false);
        toast({
          title: "Analysis Complete",
          description: `Analysis completed with ${analysisData.keysFound || 0} keys found`,
        });
        
        // Refresh data
        refetchPatterns();
        refetchKeys();
        refetchTransactions();
      }
    }
  }, [analysisData]);

  // Start analysis mutation
  const startAnalysisMutation = useMutation({
    mutationFn: async (params: AnalysisParams) => {
      const formData = new FormData();
      formData.append('address', params.address);
      formData.append('speedLevel', params.speedLevel.toString());
      formData.append('usePartialNonce', params.usePartialNonce.toString());
      formData.append('usePatternRecognition', params.usePatternRecognition.toString());
      formData.append('useAI', params.useAI.toString());
      formData.append('patternDepth', params.patternDepth.toString());
      
      params.files.forEach(file => {
        formData.append('files', file);
      });
      
      const response = await fetch('/api/analysis/start', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || response.statusText);
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      setAnalysisId(data.analysisId);
      setAnalysisRunning(true);
      toast({
        title: "Analysis Started",
        description: "Processing your data...",
      });
      
      // Reset steps for new analysis
      setSteps([
        { id: '1', name: 'Transaction data parsing', status: 'in-progress', details: 'Processing files...' },
        { id: '2', name: 'Pattern recognition', status: 'waiting', details: 'Waiting for data parsing...' },
        { id: '3', name: 'Nonce reconstruction', status: 'waiting', details: 'Waiting for pattern recognition...' },
        { id: '4', name: 'Private key derivation', status: 'waiting', details: 'Waiting for nonce reconstruction...' }
      ]);
    },
    onError: (error) => {
      toast({
        title: "Error Starting Analysis",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    }
  });

  // Exploit pattern mutation
  const exploitPatternMutation = useMutation({
    mutationFn: async (patternId: string) => {
      const response = await apiRequest('POST', '/api/patterns/exploit', { patternId });
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Pattern Exploitation Started",
        description: `Attempting to derive keys from pattern`,
      });
      refetchKeys();
    },
    onError: (error) => {
      toast({
        title: "Error Exploiting Pattern",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    }
  });

  // Export key function
  const exportKey = (key: DiscoveredKey) => {
    const keyData = JSON.stringify({
      privateKey: key.privateKey,
      address: key.address,
      discoveredAt: new Date().toISOString(),
      verification: key.verification
    }, null, 2);
    
    const blob = new Blob([keyData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `key-${key.address.substring(0, 8)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Key Exported",
      description: "Private key exported as JSON",
    });
  };

  // Handle analysis start
  const handleStartAnalysis = (params: AnalysisParams) => {
    startAnalysisMutation.mutate(params);
  };

  // Handle pattern exploitation
  const handleExploitPattern = (patternId: string) => {
    exploitPatternMutation.mutate(patternId);
  };
  
  // Handle view nonce details
  const handleViewNonceDetails = (patternId: string) => {
    const pattern = patterns.find(p => p.id === patternId);
    if (!pattern) return;
    
    // Create a formatted summary of nonce information
    const nonceDetails = [
      `Pattern: ${pattern.name}`,
      `Confidence: ${pattern.confidence}%`,
      pattern.nonceReconstructed ? 'Status: Nonce successfully reconstructed' : 'Status: Reconstruction in progress',
      pattern.nonceValue ? `Reconstructed Nonce: ${pattern.nonceValue}` : '',
      pattern.partialNonce ? `Partial Nonce: ${pattern.partialNonce}` : '',
      pattern.bruteForcedNonces && pattern.bruteForcedNonces.length > 0 ? 
        `Brute Force Candidates (${pattern.bruteForcedNonces.length}): \n${pattern.bruteForcedNonces.join('\n')}` : ''
    ].filter(Boolean).join('\n\n');
    
    toast({
      title: "Nonce Details",
      description: nonceDetails.length > 100 ? 
        nonceDetails.substring(0, 100) + '...\n(See details in expanded pattern view)' : 
        nonceDetails,
      duration: 10000,
    });
  };
  
  // Handle save nonce information
  const handleSaveNonceInfo = (patternId: string) => {
    const pattern = patterns.find(p => p.id === patternId);
    if (!pattern) return;
    
    // Create a JSON object with all nonce information
    const nonceData = {
      patternId: pattern.id,
      patternName: pattern.name,
      confidence: pattern.confidence,
      nonceReconstructed: pattern.nonceReconstructed,
      nonceValue: pattern.nonceValue,
      partialNonce: pattern.partialNonce,
      bruteForcedNonces: pattern.bruteForcedNonces,
      exportedAt: new Date().toISOString()
    };
    
    // Convert to JSON and save as file
    const blob = new Blob([JSON.stringify(nonceData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nonce-data-${pattern.id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Nonce Data Saved",
      description: "Nonce information exported as JSON file",
    });
  };

  // Format pattern data
  const formatPatterns = (): PatternGroup[] => {
    if (!patternsData?.patterns) return [];
    
    return patternsData.patterns.map((p: any) => ({
      id: p.id,
      name: p.name,
      confidence: p.confidence,
      transactionCount: p.transactionCount,
      characteristics: p.characteristics,
      affectedAddresses: p.affectedAddresses || [],
      discoveryTime: formatTimeAgo(p.discoveredAt),
      nonceReconstructed: p.nonceReconstructed,
      nonceValue: p.nonceValue,
      partialNonce: p.partialNonce,
      bruteForcedNonces: p.bruteForcedNonces,
      reconstructionProgress: p.reconstructionProgress,
      bruteForcingProgress: p.bruteForcingProgress
    }));
  };

  // Format keys data
  const formatKeys = (): DiscoveredKey[] => {
    if (!keysData?.keys) return [];
    
    return keysData.keys.map((k: any) => ({
      id: k.id,
      privateKey: k.privateKey,
      address: k.address,
      verification: k.verification,
      discoveryTime: formatTimeAgo(k.discoveredAt),
      patternId: k.patternId
    }));
  };

  // Format transactions data
  const formatTransactions = (): { transactions: Transaction[], total: number } => {
    if (!transactionsData) return { transactions: [], total: 0 };
    
    const transactions = transactionsData.transactions.map((t: any) => ({
      id: t.id,
      txid: t.txid,
      address: t.address,
      patternId: t.patternId,
      patternName: t.patternName,
      confidence: t.confidence,
      status: t.status
    }));
    
    return { 
      transactions, 
      total: transactionsData.total || transactions.length 
    };
  };

  const patterns = formatPatterns();
  const keys = formatKeys();
  const { transactions, total: totalTransactions } = formatTransactions();

  // Handler for training completion in adaptive learning
  const handleTrainingComplete = (improvements: Array<{
    patternId: string;
    oldConfidence: number;
    newConfidence: number;
  }>) => {
    // Update pattern confidences (in a real app, this would call an API)
    toast({
      title: "Training Applied",
      description: `Updated confidence scores for ${improvements.length} patterns`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div>
          <InputPanel 
            onStartAnalysis={handleStartAnalysis} 
            isAnalysisRunning={analysisRunning}
          />
          
          <AnonymityScoreCard 
            address={transactions.length > 0 ? transactions[0].address : undefined}
            transactions={transactions.map(tx => ({
              txid: tx.txid,
              patternId: tx.patternId
            }))}
            patterns={patterns.map(p => ({
              id: p.id,
              confidence: p.confidence,
              transactionCount: p.transactionCount
            }))}
          />
          
          <AdaptiveLearningPanel 
            patterns={patterns.map(p => ({
              id: p.id,
              name: p.name,
              confidence: p.confidence,
              nonceReconstructed: p.nonceReconstructed
            }))}
            keys={keys.map(k => ({
              id: k.id,
              verification: k.verification,
              patternId: k.patternId
            }))}
            onTrainingComplete={handleTrainingComplete}
          />
        </div>
        
        <div className="lg:col-span-2">
          <AnalysisProgressPanel 
            overallProgress={overallProgress} 
            status={currentStatus} 
            steps={steps} 
          />
          
          <Tabs defaultValue="basic" className="mb-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">Basic Flow</TabsTrigger>
              <TabsTrigger value="advanced">Advanced Graph</TabsTrigger>
              <TabsTrigger value="heatmap">Byte Heatmap</TabsTrigger>
            </TabsList>
            
            <TabsContent value="basic">
              <SignatureFlowVisualization 
                transactions={transactions.map(tx => ({
                  id: tx.id,
                  txid: tx.txid,
                  address: tx.address,
                  patternId: tx.patternId,
                  confidence: tx.confidence
                }))}
                patterns={patterns.map(p => ({
                  id: p.id,
                  name: p.name,
                  confidence: p.confidence,
                  affectedAddresses: p.affectedAddresses,
                  nonceReconstructed: p.nonceReconstructed,
                  nonceValue: p.nonceValue
                }))}
              />
            </TabsContent>
            
            <TabsContent value="advanced">
              <SignatureGraphVisualization 
                transactions={transactions.map(tx => ({
                  id: tx.id,
                  txid: tx.txid,
                  address: tx.address,
                  patternId: tx.patternId,
                  confidence: tx.confidence
                }))}
                patterns={patterns.map(p => ({
                  id: p.id,
                  name: p.name,
                  confidence: p.confidence,
                  affectedAddresses: p.affectedAddresses,
                  nonceReconstructed: p.nonceReconstructed,
                  nonceValue: p.nonceValue
                }))}
              />
            </TabsContent>
            
            <TabsContent value="heatmap">
              <SignatureHeatmapVisualization 
                transactions={transactions.map(tx => ({
                  id: tx.id,
                  txid: tx.txid,
                  address: tx.address,
                  patternId: tx.patternId
                }))}
              />
            </TabsContent>
          </Tabs>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <SignatureRiskAssessment 
              patterns={patterns.map(p => ({
                id: p.id,
                name: p.name,
                confidence: p.confidence,
                transactionCount: p.transactionCount,
                characteristics: p.characteristics
              }))}
            />
            
            <SignatureClusterAnalysis 
              patterns={patterns.map(p => ({
                id: p.id,
                name: p.name,
                confidence: p.confidence,
                affectedAddresses: p.affectedAddresses,
                transactionCount: p.transactionCount,
                nonceReconstructed: p.nonceReconstructed
              }))}
              transactions={transactions.map(tx => ({
                id: tx.id,
                txid: tx.txid,
                address: tx.address,
                patternId: tx.patternId
              }))}
            />
          </div>
          
          <PatternsPanel 
            patterns={patterns} 
            onExploitPattern={handleExploitPattern}
            onViewNonceDetails={handleViewNonceDetails}
            onSaveNonceInfo={handleSaveNonceInfo}
          />
          
          <DiscoveredKeysPanel 
            keys={keys} 
            onExport={exportKey} 
          />
          
          <TransactionAnalysisPanel 
            transactions={transactions}
            totalTransactions={totalTransactions}
            currentPage={transactionPage}
            pageSize={10}
            onPageChange={setTransactionPage}
            onSearch={setSearchTerm}
            onFilterChange={setTransactionFilter}
          />
        </div>
      </div>
    </div>
  );
};

export default Home;
