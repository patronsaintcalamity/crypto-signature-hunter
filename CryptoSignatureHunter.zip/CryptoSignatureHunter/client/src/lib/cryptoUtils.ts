/**
 * Utility functions for cryptographic operations on the client side
 */

// Validates a Bitcoin address format
export function isValidBitcoinAddress(address: string): boolean {
  // Basic validation for Bitcoin addresses (P2PKH, P2SH, Bech32)
  const p2pkhRegex = /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/;
  const p2shRegex = /^3[a-km-zA-HJ-NP-Z1-9]{25,34}$/;
  const bech32Regex = /^(bc1)[a-zA-HJ-NP-Z0-9]{6,}$/;
  
  return p2pkhRegex.test(address) || p2shRegex.test(address) || bech32Regex.test(address);
}

// Validates a WIF private key format
export function isValidPrivateKey(key: string): boolean {
  // Validate a WIF private key format
  const wifRegex = /^[KL5][1-9A-HJ-NP-Za-km-z]{50,51}$/;
  return wifRegex.test(key);
}

// Decode a transaction signature for verification
export function parseSignature(sigHex: string): { r: string, s: string } {
  try {
    // Basic DER signature parsing (simplified)
    // In a real implementation, this would have proper DER decoding
    // This is just a placeholder for the UI
    
    // Skip first byte (0x30) and length byte
    const rLength = parseInt(sigHex.slice(6, 8), 16) * 2;
    const r = sigHex.slice(8, 8 + rLength);
    
    // Skip s type byte (0x02)
    const sStart = 10 + rLength;
    const sLength = parseInt(sigHex.slice(sStart, sStart + 2), 16) * 2;
    const s = sigHex.slice(sStart + 2, sStart + 2 + sLength);
    
    return { r, s };
  } catch (e) {
    console.error("Error parsing signature", e);
    return { r: "", s: "" };
  }
}

// Calculate a confidence score based on pattern matching
export function calculateConfidenceScore(
  matchLength: number, 
  patternFrequency: number, 
  totalSamples: number
): number {
  // Simple confidence calculation
  // Real implementation would be more sophisticated
  
  const baseConfidence = (matchLength / 8) * 50; // Length of match contributes 50% max
  const frequencyFactor = patternFrequency / totalSamples;
  const frequencyConfidence = frequencyFactor * 50; // Frequency contributes 50% max
  
  return Math.min(Math.round(baseConfidence + frequencyConfidence), 100);
}

// Parse signature data from CSV format
export function parseCSVSignatures(csvText: string): Array<{r: string, s: string, z: string, pubkey: string}> {
  const lines = csvText.trim().split('\n');
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  
  const rIndex = headers.indexOf('r');
  const sIndex = headers.indexOf('s');
  const zIndex = headers.indexOf('z');
  const pubkeyIndex = headers.indexOf('pubkey');
  
  if (rIndex === -1 || sIndex === -1 || zIndex === -1 || pubkeyIndex === -1) {
    throw new Error("CSV file missing required columns: r, s, z, pubkey");
  }
  
  return lines.slice(1).map(line => {
    const fields = line.split(',').map(f => f.trim());
    return {
      r: fields[rIndex],
      s: fields[sIndex],
      z: fields[zIndex],
      pubkey: fields[pubkeyIndex]
    };
  });
}

// Mock function for detecting reused nonces (client-side preview only)
export function detectReusedNonce(
  signatures: Array<{r: string, s: string, z: string, pubkey: string}>
): boolean {
  // In a real implementation, this would check for identical r-values
  // across different signatures (which indicates reused nonces)
  
  const rValues = new Set();
  
  for (const sig of signatures) {
    if (rValues.has(sig.r)) {
      return true; // Found a reused nonce
    }
    rValues.add(sig.r);
  }
  
  return false;
}
