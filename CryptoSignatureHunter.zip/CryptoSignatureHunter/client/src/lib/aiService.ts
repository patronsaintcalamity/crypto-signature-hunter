import { apiRequest } from "./queryClient";
import { useQuery } from "@tanstack/react-query";

// Interface for AI service status
interface AIServiceStatus {
  available: boolean;
  message: string;
}

/**
 * Custom hook to check if AI services are available
 * @returns Query result with AI service availability status
 */
export function useAIServiceStatus() {
  return useQuery({
    queryKey: ['/api/ai/status'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/ai/status');
      const data = await response.json() as AIServiceStatus;
      return data;
    },
    // Cache the result for 5 minutes - we don't expect this to change often during a session
    staleTime: 5 * 60 * 1000,
    retry: 1, // Only retry once to avoid excessive API calls
  });
}

/**
 * Helper function to check AI availability that returns a boolean with a default value
 * Useful for conditional rendering in components
 * 
 * @param isAvailable Default value if the query is loading
 * @returns Boolean indicating if AI is available
 */
export function useIsAIAvailable(isAvailable = false) {
  const { data, isLoading } = useAIServiceStatus();
  
  if (isLoading) {
    return isAvailable;
  }
  
  return data?.available ?? isAvailable;
}