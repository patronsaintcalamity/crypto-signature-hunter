import React, { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Network, RefreshCw, DatabaseIcon, Link2, Unlink,
  Share2, LayoutGrid, Hash, Key, Fingerprint, AlertCircle
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';

interface SignatureClusterAnalysisProps {
  patterns: Array<{
    id: string;
    name: string;
    confidence: number;
    affectedAddresses: string[];
    transactionCount: number;
    nonceReconstructed?: boolean;
    nonceValue?: string;
    metadata?: {
      reusedNonce?: string;
      signatures?: Array<{ r: string; s: string; z?: string; pubkey?: string }>;
    };
  }>;
  transactions: Array<{
    id: string;
    txid: string;
    address: string;
    patternId?: string | null;
    r?: string;
    s?: string;
  }>;
}

interface AddressCluster {
  id: string;
  addresses: string[];
  correlationStrength: number;
  signatureSimilarities: Array<{
    component: 'r' | 's' | 'z';
    similarity: number;
    description: string;
  }>;
  transactionCount: number;
  patternIds: string[];
}

// Custom node component for patterns
const PatternNode = ({ data }: { data: any }) => (
  <div className={`px-3 py-2 rounded-lg shadow-md w-[180px] border ${
    data.confidence >= 90 ? 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800' :
    data.confidence >= 50 ? 'bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20 dark:border-yellow-800' :
    'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800'
  }`}>
    <div className="flex items-center justify-between mb-1">
      <div className="font-medium text-sm truncate">{data.label}</div>
      <Badge className={
        data.confidence >= 90 ? 'bg-red-500' :
        data.confidence >= 50 ? 'bg-yellow-500' :
        'bg-green-500'
      }>
        {data.confidence}%
      </Badge>
    </div>
    <div className="flex items-center justify-between text-xs text-gray-500">
      <span>Txs: {data.transactionCount}</span>
      <span>{data.nonceReconstructed ? '🔓 Exposed' : '🔒 Secure'}</span>
    </div>
  </div>
);

// Custom node component for addresses
const AddressNode = ({ data }: { data: any }) => (
  <div className="px-3 py-2 rounded-lg shadow-md border bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800 w-[180px]">
    <div className="flex items-center mb-1">
      <Fingerprint className="h-3 w-3 mr-1 text-blue-600" />
      <div className="font-medium text-sm truncate">{data.label}</div>
    </div>
    <div className="text-xs text-gray-500">
      Txs: {data.transactionCount}
    </div>
  </div>
);

// Custom node component for transactions
const TransactionNode = ({ data }: { data: any }) => (
  <div className="px-3 py-2 rounded-lg shadow-md border bg-purple-50 border-purple-200 dark:bg-purple-900/20 dark:border-purple-800 w-[180px]">
    <div className="flex items-center mb-1">
      <Hash className="h-3 w-3 mr-1 text-purple-600" />
      <div className="font-medium text-sm truncate">{data.label}</div>
    </div>
    <div className="text-xs text-gray-500 truncate">
      {data.r ? `R: ${data.r.substring(0, 8)}...` : 'No signature data'}
    </div>
  </div>
);

// Cluster component for correlated addresses
const ClusterNode = ({ cluster, onClick }: { 
  cluster: AddressCluster, 
  onClick: () => void 
}) => {
  // Determine color based on correlation strength
  const getColorClass = (strength: number) => {
    if (strength >= 0.8) return 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800';
    if (strength >= 0.5) return 'bg-orange-50 border-orange-200 dark:bg-orange-900/20 dark:border-orange-800';
    if (strength >= 0.3) return 'bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20 dark:border-yellow-800';
    return 'bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800';
  };

  // Format correlation strength as percentage
  const correlationPercent = Math.round(cluster.correlationStrength * 100);

  return (
    <div 
      className={`p-4 rounded-lg shadow-md border mb-4 cursor-pointer ${getColorClass(cluster.correlationStrength)}`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium flex items-center">
          <Link2 className="h-4 w-4 mr-1" />
          Correlated Addresses
        </h3>
        <Badge className={
          correlationPercent >= 80 ? 'bg-red-500' :
          correlationPercent >= 50 ? 'bg-orange-500' :
          correlationPercent >= 30 ? 'bg-yellow-500' :
          'bg-blue-500'
        }>
          {correlationPercent}% Correlation
        </Badge>
      </div>

      <div className="mb-3">
        {cluster.addresses.map((address, i) => (
          <div key={i} className="text-xs rounded bg-black/10 dark:bg-white/10 px-2 py-1 mb-1 font-mono">
            {address.substring(0, 10)}...{address.substring(address.length - 6)}
          </div>
        ))}
      </div>

      <div className="border-t border-gray-200 dark:border-gray-700 pt-2">
        <h4 className="text-xs font-medium mb-1">Signature Similarities:</h4>
        {cluster.signatureSimilarities
          .filter(sim => sim.similarity > 0.1)
          .sort((a, b) => b.similarity - a.similarity)
          .map((sim, i) => (
            <div key={i} className="flex items-center justify-between text-xs mb-1">
              <span className="text-gray-600 dark:text-gray-300">
                {sim.component.toUpperCase()} Values:
              </span>
              <Badge variant="outline" className={
                sim.similarity >= 0.8 ? 'text-red-600 border-red-200 dark:text-red-400 dark:border-red-800' :
                sim.similarity >= 0.5 ? 'text-orange-600 border-orange-200 dark:text-orange-400 dark:border-orange-800' :
                sim.similarity >= 0.3 ? 'text-yellow-600 border-yellow-200 dark:text-yellow-400 dark:border-yellow-800' :
                'text-blue-600 border-blue-200 dark:text-blue-400 dark:border-blue-800'
              }>
                {Math.round(sim.similarity * 100)}%
              </Badge>
            </div>
          ))}
      </div>
    </div>
  );
};

interface ClusterNode {
  id: string;
  type: 'pattern' | 'address' | 'transaction';
  label: string;
  data: {
    confidence?: number;
    transactionCount?: number;
    nonceReconstructed?: boolean;
    fullAddress?: string;
    r?: string;
    s?: string;
  };
}

const SignatureClusterAnalysis: React.FC<SignatureClusterAnalysisProps> = ({
  patterns,
  transactions
}) => {
  const { toast } = useToast();
  const [viewType, setViewType] = useState<'all' | 'patterns' | 'addresses' | 'clusters'>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [clusterNodes, setClusterNodes] = useState<ClusterNode[]>([]);
  const [selectedCluster, setSelectedCluster] = useState<AddressCluster | null>(null);

  // Fetch address clusters from API
  const { data: clustersData, isLoading: isClustersLoading } = useQuery({ 
    queryKey: ['/api/clusters'],
    enabled: transactions.length > 0 // Only fetch if we have transactions
  });

  // Extract clusters data
  const clusters: AddressCluster[] = clustersData?.clusters || [];

  // Generate graph data from patterns and transactions
  useEffect(() => {
    if (patterns.length === 0 && transactions.length === 0) return;
    if (viewType === 'clusters') return; // Don't generate nodes for cluster view

    setIsLoading(true);

    // Process after a small delay to allow loading state to render
    setTimeout(() => {
      const nodes: ClusterNode[] = [];

      // Generate nodes based on view type
      if (viewType === 'all' || viewType === 'patterns') {
        // Add pattern nodes
        patterns.forEach((pattern) => {
          nodes.push({
            id: `pattern-${pattern.id}`,
            type: 'pattern',
            label: pattern.name,
            data: {
              confidence: pattern.confidence,
              transactionCount: pattern.transactionCount,
              nonceReconstructed: pattern.nonceReconstructed
            }
          });
        });
      }

      if (viewType === 'all' || viewType === 'addresses') {
        // Get unique addresses
        const uniqueAddresses = [...new Set(transactions.map(tx => tx.address))];

        // Add address nodes
        uniqueAddresses.forEach((address) => {
          // Count transactions for this address
          const addressTxs = transactions.filter(tx => tx.address === address).length;

          nodes.push({
            id: `address-${address}`,
            type: 'address',
            label: `${address.substring(0, 6)}...${address.substring(address.length - 4)}`,
            data: {
              fullAddress: address,
              transactionCount: addressTxs
            }
          });
        });
      }

      if (viewType === 'all') {
        // Add selected transaction nodes (limit to first 10 for performance)
        const limitedTransactions = transactions.slice(0, 10);
        limitedTransactions.forEach((tx) => {
          nodes.push({
            id: `tx-${tx.id}`,
            type: 'transaction',
            label: `TX: ${tx.txid.substring(0, 8)}...`,
            data: {
              r: tx.r,
              s: tx.s
            }
          });
        });
      }

      setClusterNodes(nodes);
      setIsLoading(false);
    }, 500);

  }, [patterns, transactions, viewType]);

  const handleNodeClick = (node: ClusterNode) => {
    // Extract node data for the toast
    const nodeData = node.data;
    const nodeType = node.type;

    let detailMessage = '';

    if (nodeType === 'pattern') {
      detailMessage = `Confidence: ${nodeData.confidence}%\nTransactions: ${nodeData.transactionCount}\nStatus: ${nodeData.nonceReconstructed ? 'Nonce Reconstructed' : 'Secure'}`;
    } else if (nodeType === 'address') {
      detailMessage = `Transactions: ${nodeData.transactionCount}\nFull Address: ${nodeData.fullAddress}`;
    } else if (nodeType === 'transaction') {
      detailMessage = `${nodeData.r ? `R: ${nodeData.r.substring(0, 10)}...\n` : ''}${nodeData.s ? `S: ${nodeData.s.substring(0, 10)}...` : ''}`;
    }

    toast({
      title: node.label,
      description: detailMessage,
      duration: 5000
    });
  };

  const handleClusterClick = (cluster: AddressCluster) => {
    // Toggle selected cluster
    setSelectedCluster(selectedCluster?.id === cluster.id ? null : cluster);
  };

  // Render a node
  const renderClusterNode = (node: ClusterNode) => {
    let nodeClass = 'p-3 rounded-lg shadow-md mb-2 border cursor-pointer ';
    let color = '';

    if (node.type === 'pattern') {
      const confidence = node.data.confidence || 0;
      if (confidence >= 90) {
        nodeClass += 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800';
        color = 'text-red-700 dark:text-red-300';
      } else if (confidence >= 50) {
        nodeClass += 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800';
        color = 'text-yellow-700 dark:text-yellow-300';
      } else {
        nodeClass += 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800';
        color = 'text-green-700 dark:text-green-300';
      }
    } else if (node.type === 'address') {
      nodeClass += 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800';
      color = 'text-blue-700 dark:text-blue-300';
    } else {
      nodeClass += 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800';
      color = 'text-purple-700 dark:text-purple-300';
    }

    const icon = 
      node.type === 'pattern' ? <Share2 className={`h-4 w-4 ${color}`} /> :
      node.type === 'address' ? <Fingerprint className={`h-4 w-4 ${color}`} /> :
      <Hash className={`h-4 w-4 ${color}`} />;

    return (
      <div 
        key={node.id}
        className={nodeClass}
        onClick={() => handleNodeClick(node)}
      >
        <div className="flex items-center gap-2">
          {icon}
          <span className="font-medium text-sm">{node.label}</span>
          {node.type === 'pattern' && (
            <Badge className={
              (node.data.confidence || 0) >= 90 ? 'bg-red-500 ml-auto' :
              (node.data.confidence || 0) >= 50 ? 'bg-yellow-500 ml-auto' :
              'bg-green-500 ml-auto'
            }>
              {node.data.confidence}%
            </Badge>
          )}
        </div>
        {node.type === 'pattern' && (
          <div className="flex justify-between mt-1 text-xs text-gray-500">
            <span>Txs: {node.data.transactionCount}</span>
            <span>{node.data.nonceReconstructed ? '🔓 Exposed' : '🔒 Secure'}</span>
          </div>
        )}
        {node.type === 'address' && (
          <div className="mt-1 text-xs text-gray-500">
            Transactions: {node.data.transactionCount}
          </div>
        )}
      </div>
    );
  };

  // Render the content based on view type
  const renderContent = () => {
    if (isLoading || isClustersLoading) {
      return (
        <div className="absolute inset-0 flex items-center justify-center bg-white/80 dark:bg-gray-800/80 z-10">
          <div className="flex flex-col items-center">
            <RefreshCw className="h-8 w-8 text-primary animate-spin mb-2" />
            <p className="text-sm font-medium">Generating Cluster Analysis...</p>
          </div>
        </div>
      );
    }

    if (viewType === 'clusters') {
      if (clusters.length === 0) {
        return (
          <div className="flex flex-col items-center justify-center h-full">
            <Unlink className="h-16 w-16 text-gray-300 mb-4" />
            <p className="text-gray-500 text-center">
              No address correlations detected.
              <br />
              Upload more signature data to identify potential correlations.
            </p>
          </div>
        );
      }

      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Address Clusters */}
          <div>
            <h3 className="font-medium text-sm mb-3 text-gray-500">
              Address Correlations ({clusters.length})
            </h3>
            {clusters.map(cluster => (
              <ClusterNode 
                key={cluster.id} 
                cluster={cluster}
                onClick={() => handleClusterClick(cluster)}
              />
            ))}
          </div>

          {/* Selected Cluster Details */}
          <div>
            {selectedCluster ? (
              <div className="p-4 rounded-lg border bg-gray-50 dark:bg-gray-800/50">
                <h3 className="font-medium text-sm mb-4 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-2 text-red-500" />
                  Potential Security Risk
                </h3>

                <p className="text-sm mb-4">
                  {Math.round(selectedCluster.correlationStrength * 100)}% correlation detected between 
                  {selectedCluster.addresses.length} addresses. This could indicate the following:
                </p>

                <ul className="list-disc pl-5 text-sm mb-4 space-y-2">
                  <li>Potential key reuse across multiple addresses</li>
                  <li>Cryptographic weakness in signature generation</li>
                  <li>Deterministic nonce patterns across signatures</li>
                  <li>Shared private key access across multiple addresses</li>
                </ul>

                <div className="border-t border-gray-200 dark:border-gray-700 pt-3 mt-3">
                  <h4 className="text-xs font-medium mb-2">Signature Components Analysis:</h4>
                  {selectedCluster.signatureSimilarities.map((sim, i) => (
                    <div key={i} className="mb-2">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-medium">{sim.component.toUpperCase()} Component:</span>
                        <Badge variant="outline" className={
                          sim.similarity >= 0.8 ? 'text-red-600 dark:text-red-400' :
                          sim.similarity >= 0.5 ? 'text-orange-600 dark:text-orange-400' :
                          'text-blue-600 dark:text-blue-400'
                        }>
                          {Math.round(sim.similarity * 100)}%
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-500">{sim.description}</p>
                    </div>
                  ))}
                </div>

                {selectedCluster.patternIds.length > 0 && (
                  <div className="border-t border-gray-200 dark:border-gray-700 pt-3 mt-3">
                    <h4 className="text-xs font-medium mb-2">Related Patterns:</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedCluster.patternIds.map(patternId => {
                        const pattern = patterns.find(p => p.id === patternId);
                        return pattern ? (
                          <Badge key={patternId} className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                            {pattern.name}
                          </Badge>
                        ) : null;
                      })}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full bg-gray-50 dark:bg-gray-800/50 rounded-lg border p-4">
                <p className="text-gray-500 text-center text-sm">
                  Select a correlation group to view detailed analysis.
                </p>
              </div>
            )}
          </div>
        </div>
      );
    }

    if (clusterNodes.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center h-full">
          <DatabaseIcon className="h-16 w-16 text-gray-300 mb-4" />
          <p className="text-gray-500 text-center">
            No data available for cluster analysis.
            <br />
            Start an analysis to identify signature patterns and relationships.
          </p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <h3 className="font-medium text-sm mb-3 text-gray-500">Patterns ({
            clusterNodes.filter(n => n.type === 'pattern').length
          })</h3>
          {clusterNodes
            .filter(node => node.type === 'pattern')
            .map(renderClusterNode)}
        </div>

        <div>
          <h3 className="font-medium text-sm mb-3 text-gray-500">Addresses ({
            clusterNodes.filter(n => n.type === 'address').length
          })</h3>
          {clusterNodes
            .filter(node => node.type === 'address')
            .map(renderClusterNode)}
        </div>

        <div>
          <h3 className="font-medium text-sm mb-3 text-gray-500">Transactions ({
            clusterNodes.filter(n => n.type === 'transaction').length
          })</h3>
          {clusterNodes
            .filter(node => node.type === 'transaction')
            .map(renderClusterNode)}
        </div>
      </div>
    );
  };

  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold flex items-center">
          <Network className="h-5 w-5 mr-2" />
          Signature Cluster Analysis
        </h2>

        <div className="flex space-x-2">
          <Button
            variant={viewType === 'all' ? 'secondary' : 'outline'}
            size="sm"
            className={viewType === 'all' ? 'bg-white/20 text-white' : 'bg-transparent text-white border-white/20'}
            onClick={() => setViewType('all')}
          >
            <LayoutGrid className="h-4 w-4 mr-1" />
            All
          </Button>
          <Button
            variant={viewType === 'patterns' ? 'secondary' : 'outline'}
            size="sm"
            className={viewType === 'patterns' ? 'bg-white/20 text-white' : 'bg-transparent text-white border-white/20'}
            onClick={() => setViewType('patterns')}
          >
            <Share2 className="h-4 w-4 mr-1" />
            Patterns
          </Button>
          <Button
            variant={viewType === 'addresses' ? 'secondary' : 'outline'}
            size="sm"
            className={viewType === 'addresses' ? 'bg-white/20 text-white' : 'bg-transparent text-white border-white/20'}
            onClick={() => setViewType('addresses')}
          >
            <Key className="h-4 w-4 mr-1" />
            Addresses
          </Button>
          <Button
            variant={viewType === 'clusters' ? 'secondary' : 'outline'}
            size="sm"
            className={viewType === 'clusters' ? 'bg-white/20 text-white' : 'bg-transparent text-white border-white/20'}
            onClick={() => setViewType('clusters')}
          >
            <Link2 className="h-4 w-4 mr-1" />
            Correlations
          </Button>
        </div>
      </div>

      <div className="h-[400px] relative overflow-auto p-4">
        {renderContent()}
      </div>

      <div className="px-6 py-3 bg-gray-50 dark:bg-gray-800 border-t">
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
            <span className="text-xs">High Risk</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
            <span className="text-xs">Medium Risk</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
            <span className="text-xs">Low Risk</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-blue-500 mr-1"></div>
            <span className="text-xs">Address</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-orange-500 mr-1"></div>
            <span className="text-xs">Correlation</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default SignatureClusterAnalysis;