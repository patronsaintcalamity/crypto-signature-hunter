import React from 'react';
import { LockKeyhole, Info, Zap, AlertTriangle } from 'lucide-react';
import { Link } from 'wouter';
import { useAIServiceStatus } from '@/lib/aiService';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const Header: React.FC = () => {
  const { data: aiStatus, isLoading: aiStatusLoading } = useAIServiceStatus();
  
  return (
    <header className="bg-primary text-white py-4 px-6 shadow-md">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <Link href="/" className="flex items-center">
              <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center mr-3">
                <LockKeyhole className="h-6 w-6" />
              </div>
              <h1 className="text-xl font-bold">Crypto Signature Analyzer</h1>
          </Link>
        </div>
        <div className="flex items-center space-x-4">
          {/* AI Status Indicator */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center mr-2">
                  {!aiStatusLoading && (
                    <>
                      {aiStatus?.available ? (
                        <div className="flex items-center text-accent-foreground py-1 px-2 rounded-md bg-background/10 text-xs">
                          <Zap className="h-3 w-3 mr-1 text-green-400" />
                          <span>AI Enhanced</span>
                        </div>
                      ) : (
                        <div className="flex items-center text-yellow-200 py-1 px-2 rounded-md bg-background/10 text-xs">
                          <AlertTriangle className="h-3 w-3 mr-1 text-yellow-400" />
                          <span>Basic Mode</span>
                        </div>
                      )}
                    </>
                  )}
                </div>
              </TooltipTrigger>
              <TooltipContent>
                {aiStatus?.available 
                  ? "Enhanced analysis with AI capabilities is active"
                  : "Running in basic mode - AI analysis unavailable"}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <button className="bg-dark-surface hover:bg-gray-700 text-white px-4 py-2 rounded-md flex items-center text-sm">
            <Info className="h-4 w-4 mr-2" />
            Documentation
          </button>
          <button className="bg-secondary hover:bg-blue-600 text-white px-4 py-2 rounded-md flex items-center text-sm">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
            Connect Wallet
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
