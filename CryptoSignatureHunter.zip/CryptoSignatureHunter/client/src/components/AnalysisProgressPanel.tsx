import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Check, Circle } from 'lucide-react';

export interface AnalysisStep {
  id: string;
  name: string;
  status: 'completed' | 'in-progress' | 'waiting';
  details: string;
}

interface AnalysisProgressPanelProps {
  overallProgress: number;
  status: string;
  steps: AnalysisStep[];
}

const AnalysisProgressPanel: React.FC<AnalysisProgressPanelProps> = ({ 
  overallProgress, 
  status, 
  steps 
}) => {
  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold">Analysis Progress</h2>
        <span className="text-xs px-2 py-1 bg-secondary text-white rounded-full">
          {overallProgress === 100 ? 'Completed' : overallProgress > 0 ? 'Running' : 'Ready'}
        </span>
      </div>
      <CardContent className="p-6">
        <div className="mb-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Overall Progress</span>
            <span className="text-sm font-medium">{overallProgress}%</span>
          </div>
          <Progress value={overallProgress} className="w-full" />
        </div>
        
        <div className="space-y-4 mb-4">
          {steps.map((step) => (
            <div className="flex items-center" key={step.id}>
              <div className="flex-shrink-0">
                {step.status === 'completed' && (
                  <Check className="h-5 w-5 text-accent" />
                )}
                {step.status === 'in-progress' && (
                  <div className="h-5 w-5 bg-secondary rounded-full flex items-center justify-center animate-pulse">
                    <div className="h-2 w-2 bg-white rounded-full"></div>
                  </div>
                )}
                {step.status === 'waiting' && (
                  <Circle className="h-5 w-5 text-mid-gray" />
                )}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">{step.name}</p>
                <p className="text-xs text-mid-gray">{step.details}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-sm text-mid-gray italic">
          <span className="font-medium">Status: </span>{status}
        </div>
      </CardContent>
    </Card>
  );
};

export default AnalysisProgressPanel;
