import React from 'react';
import { 
  Award, 
  Trophy, 
  Star, 
  Lightbulb, 
  Zap, 
  Shield, 
  Clock, 
  Target, 
  Wand2, 
  Sparkles, 
  Gem
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { AchievementType } from '@shared/schema';

// Icons mapping for different achievement types
const achievementIcons = {
  pattern_discovery: Award,
  high_confidence: Target,
  key_found: Shield,
  nonce_reconstructed: Wand2,
  multiple_patterns: Sparkles,
  quick_analysis: Clock,
  first_analysis: Star,
  master_analyst: Trophy,
  accuracy: Gem,
  breakthrough: Lightbulb,
  innovator: Zap
};

// Colors for different achievement levels
const achievementColors = {
  bronze: 'bg-amber-700/10 text-amber-700 border-amber-700/20',
  silver: 'bg-slate-400/10 text-slate-400 border-slate-400/20',
  gold: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
  platinum: 'bg-purple-500/10 text-purple-500 border-purple-500/20'
};

export interface AchievementBadgeProps {
  type: keyof typeof achievementIcons | string;
  label: string;
  description: string;
  level?: 'bronze' | 'silver' | 'gold' | 'platinum';
  date?: string;
  className?: string;
  onClick?: () => void;
}

/**
 * Achievement badge component for displaying crypto analysis achievements
 */
export function AchievementBadge({
  type,
  label,
  description,
  level = 'bronze',
  date,
  className,
  onClick
}: AchievementBadgeProps) {
  const IconComponent = achievementIcons[type as keyof typeof achievementIcons] || Trophy;
  const colorClass = achievementColors[level];
  
  return (
    <TooltipProvider>
      <Tooltip delayDuration={300}>
        <TooltipTrigger asChild>
          <Card 
            className={cn(
              'relative border overflow-hidden transition-all cursor-pointer hover:scale-105 w-36 h-36',
              colorClass,
              className
            )}
            onClick={onClick}
          >
            <div className="absolute inset-0 opacity-10 bg-gradient-to-br from-white to-transparent pointer-events-none" />
            
            <CardHeader className="p-3 text-center pb-0">
              <Badge className={cn('bg-transparent', colorClass)}>
                {level.charAt(0).toUpperCase() + level.slice(1)}
              </Badge>
              <CardTitle className="text-sm mt-1 font-medium">{label}</CardTitle>
            </CardHeader>
            
            <CardContent className="p-3 py-1 flex items-center justify-center">
              <IconComponent size={32} className="opacity-90" />
            </CardContent>
            
            <CardFooter className="p-2 text-xs opacity-80 text-center">
              {date ? new Date(date).toLocaleDateString() : 'Locked'}
            </CardFooter>
          </Card>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="max-w-xs p-3">
          <div className="space-y-1">
            <h4 className="font-medium">{label}</h4>
            <p className="text-sm">{description}</p>
            {date && <p className="text-xs opacity-70">Achieved: {new Date(date).toLocaleDateString()}</p>}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

/**
 * Collection of achievement badges displayed in a grid
 */
export function AchievementCollection({
  achievements = [],
  className
}: {
  achievements: Array<{
    id: number;
    type: AchievementType;
    label: string;
    description: string;
    level: 'bronze' | 'silver' | 'gold' | 'platinum';
    achievedAt: string;
  }>;
  className?: string;
}) {
  return (
    <div className={cn('grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4', className)}>
      {achievements.map((achievement) => (
        <AchievementBadge
          key={achievement.id}
          type={achievement.type}
          label={achievement.label}
          description={achievement.description}
          level={achievement.level}
          date={achievement.achievedAt}
        />
      ))}
    </div>
  );
}

/**
 * Achievement display with progress for dashboard
 */
export function RecentAchievements({
  achievements = [],
  className
}: {
  achievements: Array<{
    id: number;
    type: AchievementType;
    label: string;
    description: string;
    level: 'bronze' | 'silver' | 'gold' | 'platinum';
    achievedAt: string;
  }>;
  className?: string;
}) {
  // Sort achievements by date (newest first)
  const sortedAchievements = [...achievements].sort(
    (a, b) => new Date(b.achievedAt).getTime() - new Date(a.achievedAt).getTime()
  );
  
  // Take only the 4 most recent achievements
  const recentAchievements = sortedAchievements.slice(0, 4);
  
  return (
    <Card className={cn('border', className)}>
      <CardHeader>
        <CardTitle className="text-xl flex items-center gap-2">
          <Trophy size={18} /> Recent Achievements
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {recentAchievements.map((achievement) => (
            <AchievementBadge
              key={achievement.id}
              type={achievement.type}
              label={achievement.label}
              description={achievement.description}
              level={achievement.level}
              date={achievement.achievedAt}
            />
          ))}
          {recentAchievements.length === 0 && (
            <div className="col-span-4 py-8 text-center text-muted-foreground">
              No achievements yet. Start analyzing transactions to earn badges!
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}