import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ClipboardCopy, Code, Eye, Save, Wrench, Brain, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export interface PatternGroup {
  id: string;
  name: string;
  confidence: number;
  transactionCount: number;
  characteristics: string;
  affectedAddresses: string[];
  discoveryTime: string;
  nonceReconstructed?: boolean;
  nonceValue?: string | null;
  partialNonce?: string | null;
  bruteForcedNonces?: string[] | null;
  reconstructionProgress?: number;
  bruteForcingProgress?: number;
}

interface PatternsPanelProps {
  patterns: PatternGroup[];
  onExploitPattern: (patternId: string) => void;
  onSaveNonceInfo?: (patternId: string) => void;
  onViewNonceDetails?: (patternId: string) => void;
}

const PatternsPanel: React.FC<PatternsPanelProps> = ({ 
  patterns, 
  onExploitPattern,
  onSaveNonceInfo = () => {},
  onViewNonceDetails = () => {}
}) => {
  const { toast } = useToast();
  const [filter, setFilter] = useState<string>('all');
  const [expandedPatterns, setExpandedPatterns] = useState<Record<string, boolean>>({});

  const filteredPatterns = patterns.filter(pattern => {
    if (filter === 'all') return true;
    if (filter === 'high') return pattern.confidence >= 90;
    if (filter === 'medium') return pattern.confidence >= 50 && pattern.confidence < 90;
    if (filter === 'low') return pattern.confidence < 50;
    return true;
  });

  const toggleExpand = (patternId: string) => {
    setExpandedPatterns(prev => ({
      ...prev,
      [patternId]: !prev[patternId]
    }));
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Pattern information has been copied"
    });
  };

  const getConfidenceBadgeColor = (confidence: number) => {
    if (confidence >= 90) return 'bg-accent text-white';
    if (confidence >= 50) return 'bg-yellow-500 text-white';
    return 'bg-error text-white';
  };

  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4">
        <h2 className="text-lg font-semibold">Discovered Patterns</h2>
      </div>
      <div className="px-6 py-4 border-b">
        <div className="flex flex-wrap items-center">
          <span className="mr-4 text-sm font-medium">Filter by confidence:</span>
          <div className="flex space-x-2">
            <Button
              variant={filter === 'all' ? 'default' : 'secondary'}
              size="sm"
              className={filter === 'all' ? 'bg-secondary text-white' : 'bg-light-gray text-gray-700'}
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button
              variant={filter === 'high' ? 'default' : 'secondary'}
              size="sm"
              className={filter === 'high' ? 'bg-secondary text-white' : 'bg-light-gray text-gray-700'}
              onClick={() => setFilter('high')}
            >
              High (90%+)
            </Button>
            <Button
              variant={filter === 'medium' ? 'default' : 'secondary'}
              size="sm"
              className={filter === 'medium' ? 'bg-secondary text-white' : 'bg-light-gray text-gray-700'}
              onClick={() => setFilter('medium')}
            >
              Medium (50-89%)
            </Button>
            <Button
              variant={filter === 'low' ? 'default' : 'secondary'}
              size="sm"
              className={filter === 'low' ? 'bg-secondary text-white' : 'bg-light-gray text-gray-700'}
              onClick={() => setFilter('low')}
            >
              Low (&lt;50%)
            </Button>
          </div>
        </div>
      </div>
      
      <div className="divide-y divide-light-gray">
        {filteredPatterns.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            No patterns discovered yet
          </div>
        ) : (
          filteredPatterns.map((pattern) => (
            <div className="p-6" key={pattern.id}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-md font-medium flex items-center">
                    {pattern.name}
                    <span className={`ml-2 text-xs px-2 py-1 ${getConfidenceBadgeColor(pattern.confidence)} rounded-full`}>
                      {pattern.confidence}% Confidence
                    </span>
                  </h3>
                  <p className="text-sm text-mid-gray">Identified across {pattern.transactionCount} transactions</p>
                </div>
                <Button 
                  variant="link" 
                  className="text-secondary hover:text-blue-600 text-sm font-medium"
                  onClick={() => toggleExpand(pattern.id)}
                >
                  {expandedPatterns[pattern.id] ? 'Hide Details' : 'View Details'}
                </Button>
              </div>
              
              <div className="bg-background rounded-lg p-4 mb-4">
                <h4 className="text-xs font-medium mb-2">Pattern Characteristics:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-mid-gray mb-1">Signature Pattern</p>
                    <div className="bg-dark-surface rounded p-2">
                      <pre className="crypto-data text-xs text-white overflow-x-auto">
                        {pattern.characteristics}
                      </pre>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-mid-gray mb-1">Affected Addresses</p>
                    <div className="bg-dark-surface rounded p-2 h-[calc(100%-20px)]">
                      <div className="crypto-data text-xs text-white overflow-x-auto">
                        {pattern.affectedAddresses.map((address, i) => (
                          <span key={i}>
                            {address}
                            {i < pattern.affectedAddresses.length - 1 && <br />}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Nonce Information Section */}
                {expandedPatterns[pattern.id] && (
                  <div className="mt-4">
                    <h4 className="text-xs font-medium mb-2">Nonce Analysis:</h4>
                    
                    {/* Reused Nonce Information */}
                    {pattern.metadata?.reusedNonce ? (
                      <div className="mb-4">
                        <div className="flex items-center">
                          <Badge className="bg-red-500 text-white mb-1">Reused Nonce (k)</Badge>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-6 ml-1 p-0 text-xs text-secondary"
                            onClick={() => handleCopy(pattern.metadata.reusedNonce)}
                          >
                            <ClipboardCopy className="h-3 w-3 mr-1" />
                            Copy
                          </Button>
                        </div>
                        <div className="bg-dark-surface rounded p-2 mb-2">
                          <pre className="crypto-data text-xs text-white overflow-x-auto whitespace-pre-wrap break-all">
                            Reused k (nonce, 256-bit hex):{'\n'}{pattern.metadata?.reusedNonce || 'Not available'}
                            {'\n\n'}Signature Data for k1 = k2:{'\n'}
                            R (k·G.x): {pattern.metadata?.signatures?.[0]?.r || 'Not available'}{'\n'}
                            S1: {pattern.metadata?.signatures?.[0]?.s || 'Not available'}{'\n'}
                            S2: {pattern.metadata?.signatures?.[1]?.s || 'Not available'}{'\n'}
                            Z1: {pattern.metadata?.signatures?.[0]?.z || 'Not available'}{'\n'}
                            Z2: {pattern.metadata?.signatures?.[1]?.z || 'Not available'}
                          </pre>
                        </div>
                        
                        <h5 className="text-xs font-medium mb-2">Full Signatures:</h5>
                        {pattern.metadata.signatures.map((sig, index) => (
                          <div key={index} className="bg-dark-surface rounded p-2 mb-2">
                            <pre className="crypto-data text-xs text-white overflow-x-auto">
                              Signature {index + 1}:
                              R (256-bit): {sig.r}
                              S (256-bit): {sig.s}
                              Z (message hash): {sig.z}
                              Public Key: {sig.pubkey}
                            </pre>
                          </div>
                        ))}
                        
                        <div className="text-xs text-yellow-500 mt-2">
                          To derive private key: solve k1 = k2 using the signature pairs above
                        </div>
                      </div>
                    ) : pattern.nonceReconstructed && pattern.nonceValue ? (
                      <div className="mb-4">
                        <div className="flex items-center">
                          <Badge className="bg-accent text-white mb-1">Reconstructed Nonce</Badge>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-6 ml-1 p-0 text-xs text-secondary"
                            onClick={() => handleCopy(pattern.nonceValue || "")}
                          >
                            <ClipboardCopy className="h-3 w-3 mr-1" />
                            Copy
                          </Button>
                        </div>
                        <div className="bg-dark-surface rounded p-2">
                          <pre className="crypto-data text-xs text-white overflow-x-auto">
                            {pattern.nonceValue}
                          </pre>
                        </div>
                      </div>
                    ) : (
                      <>
                        {/* Reconstruction Progress */}
                        <div className="mb-4">
                          <p className="text-xs text-mid-gray mb-1 flex items-center">
                            <Brain className="h-3 w-3 mr-1" />
                            Nonce Reconstruction Progress
                          </p>
                          <Progress 
                            value={pattern.reconstructionProgress || 0} 
                            className="h-2" 
                          />
                          <p className="text-xs text-right mt-1">
                            {pattern.reconstructionProgress || 0}%
                          </p>
                        </div>
                      </>
                    )}
                    
                    {/* Partial Nonce */}
                    {pattern.partialNonce && (
                      <div className="mb-4">
                        <div className="flex items-center">
                          <Badge className="bg-yellow-500 text-white mb-1">Partial Nonce</Badge>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-6 ml-1 p-0 text-xs text-secondary"
                            onClick={() => handleCopy(pattern.partialNonce || "")}
                          >
                            <ClipboardCopy className="h-3 w-3 mr-1" />
                            Copy
                          </Button>
                        </div>
                        <div className="bg-dark-surface rounded p-2">
                          <pre className="crypto-data text-xs text-white overflow-x-auto">
                            {pattern.partialNonce}
                          </pre>
                        </div>
                      </div>
                    )}
                    
                    {/* Brute Force Candidates */}
                    {pattern.bruteForcedNonces && pattern.bruteForcedNonces.length > 0 && (
                      <div className="mb-4">
                        <div className="flex items-center justify-between">
                          <Badge className="bg-error text-white mb-1">Brute Force Candidates ({pattern.bruteForcedNonces.length})</Badge>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-6 ml-1 p-0 text-xs text-secondary"
                            onClick={() => handleCopy(pattern.bruteForcedNonces?.join('\n') || "")}
                          >
                            <ClipboardCopy className="h-3 w-3 mr-1" />
                            Copy All
                          </Button>
                        </div>
                        <div className="bg-dark-surface rounded p-2">
                          <pre className="crypto-data text-xs text-white overflow-x-auto h-24 overflow-y-auto">
                            {pattern.bruteForcedNonces.map((nonce, i) => (
                              <div key={i} className="flex justify-between items-center">
                                <span>{nonce}</span>
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-6 p-0 text-xs text-secondary"
                                  onClick={() => handleCopy(nonce)}
                                >
                                  <ClipboardCopy className="h-3 w-3" />
                                </Button>
                              </div>
                            ))}
                          </pre>
                        </div>
                        
                        {/* Brute Force Progress */}
                        <div className="mt-2">
                          <p className="text-xs text-mid-gray mb-1 flex items-center">
                            <Wrench className="h-3 w-3 mr-1" />
                            Brute Force Progress
                          </p>
                          <Progress 
                            value={pattern.bruteForcingProgress || 0} 
                            className="h-2" 
                          />
                          <p className="text-xs text-right mt-1">
                            {pattern.bruteForcingProgress || 0}%
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex flex-wrap items-center gap-2">
                  <Button 
                    size="sm"
                    className="text-xs bg-secondary text-white hover:bg-blue-600"
                    onClick={() => onExploitPattern(pattern.id)}
                  >
                    <Code className="h-4 w-4 mr-1" />
                    Exploit Pattern
                  </Button>
                  
                  {/* View Nonce Details Button */}
                  <Button 
                    size="sm"
                    variant="outline"
                    className="text-xs border-accent text-accent hover:bg-accent hover:text-white"
                    onClick={() => onViewNonceDetails(pattern.id)}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View Nonce Details
                  </Button>
                  
                  {/* Save Nonce Info Button - Only show if we have any type of nonce data */}
                  {(pattern.nonceValue || pattern.partialNonce || (pattern.bruteForcedNonces && pattern.bruteForcedNonces.length > 0)) && (
                    <Button 
                      size="sm"
                      variant="outline"
                      className="text-xs border-yellow-500 text-yellow-600 hover:bg-yellow-500 hover:text-white"
                      onClick={() => onSaveNonceInfo(pattern.id)}
                    >
                      <Save className="h-4 w-4 mr-1" />
                      Save Nonce Info
                    </Button>
                  )}
                  
                  <Button 
                    size="sm"
                    variant="outline"
                    className="text-xs border-light-gray text-mid-gray hover:bg-light-gray"
                    onClick={() => handleCopy(JSON.stringify(pattern, null, 2))}
                  >
                    <ClipboardCopy className="h-4 w-4 mr-1" />
                    Copy
                  </Button>
                </div>
                <div className="text-xs text-mid-gray">
                  Found {pattern.discoveryTime}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
};

export default PatternsPanel;
