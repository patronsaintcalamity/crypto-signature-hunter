import React, { useState } from 'react';
import { 
  CalendarClock, 
  ChevronRight, 
  Search, 
  Key, 
  Puzzle,
  Lightbulb,
  PlayCircle,
  CheckCircle2,
  ChevronsUpDown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TimelineEntry } from '@shared/schema';

// Icons for different timeline event types
const timelineIcons = {
  pattern_found: Puzzle,
  key_derived: Key,
  nonce_reconstructed: Lightbulb,
  analysis_started: PlayCircle,
  analysis_completed: CheckCircle2
};

// Colors for different timeline event types
const timelineColors = {
  pattern_found: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  key_derived: 'bg-green-500/10 text-green-500 border-green-500/20',
  nonce_reconstructed: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
  analysis_started: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  analysis_completed: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
};

// Labels for different timeline event types
const timelineLabels = {
  pattern_found: 'Pattern Found',
  key_derived: 'Key Derived',
  nonce_reconstructed: 'Nonce Reconstructed',
  analysis_started: 'Analysis Started',
  analysis_completed: 'Analysis Completed'
};

interface TimelineItemProps {
  entry: TimelineEntry;
  isLast?: boolean;
}

const TimelineItem: React.FC<TimelineItemProps> = ({ entry, isLast = false }) => {
  const [expanded, setExpanded] = useState(false);
  const IconComponent = timelineIcons[entry.type as keyof typeof timelineIcons] || CalendarClock;
  const colorClass = timelineColors[entry.type as keyof typeof timelineColors] || '';
  const typeLabel = timelineLabels[entry.type as keyof typeof timelineLabels] || entry.type;
  
  // Format the date for display
  const date = new Date(entry.timestamp);
  const formattedDate = date.toLocaleDateString();
  const formattedTime = date.toLocaleTimeString();
  
  return (
    <div className="flex group">
      {/* Timeline connector */}
      <div className="flex flex-col items-center mr-4">
        <div className={cn(
          "rounded-full p-1 border-2 shadow-sm z-10",
          colorClass
        )}>
          <IconComponent size={16} className="text-current" />
        </div>
        {!isLast && (
          <div className="w-px grow bg-border group-hover:bg-primary/50 transition-colors ease-in-out duration-300" />
        )}
      </div>
      
      {/* Timeline content */}
      <div className="pb-8 w-full">
        <Collapsible open={expanded} onOpenChange={setExpanded}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold flex items-center">
                {entry.title}
                <Badge variant="outline" className={cn("ml-2 text-xs", colorClass)}>
                  {typeLabel}
                </Badge>
              </p>
              <p className="text-xs text-muted-foreground">
                {formattedDate} at {formattedTime}
              </p>
            </div>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="p-1 h-auto">
                <ChevronRight className={cn(
                  "h-4 w-4 transition-transform duration-200",
                  expanded ? "rotate-90" : ""
                )} />
              </Button>
            </CollapsibleTrigger>
          </div>
          
          <CollapsibleContent>
            <div className="pl-0 pt-2">
              <Card className="bg-card/50">
                <CardContent className="p-3 text-sm">
                  <p>{entry.description}</p>
                  
                  {entry.metadata && Object.keys(entry.metadata).length > 0 && (
                    <>
                      <Separator className="my-2" />
                      <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="details" className="border-b-0">
                          <AccordionTrigger className="py-1 text-xs">
                            Additional Details
                          </AccordionTrigger>
                          <AccordionContent>
                            <div className="text-xs space-y-1 font-mono bg-muted/50 p-2 rounded">
                              {Object.entries(entry.metadata).map(([key, value]) => (
                                <div key={key} className="grid grid-cols-3 gap-2">
                                  <span className="text-muted-foreground">{key}:</span>
                                  <span className="col-span-2 break-all">
                                    {typeof value === 'object' 
                                      ? JSON.stringify(value) 
                                      : String(value)
                                    }
                                  </span>
                                </div>
                              ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </div>
  );
};

export interface AnalysisTimelineProps {
  entries: TimelineEntry[];
  className?: string;
}

export function AnalysisTimeline({ entries = [], className }: AnalysisTimelineProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  
  // Filter entries by search term and type
  const filteredEntries = entries.filter(entry => {
    const matchesSearch = 
      entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = typeFilter === 'all' || entry.type === typeFilter;
    
    return matchesSearch && matchesType;
  });
  
  // Sort entries by timestamp (newest first)
  const sortedEntries = [...filteredEntries].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
  
  return (
    <Card className={cn('border', className)}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <CalendarClock size={18} /> Analysis Timeline
            </CardTitle>
            <CardDescription>
              Chronological history of discoveries and events
            </CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search timeline..."
                className="pl-8 h-9 w-[200px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="h-9 w-[130px]">
                <ChevronsUpDown className="h-4 w-4 opacity-50" />
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Events</SelectItem>
                <SelectItem value="pattern_found">Patterns</SelectItem>
                <SelectItem value="key_derived">Keys</SelectItem>
                <SelectItem value="nonce_reconstructed">Nonces</SelectItem>
                <SelectItem value="analysis_started">Analysis Start</SelectItem>
                <SelectItem value="analysis_completed">Analysis Complete</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {sortedEntries.length > 0 ? (
          <div className="space-y-0 pt-2">
            {sortedEntries.map((entry, index) => (
              <TimelineItem 
                key={entry.id} 
                entry={entry} 
                isLast={index === sortedEntries.length - 1}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            {entries.length > 0 
              ? 'No matching events found for your search criteria.' 
              : 'No timeline events recorded yet. Start analyzing to build your timeline.'}
          </div>
        )}
      </CardContent>
    </Card>
  );
}