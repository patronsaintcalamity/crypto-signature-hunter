import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  ShieldCheck, ShieldAlert, ShieldX, 
  EyeOff, Fingerprint, RefreshCw, ChevronDown 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AnonymityScoreCardProps {
  address?: string;
  transactions?: Array<{
    txid: string;
    r?: string;
    s?: string;
    z?: string;
    patternId?: string | null;
  }>;
  patterns?: Array<{
    id: string;
    confidence: number;
    transactionCount: number;
  }>;
}

const AnonymityScoreCard: React.FC<AnonymityScoreCardProps> = ({
  address,
  transactions = [],
  patterns = []
}) => {
  const { toast } = useToast();
  const [anonymityScore, setAnonymityScore] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [riskFactors, setRiskFactors] = useState<Array<{
    name: string;
    impact: number;
    description: string;
    severity: 'high' | 'medium' | 'low';
  }>>([]);
  
  const generateScore = () => {
    setIsGenerating(true);
    
    // Simulate calculation delay
    setTimeout(() => {
      const factors: Array<{
        name: string;
        impact: number;
        description: string;
        severity: 'high' | 'medium' | 'low';
      }> = [];
      
      let baseScore = 100; // Start with perfect score
      
      // Factor 1: Number of transactions (more transactions = less anonymity)
      const txCount = transactions.length;
      let txImpact = 0;
      
      if (txCount > 20) {
        txImpact = 25;
        factors.push({
          name: 'High Transaction Count',
          impact: txImpact,
          description: `${txCount} transactions found for this address. High transaction volume increases traceability.`,
          severity: 'high'
        });
      } else if (txCount > 10) {
        txImpact = 15;
        factors.push({
          name: 'Medium Transaction Count',
          impact: txImpact,
          description: `${txCount} transactions found for this address. Moderate transaction volume increases analysis surface area.`,
          severity: 'medium'
        });
      } else if (txCount > 0) {
        txImpact = 5;
        factors.push({
          name: 'Low Transaction Count',
          impact: txImpact,
          description: `${txCount} transactions found for this address. Minimal transaction history provides better privacy.`,
          severity: 'low'
        });
      }
      
      baseScore -= txImpact;
      
      // Factor 2: Pattern detection (more patterns = less anonymity)
      const patternCount = patterns.length;
      let patternImpact = 0;
      
      if (patternCount > 3) {
        patternImpact = 35;
        factors.push({
          name: 'Multiple Signature Patterns',
          impact: patternImpact,
          description: `${patternCount} distinct signature patterns detected. High number of patterns indicates weak key generation.`,
          severity: 'high'
        });
      } else if (patternCount > 1) {
        patternImpact = 20;
        factors.push({
          name: 'Some Signature Patterns',
          impact: patternImpact,
          description: `${patternCount} signature patterns detected. Multiple patterns suggests non-random signatures.`,
          severity: 'medium'
        });
      } else if (patternCount === 1) {
        patternImpact = 10;
        factors.push({
          name: 'Single Signature Pattern',
          impact: patternImpact,
          description: 'One signature pattern detected. Pattern consistency indicates potential cryptographic weakness.',
          severity: 'low'
        });
      }
      
      baseScore -= patternImpact;
      
      // Factor 3: High confidence patterns (higher confidence = greater risk)
      const highConfidencePatterns = patterns.filter(p => p.confidence >= 90).length;
      let confidenceImpact = 0;
      
      if (highConfidencePatterns > 0) {
        confidenceImpact = 30;
        factors.push({
          name: 'High Confidence Vulnerabilities',
          impact: confidenceImpact,
          description: `${highConfidencePatterns} high-confidence vulnerability patterns detected. These patterns have a high probability of key exposure.`,
          severity: 'high'
        });
      }
      
      baseScore -= confidenceImpact;
      
      // Ensure score doesn't go below 0 or above 100
      const finalScore = Math.max(0, Math.min(100, baseScore));
      
      setAnonymityScore(finalScore);
      setRiskFactors(factors);
      setIsGenerating(false);
      
      toast({
        title: "Anonymity Score Generated",
        description: `Score: ${finalScore}/100`,
      });
    }, 1500);
  };
  
  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 50) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  
  const getScoreIcon = (score: number) => {
    if (score >= 80) return <ShieldCheck className="text-green-500 h-12 w-12" />;
    if (score >= 50) return <ShieldAlert className="text-yellow-500 h-12 w-12" />;
    return <ShieldX className="text-red-500 h-12 w-12" />;
  };
  
  const getScoreText = (score: number): string => {
    if (score >= 80) return 'High Anonymity';
    if (score >= 50) return 'Moderate Anonymity';
    return 'Low Anonymity';
  };
  
  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4">
        <h2 className="text-lg font-semibold flex items-center">
          <EyeOff className="h-5 w-5 mr-2" />
          Anonymity Score Generator
        </h2>
      </div>
      
      <div className="px-6 py-4">
        <div className="flex flex-col items-center text-center mb-6">
          {anonymityScore !== null ? (
            <>
              <div className="mb-4">
                {getScoreIcon(anonymityScore)}
              </div>
              <h3 className="text-2xl font-bold mb-2">
                {getScoreText(anonymityScore)}
              </h3>
              <div className="w-full max-w-md mb-4">
                <Progress 
                  value={anonymityScore} 
                  className={`h-3 ${getScoreColor(anonymityScore)}`} 
                />
                <div className="flex justify-between mt-1 text-sm text-gray-500">
                  <span>High Risk</span>
                  <span>{anonymityScore}/100</span>
                  <span>Low Risk</span>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center py-8">
              <Fingerprint className="h-16 w-16 text-gray-300 mb-4" />
              <p className="text-gray-500 mb-6">
                Generate an anonymity score based on signature analysis
              </p>
            </div>
          )}
          
          <Button 
            className="bg-primary hover:bg-primary/90"
            disabled={isGenerating || (!address && transactions.length === 0)}
            onClick={generateScore}
          >
            {isGenerating ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Generating Score...
              </>
            ) : (
              <>
                <Fingerprint className="h-4 w-4 mr-2" />
                {anonymityScore !== null ? 'Recalculate Score' : 'Generate Score'}
              </>
            )}
          </Button>
        </div>
        
        {anonymityScore !== null && riskFactors.length > 0 && (
          <div className="mt-6">
            <div 
              className="flex items-center justify-between cursor-pointer py-2"
              onClick={() => setShowDetails(!showDetails)}
            >
              <h4 className="font-medium">Risk Factors</h4>
              <ChevronDown className={`h-5 w-5 transition-transform ${showDetails ? 'rotate-180' : ''}`} />
            </div>
            
            {showDetails && (
              <div className="mt-2 space-y-3">
                {riskFactors.map((factor, index) => (
                  <div 
                    key={index} 
                    className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md border-l-4 border-red-500"
                    style={{ borderColor: 
                      factor.severity === 'high' ? '#E53935' : 
                      factor.severity === 'medium' ? '#FB8C00' : 
                      '#43A047'
                    }}
                  >
                    <div className="flex justify-between mb-1">
                      <span className="font-medium">{factor.name}</span>
                      <span className="text-sm">-{factor.impact} points</span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">{factor.description}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
};

export default AnonymityScoreCard;