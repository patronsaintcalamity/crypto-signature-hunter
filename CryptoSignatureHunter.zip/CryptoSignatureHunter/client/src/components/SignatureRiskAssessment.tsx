import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Cell, Pie, PieChart, Legend 
} from 'recharts';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Shield, TrendingUp, BarChart2, PieChart as PieChartIcon } from 'lucide-react';

interface RiskCategory {
  name: string;
  value: number;
  color: string;
  details: string;
}

interface SignatureRiskAssessmentProps {
  patterns: Array<{
    id: string;
    name: string;
    confidence: number;
    transactionCount: number;
    characteristics: string;
  }>;
}

const SignatureRiskAssessment: React.FC<SignatureRiskAssessmentProps> = ({
  patterns
}) => {
  const [chartType, setChartType] = useState<'bar' | 'pie'>('bar');
  
  // Calculate risk levels based on patterns
  const generateRiskData = (): RiskCategory[] => {
    // Count patterns by risk level
    const highRiskPatterns = patterns.filter(p => p.confidence >= 90).length;
    const mediumRiskPatterns = patterns.filter(p => p.confidence >= 50 && p.confidence < 90).length;
    const lowRiskPatterns = patterns.filter(p => p.confidence < 50).length;
    
    return [
      {
        name: 'High Risk',
        value: highRiskPatterns,
        color: '#E53935', // Red
        details: 'High confidence signature patterns that likely indicate key exposure'
      },
      {
        name: 'Medium Risk',
        value: mediumRiskPatterns,
        color: '#FB8C00', // Orange
        details: 'Moderate confidence patterns with potential vulnerabilities'
      },
      {
        name: 'Low Risk',
        value: lowRiskPatterns,
        color: '#43A047', // Green
        details: 'Low confidence patterns that may not indicate vulnerabilities'
      }
    ];
  };
  
  const riskData = generateRiskData();
  
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-gray-800 p-3 rounded shadow-md border border-gray-200 dark:border-gray-700">
          <p className="font-medium">{data.name}</p>
          <p className="text-sm">{data.value} pattern{data.value !== 1 ? 's' : ''}</p>
          <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">{data.details}</p>
        </div>
      );
    }
    return null;
  };
  
  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold flex items-center">
          <Shield className="h-5 w-5 mr-2" />
          Risk Assessment
        </h2>
        
        <div className="flex space-x-2">
          <Button
            variant={chartType === 'bar' ? 'secondary' : 'outline'}
            size="sm"
            className={chartType === 'bar' ? 'bg-white/20 text-white' : 'bg-transparent text-white border-white/20'}
            onClick={() => setChartType('bar')}
          >
            <BarChart2 className="h-4 w-4 mr-1" />
            Bar
          </Button>
          <Button
            variant={chartType === 'pie' ? 'secondary' : 'outline'}
            size="sm"
            className={chartType === 'pie' ? 'bg-white/20 text-white' : 'bg-transparent text-white border-white/20'}
            onClick={() => setChartType('pie')}
          >
            <PieChartIcon className="h-4 w-4 mr-1" />
            Pie
          </Button>
        </div>
      </div>
      
      <div className="px-6 py-6">
        {patterns.length > 0 ? (
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              {chartType === 'bar' ? (
                <BarChart
                  data={riskData}
                  margin={{ top: 20, right: 30, left: 0, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="value" name="Patterns">
                    {riskData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              ) : (
                <PieChart>
                  <Pie
                    data={riskData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, value, percent }) => value > 0 ? `${name}: ${value} (${(percent * 100).toFixed(0)}%)` : ''}
                  >
                    {riskData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                </PieChart>
              )}
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8">
            <AlertTriangle className="h-16 w-16 text-gray-300 mb-4" />
            <p className="text-gray-500 text-center">
              No signature pattern data available for risk assessment.
              <br />
              Start an analysis to identify signature patterns and risks.
            </p>
          </div>
        )}
      </div>
      
      <div className="px-6 py-3 bg-gray-50 dark:bg-gray-800 border-t">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <TrendingUp className="h-4 w-4 mr-2 text-gray-500" />
            <span className="text-sm text-gray-600 dark:text-gray-300">
              Risk assessment based on signature pattern analysis
            </span>
          </div>
          
          {patterns.length > 0 && (
            <div className="text-sm text-gray-600 dark:text-gray-300">
              {patterns.length} pattern{patterns.length !== 1 ? 's' : ''} analyzed
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default SignatureRiskAssessment;