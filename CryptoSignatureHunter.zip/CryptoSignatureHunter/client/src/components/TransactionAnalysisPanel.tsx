import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Filter } from 'lucide-react';

export interface Transaction {
  id: string;
  txid: string;
  address: string;
  patternId: string | null;
  patternName: string | null;
  confidence: number;
  status: 'key_found' | 'in_progress' | 'analyzed' | 'pending';
}

interface TransactionAnalysisPanelProps {
  transactions: Transaction[];
  totalTransactions: number;
  currentPage: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  onSearch: (term: string) => void;
  onFilterChange: (filter: string) => void;
}

const TransactionAnalysisPanel: React.FC<TransactionAnalysisPanelProps> = ({
  transactions,
  totalTransactions,
  currentPage,
  pageSize,
  onPageChange,
  onSearch,
  onFilterChange
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchTerm);
  };

  const handleFilterChange = (value: string) => {
    setFilter(value);
    onFilterChange(value);
  };

  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'key_found':
        return (
          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
            Key Found
          </span>
        );
      case 'in_progress':
        return (
          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
            In Progress
          </span>
        );
      case 'analyzed':
        return (
          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
            Analyzed
          </span>
        );
      case 'pending':
        return (
          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
            Pending
          </span>
        );
      default:
        return null;
    }
  };

  const getPatternDisplay = (patternName: string | null) => {
    if (!patternName) {
      return (
        <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
          No Pattern
        </span>
      );
    }
    return (
      <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
        {patternName}
      </span>
    );
  };

  const totalPages = Math.ceil(totalTransactions / pageSize);
  const start = (currentPage - 1) * pageSize + 1;
  const end = Math.min(start + pageSize - 1, totalTransactions);

  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4">
        <h2 className="text-lg font-semibold">Transaction Analysis</h2>
      </div>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row justify-between mb-4">
          <div className="mb-4 md:mb-0 flex-grow md:mr-4">
            <form onSubmit={handleSearchSubmit}>
              <div className="relative">
                <Input
                  id="txid-search"
                  placeholder="Search transaction hash or signature pattern"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  <Button type="submit" variant="ghost" size="sm" className="h-full">
                    <Search className="h-5 w-5 text-mid-gray" />
                  </Button>
                </div>
              </div>
            </form>
          </div>
          
          <div className="flex space-x-2">
            <Select value={filter} onValueChange={handleFilterChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Transactions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Transactions</SelectItem>
                <SelectItem value="with_pattern">With Pattern Match</SelectItem>
                <SelectItem value="vulnerable">With Vulnerability</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" size="icon">
              <Filter className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-background">
              <TableRow>
                <TableHead className="text-xs font-medium text-mid-gray uppercase">
                  Transaction ID
                </TableHead>
                <TableHead className="text-xs font-medium text-mid-gray uppercase">
                  Address
                </TableHead>
                <TableHead className="text-xs font-medium text-mid-gray uppercase">
                  Signature Pattern
                </TableHead>
                <TableHead className="text-xs font-medium text-mid-gray uppercase">
                  Confidence
                </TableHead>
                <TableHead className="text-xs font-medium text-mid-gray uppercase">
                  Status
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                    No transactions found
                  </TableCell>
                </TableRow>
              ) : (
                transactions.map((tx) => (
                  <TableRow key={tx.id} className="hover:bg-background cursor-pointer">
                    <TableCell className="font-mono text-sm text-gray-700">
                      {tx.txid.slice(0, 6)}...{tx.txid.slice(-6)}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {tx.address.slice(0, 6)}...{tx.address.slice(-4)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {getPatternDisplay(tx.patternName)}
                    </TableCell>
                    <TableCell className="text-sm">
                      <div className="flex items-center">
                        <div className="w-16 bg-light-gray rounded-full h-2 mr-2">
                          <div 
                            className={`h-2 rounded-full ${
                              tx.confidence >= 90 ? 'bg-accent' : 
                              tx.confidence >= 50 ? 'bg-yellow-500' : 
                              'bg-red-500'
                            }`} 
                            style={{ width: `${tx.confidence}%` }}
                          >
                          </div>
                        </div>
                        <span>{tx.confidence}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">
                      {getStatusDisplay(tx.status)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        
        <div className="flex justify-between items-center mt-4">
          <div className="text-sm text-mid-gray">
            Showing <span className="font-medium">{start}-{end}</span> of <span className="font-medium">{totalTransactions}</span> transactions
          </div>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              className="px-3 py-1 border-light-gray text-mid-gray"
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            <Button 
              className="px-3 py-1 bg-secondary text-white"
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage >= totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TransactionAnalysisPanel;
