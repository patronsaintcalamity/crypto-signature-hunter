import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, Eye, EyeOff, ClipboardCopy, Download, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export interface DiscoveredKey {
  id: string;
  privateKey: string;
  address: string;
  verification: 'confirmed' | 'pending' | 'failed';
  discoveryTime: string;
  patternId: string;
}

interface DiscoveredKeysPanelProps {
  keys: DiscoveredKey[];
  onExport: (key: DiscoveredKey) => void;
}

const DiscoveredKeysPanel: React.FC<DiscoveredKeysPanelProps> = ({ keys, onExport }) => {
  const { toast } = useToast();
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});

  const toggleKeyVisibility = (keyId: string) => {
    setVisibleKeys(prev => ({
      ...prev,
      [keyId]: !prev[keyId]
    }));
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Private key has been copied"
    });
  };

  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold">Discovered Keys</h2>
        <span className="text-xs px-2 py-1 bg-accent text-white rounded-full">
          {keys.length} {keys.length === 1 ? 'Key' : 'Keys'} Found
        </span>
      </div>
      <CardContent className="p-6">
        {keys.length === 0 ? (
          <div className="text-center text-gray-500 py-6">
            No private keys discovered yet
          </div>
        ) : (
          <>
            {keys.some(key => key.verification === 'confirmed') && (
              <div className="bg-green-50 border border-accent rounded-lg p-4 mb-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Shield className="h-5 w-5 text-accent" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-green-800">Verified Key Discovery</h3>
                    <div className="mt-2 text-sm text-green-700">
                      <p>Successfully derived and verified private key from signature patterns.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {keys.map((key) => (
              <div key={key.id} className="border border-light-gray rounded-lg overflow-hidden mb-4">
                <div className="bg-background px-4 py-3 flex justify-between items-center">
                  <div className="flex items-center">
                    {key.verification === 'confirmed' ? (
                      <Shield className="h-5 w-5 text-accent mr-2" />
                    ) : key.verification === 'pending' ? (
                      <AlertCircle className="h-5 w-5 text-yellow-500 mr-2" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-error mr-2" />
                    )}
                    <h3 className="text-sm font-medium">Private Key</h3>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-xs px-2 py-1 border-light-gray text-mid-gray"
                      onClick={() => toggleKeyVisibility(key.id)}
                    >
                      {visibleKeys[key.id] ? (
                        <>
                          <EyeOff className="h-4 w-4 mr-1" />
                          Hide
                        </>
                      ) : (
                        <>
                          <Eye className="h-4 w-4 mr-1" />
                          Show
                        </>
                      )}
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-xs px-2 py-1 border-light-gray text-mid-gray"
                      onClick={() => handleCopy(key.privateKey)}
                    >
                      <ClipboardCopy className="h-4 w-4 mr-1" />
                      Copy
                    </Button>
                    <Button 
                      size="sm"
                      className="text-xs px-2 py-1 bg-secondary text-white"
                      onClick={() => onExport(key)}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Export
                    </Button>
                  </div>
                </div>
                <div className="p-4 bg-dark-surface">
                  <div className="flex items-center">
                    <pre className="crypto-data text-xs text-white overflow-x-auto w-full">
                      {visibleKeys[key.id] ? key.privateKey : '••••••••••••••••••••••••••••••••••••••••••••••••••••'}
                    </pre>
                  </div>
                </div>
                <div className="px-4 py-3 bg-background">
                  <div className="flex justify-between items-center">
                    <div className="text-xs">
                      <span className="text-mid-gray">Associated Address:</span>
                      <span className="font-mono ml-1">{key.address}</span>
                    </div>
                    <div className="text-xs">
                      <span className="text-mid-gray">Verification:</span>
                      <span className={`font-medium ml-1 ${
                        key.verification === 'confirmed' 
                          ? 'text-accent' 
                          : key.verification === 'pending' 
                            ? 'text-yellow-500' 
                            : 'text-error'
                      }`}>
                        {key.verification === 'confirmed' 
                          ? 'Confirmed on Bitcoin mainnet' 
                          : key.verification === 'pending' 
                            ? 'Verification in progress' 
                            : 'Verification failed - Key does not match address'}
                      </span>
                      {key.verification === 'failed' && (
                        <button 
                          className="ml-2 text-secondary underline"
                          onClick={() => {
                            toast({
                              title: "Verification Details",
                              description: "The derived private key doesn't correctly generate the associated Bitcoin address. This could indicate an issue with the cryptographic calculations or incorrect nonce reconstruction.",
                              variant: "destructive"
                            });
                          }}
                        >
                          Details
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default DiscoveredKeysPanel;
