import React, { useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Network, RefreshCw, Search, ZoomIn, ZoomOut, Maximize2, Minimize2, X, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import ForceGraph2D from 'react-force-graph-2d';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import * as d3 from 'd3';

interface GraphTransaction {
  id: string;
  txid: string;
  address: string;
  patternId?: string | null;
  confidence?: number;
}

interface GraphPattern {
  id: string;
  name: string;
  confidence: number;
  affectedAddresses: string[];
  nonceReconstructed?: boolean;
  nonceValue?: string | null;
}

interface SignatureGraphVisualizationProps {
  transactions: GraphTransaction[];
  patterns: GraphPattern[];
}

interface GraphNode {
  id: string;
  group: string;
  type: string;
  label: string;
  r?: string;
  s?: string;
  z?: string;
  patternId?: string;
  confidence?: number;
  transactions?: string[];
  size?: number;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
  fx?: number;
  fy?: number;
  __bckgDimensions?: [number, number];
}

interface GraphLink {
  source: string | GraphNode;
  target: string | GraphNode;
  value: number;
  type: string;
}

interface GraphGroup {
  id: string;
  name: string;
  color: string;
}

interface GraphData {
  nodes: GraphNode[];
  links: GraphLink[];
  groups: GraphGroup[];
}

const SignatureGraphVisualization: React.FC<SignatureGraphVisualizationProps> = ({
  transactions,
  patterns
}) => {
  const { toast } = useToast();
  const [highlightNodes, setHighlightNodes] = useState(new Set<string>());
  const [highlightLinks, setHighlightLinks] = useState(new Set<GraphLink>());
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [graphData, setGraphData] = useState<GraphData>({ nodes: [], links: [], groups: [] });
  const [isExpanded, setIsExpanded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [graphFilter, setGraphFilter] = useState<string>('all');
  const [nodeSizeMultiplier, setNodeSizeMultiplier] = useState<number>(1);
  const [linkStrengthMultiplier, setLinkStrengthMultiplier] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<string>('controls');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const graphRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Fetch graph data from API
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/visualization/signature-graph'],
    enabled: transactions.length > 0 || patterns.length > 0
  });

  // Process graph data from API
  useEffect(() => {
    if (!data) return;
    
    let filteredNodes = [...data.nodes];
    let filteredLinks = [...data.links];
    
    // Apply graph filter
    if (graphFilter !== 'all') {
      // Filter nodes by type
      filteredNodes = data.nodes.filter(node => node.group === graphFilter);
      
      // Filter links that connect to the filtered nodes
      const nodeIds = new Set(filteredNodes.map(node => node.id));
      filteredLinks = data.links.filter(link => 
        nodeIds.has(typeof link.source === 'string' ? link.source : link.source.id) && 
        nodeIds.has(typeof link.target === 'string' ? link.target : link.target.id)
      );
    }
    
    // Apply search filter if present
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      
      // Filter nodes that match the search query in id or label
      filteredNodes = filteredNodes.filter(node => 
        node.id.toLowerCase().includes(query) || 
        node.label.toLowerCase().includes(query)
      );
      
      // Filter links that connect to the filtered nodes
      const nodeIds = new Set(filteredNodes.map(node => node.id));
      filteredLinks = filteredLinks.filter(link => 
        nodeIds.has(typeof link.source === 'string' ? link.source : link.source.id) && 
        nodeIds.has(typeof link.target === 'string' ? link.target : link.target.id)
      );
    }
    
    setGraphData({
      nodes: filteredNodes,
      links: filteredLinks,
      groups: data.groups
    });
  }, [data, graphFilter, searchQuery]);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(err => {
        toast({
          title: "Fullscreen Error",
          description: `Error attempting to enable full-screen mode: ${err.message}`,
          variant: "destructive"
        });
      });
    } else {
      document.exitFullscreen();
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const handleNodeClick = (node: GraphNode) => {
    // Toggle node selection
    setSelectedNode(selectedNode && selectedNode.id === node.id ? null : node);
    
    // Clear any existing highlights
    setHighlightNodes(new Set([node.id]));
    setHighlightLinks(new Set());
    
    if (graphRef.current) {
      // Highlight the selected node and its connected links
      const links: GraphLink[] = graphRef.current.graphData().links;
      
      // Find links connected to this node
      const connectedLinks = links.filter((link: GraphLink) => {
        const sourceId = typeof link.source === 'string' ? link.source : link.source.id;
        const targetId = typeof link.target === 'string' ? link.target : link.target.id;
        return sourceId === node.id || targetId === node.id;
      });
      
      // Find connected nodes
      const connectedNodes = new Set<string>([node.id]);
      connectedLinks.forEach((link: GraphLink) => {
        const sourceId = typeof link.source === 'string' ? link.source : link.source.id;
        const targetId = typeof link.target === 'string' ? link.target : link.target.id;
        connectedNodes.add(sourceId);
        connectedNodes.add(targetId);
        setHighlightLinks(prevLinks => new Set([...prevLinks, link]));
      });
      
      setHighlightNodes(connectedNodes);
      
      // Center view on the selected node with some animation
      graphRef.current.centerAt(node.x, node.y, 1000);
      graphRef.current.zoom(2.5, 1000);
    }
    
    // Show node details in toast
    let details = '';
    if (node.type === 'transaction') {
      details = `Transaction: ${node.label}\n${
        node.r ? `R: ${node.r.substring(0, 16)}...\n` : ''
      }${
        node.s ? `S: ${node.s.substring(0, 16)}...\n` : ''
      }${
        node.confidence ? `Confidence: ${node.confidence}%` : ''
      }`;
    } else if (node.type === 'address') {
      details = `Address: ${node.id}\nTransactions: ${node.transactions?.length || 0}`;
    } else if (node.type === 'pattern') {
      details = `Pattern: ${node.label}\nConfidence: ${node.confidence}%\nTransactions: ${node.transactions?.length || 0}`;
    } else if (node.type === 'nonce') {
      details = `${node.label}\nUsed in pattern reconstruction`;
    }
    
    toast({
      title: `${node.type.charAt(0).toUpperCase() + node.type.slice(1)} Details`,
      description: details,
      duration: 5000
    });
  };

  const handleResetView = () => {
    if (graphRef.current) {
      graphRef.current.zoomToFit(400);
      setSelectedNode(null);
      setHighlightNodes(new Set());
      setHighlightLinks(new Set());
    }
  };

  const handleZoomIn = () => {
    if (graphRef.current) {
      const currentZoom = graphRef.current.zoom();
      graphRef.current.zoom(currentZoom * 1.5, 400);
    }
  };

  const handleZoomOut = () => {
    if (graphRef.current) {
      const currentZoom = graphRef.current.zoom();
      graphRef.current.zoom(currentZoom / 1.5, 400);
    }
  };

  const exportGraphImage = () => {
    if (!graphRef.current) return;
    
    try {
      // Get the canvas
      const canvas = graphRef.current.canvas();
      
      // Convert canvas to data URL
      const imageUrl = canvas.toDataURL('image/png');
      
      // Create download link
      const downloadLink = document.createElement('a');
      downloadLink.href = imageUrl;
      downloadLink.download = 'signature-graph.png';
      downloadLink.click();
      
      toast({
        title: "Export Successful",
        description: "Graph image has been exported successfully",
        duration: 3000
      });
    } catch (err) {
      toast({
        title: "Export Failed",
        description: "Failed to export graph image: " + (err instanceof Error ? err.message : String(err)),
        variant: "destructive"
      });
    }
  };

  // Define colors for different node types
  const getNodeColor = (node: GraphNode) => {
    if (highlightNodes.size && !highlightNodes.has(node.id)) {
      return 'rgba(200, 200, 200, 0.5)'; // Faded color for non-highlighted nodes
    }
    
    if (node.group === 'transaction') return '#9C27B0';
    if (node.group === 'address') return '#1976D2';
    if (node.group === 'pattern') {
      // Pattern color based on confidence
      const confidence = node.confidence || 0;
      if (confidence >= 90) return '#E53935'; // High confidence - red
      if (confidence >= 50) return '#FB8C00'; // Medium confidence - orange
      return '#43A047'; // Low confidence - green
    }
    if (node.group === 'nonce') return '#4CAF50';
    return '#9E9E9E'; // Default gray
  };

  // Define different node shapes based on node type
  const paintNode = (node: GraphNode, ctx: CanvasRenderingContext2D, globalScale: number) => {
    const size = ((node.size || 1) * 3 * nodeSizeMultiplier) / globalScale;
    
    ctx.beginPath();
    
    // Different shapes for different node types
    if (node.group === 'transaction') {
      // Diamond for transactions
      ctx.moveTo(node.x!, node.y! - size);
      ctx.lineTo(node.x! + size, node.y!);
      ctx.lineTo(node.x!, node.y! + size);
      ctx.lineTo(node.x! - size, node.y!);
    } else if (node.group === 'address') {
      // Square for addresses
      ctx.rect(node.x! - size, node.y! - size, size * 2, size * 2);
    } else if (node.group === 'pattern') {
      // Triangle for patterns
      ctx.moveTo(node.x!, node.y! - size);
      ctx.lineTo(node.x! + size, node.y! + size);
      ctx.lineTo(node.x! - size, node.y! + size);
    } else if (node.group === 'nonce') {
      // Circle for nonce
      ctx.arc(node.x!, node.y!, size, 0, 2 * Math.PI);
    } else {
      // Default circle
      ctx.arc(node.x!, node.y!, size, 0, 2 * Math.PI);
    }
    
    ctx.fillStyle = getNodeColor(node);
    ctx.fill();
    
    // Add text label for the selected node or larger nodes
    if ((selectedNode && selectedNode.id === node.id) || size > 3 / globalScale) {
      ctx.font = `${12 / globalScale}px Sans-Serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.lineWidth = 2 / globalScale;
      const label = node.label.length > 20 ? node.label.substring(0, 17) + '...' : node.label;
      ctx.strokeText(label, node.x!, node.y! + size + (10 / globalScale));
      ctx.fillText(label, node.x!, node.y! + size + (10 / globalScale));
    }
    
    // Add highlight effect for selectedNode
    if (selectedNode && selectedNode.id === node.id) {
      ctx.beginPath();
      if (node.group === 'transaction') {
        ctx.moveTo(node.x!, node.y! - size - 2);
        ctx.lineTo(node.x! + size + 2, node.y!);
        ctx.lineTo(node.x!, node.y! + size + 2);
        ctx.lineTo(node.x! - size - 2, node.y!);
      } else if (node.group === 'address') {
        ctx.rect(node.x! - size - 2, node.y! - size - 2, (size + 2) * 2, (size + 2) * 2);
      } else if (node.group === 'pattern') {
        ctx.moveTo(node.x!, node.y! - size - 2);
        ctx.lineTo(node.x! + size + 2, node.y! + size + 2);
        ctx.lineTo(node.x! - size - 2, node.y! + size + 2);
      } else {
        ctx.arc(node.x!, node.y!, size + 2, 0, 2 * Math.PI);
      }
      ctx.strokeStyle = '#FFF';
      ctx.lineWidth = 2 / globalScale;
      ctx.stroke();
    }
  };

  // Define link appearance
  const getLinkColor = (link: GraphLink) => {
    if (highlightLinks.size && ![...highlightLinks].some(highlightLink => 
      (typeof highlightLink.source === typeof link.source && 
       typeof highlightLink.target === typeof link.target &&
       (typeof link.source === 'string' ? 
        link.source === highlightLink.source : 
        link.source.id === (highlightLink.source as GraphNode).id) &&
       (typeof link.target === 'string' ? 
        link.target === highlightLink.target : 
        link.target.id === (highlightLink.target as GraphNode).id)
      ))) {
      return 'rgba(200, 200, 200, 0.15)'; // Faded color for non-highlighted links
    }
    
    if (link.type === 'address') return '#64B5F6';
    if (link.type === 'pattern') return '#FFB74D';
    if (link.type === 'derived') return '#81C784';
    if (link.type === 'similarity') return '#E57373';
    return '#B0BEC5'; // Default color
  };

  const getLinkWidth = (link: GraphLink) => {
    const baseWidth = link.value || 1;
    return baseWidth * linkStrengthMultiplier;
  };

  return (
    <Card 
      className={`overflow-hidden mb-6 relative ${isFullscreen ? 'fixed inset-0 z-50 m-0' : ''}`}
      ref={containerRef}
    >
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold flex items-center">
          <Network className="h-5 w-5 mr-2" />
          Advanced Signature Graph Visualization
        </h2>
        
        <div className="flex space-x-2">
          {!isFullscreen && (
            <Button 
              variant="outline" 
              size="sm"
              className="bg-white/10 hover:bg-white/20 text-white border-white/20"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? 'Collapse' : 'Expand'}
            </Button>
          )}
          
          <Button 
            variant="outline" 
            size="sm"
            className="bg-white/10 hover:bg-white/20 text-white border-white/20"
            onClick={toggleFullscreen}
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
        </div>
      </div>
      
      <div className={`transition-all duration-300 ease-in-out relative ${
        isFullscreen ? 'h-[calc(100vh-168px)]' : 
        isExpanded ? 'h-[600px]' : 'h-[400px]'
      }`}>
        {/* Graph visualization */}
        {graphData.nodes.length > 0 ? (
          <ForceGraph2D
            ref={graphRef}
            graphData={graphData}
            nodeId="id"
            nodeLabel={node => `${node.label}`}
            nodeColor={getNodeColor}
            nodeCanvasObject={paintNode}
            linkColor={getLinkColor}
            linkWidth={getLinkWidth}
            linkDirectionalParticles={2}
            linkDirectionalParticleWidth={link => highlightLinks.has(link as any) ? 2 : 0}
            linkDirectionalParticleSpeed={0.005}
            nodeRelSize={6}
            onNodeClick={handleNodeClick}
            cooldownTicks={100}
            onEngineStop={() => {
              graphRef.current?.zoomToFit(400, 40);
            }}
            d3AlphaDecay={0.02}
            d3VelocityDecay={0.3}
            warmupTicks={50}
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            {isLoading ? (
              <>
                <RefreshCw className="h-16 w-16 text-gray-300 mb-4 animate-spin" />
                <p className="text-gray-500 text-center">
                  Loading signature relationships...
                </p>
              </>
            ) : error ? (
              <>
                <X className="h-16 w-16 text-red-300 mb-4" />
                <p className="text-red-500 text-center">
                  Failed to load visualization data.
                  <br />
                  {(error as any)?.message || 'Unknown error'}
                </p>
              </>
            ) : (
              <>
                <Network className="h-16 w-16 text-gray-300 mb-4" />
                <p className="text-gray-500 text-center">
                  No signature data to visualize.
                  <br />
                  Start an analysis to see signature relationships.
                </p>
              </>
            )}
          </div>
        )}
        
        {/* Controls panel */}
        {graphData.nodes.length > 0 && (
          <div className="absolute bottom-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg border p-3 w-64">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-2 mb-2">
                <TabsTrigger value="controls">Controls</TabsTrigger>
                <TabsTrigger value="filter">Filter</TabsTrigger>
              </TabsList>
              
              <TabsContent value="controls" className="space-y-3">
                <div className="flex justify-between gap-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" size="sm" onClick={handleResetView}>
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Reset View</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" size="sm" onClick={handleZoomIn}>
                          <ZoomIn className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Zoom In</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" size="sm" onClick={handleZoomOut}>
                          <ZoomOut className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Zoom Out</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" size="sm" onClick={exportGraphImage}>
                          <Download className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Export as Image</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                
                <div>
                  <Label className="text-xs block mb-1">Node Size</Label>
                  <Slider
                    value={[nodeSizeMultiplier]}
                    min={0.5}
                    max={3}
                    step={0.1}
                    onValueChange={values => setNodeSizeMultiplier(values[0])}
                  />
                </div>
                
                <div>
                  <Label className="text-xs block mb-1">Link Strength</Label>
                  <Slider
                    value={[linkStrengthMultiplier]}
                    min={0.5}
                    max={3}
                    step={0.1}
                    onValueChange={values => setLinkStrengthMultiplier(values[0])}
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="filter" className="space-y-3">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="pl-10 pr-4 py-2 w-full text-sm bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md"
                    placeholder="Search nodes..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <div className="space-y-1">
                  <Label className="text-xs block mb-1">Node Type</Label>
                  <div className="flex flex-wrap gap-1">
                    <Badge 
                      variant={graphFilter === 'all' ? 'default' : 'outline'} 
                      className="cursor-pointer"
                      onClick={() => setGraphFilter('all')}
                    >
                      All
                    </Badge>
                    {graphData.groups.map(group => (
                      <Badge 
                        key={group.id}
                        variant={graphFilter === group.id ? 'default' : 'outline'} 
                        className="cursor-pointer"
                        onClick={() => setGraphFilter(group.id)}
                        style={{ 
                          backgroundColor: graphFilter === group.id ? group.color : 'transparent',
                          color: graphFilter === group.id ? 'white' : undefined,
                          borderColor: group.color
                        }}
                      >
                        {group.name}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                {selectedNode && (
                  <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                    <Label className="text-xs block mb-1">Selected Node</Label>
                    <div className="text-sm font-medium">{selectedNode.label}</div>
                    <div className="text-xs text-gray-500">
                      Type: {selectedNode.type.charAt(0).toUpperCase() + selectedNode.type.slice(1)}
                    </div>
                    {selectedNode.confidence && (
                      <div className="text-xs text-gray-500">
                        Confidence: {selectedNode.confidence}%
                      </div>
                    )}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div className="px-6 py-3 bg-gray-50 dark:bg-gray-800 border-t">
        <div className="flex justify-between items-center flex-wrap gap-2">
          <div className="flex flex-wrap gap-2">
            {graphData.groups.map(group => (
              <Badge 
                key={group.id}
                className="cursor-pointer"
                style={{ backgroundColor: group.color }}
                onClick={() => setGraphFilter(graphFilter === group.id ? 'all' : group.id)}
              >
                {group.name}
              </Badge>
            ))}
          </div>
          
          <div className="text-xs text-gray-500">
            {graphData.nodes.length} nodes, {graphData.links.length} links
          </div>
        </div>
      </div>
    </Card>
  );
};

export default SignatureGraphVisualization;