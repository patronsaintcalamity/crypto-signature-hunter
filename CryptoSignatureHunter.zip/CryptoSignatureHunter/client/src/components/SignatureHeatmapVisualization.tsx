import React, { useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';
import { ThermometerIcon, Download, RefreshCw, Search, EyeOff, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import * as d3 from 'd3';

interface HeatmapTransaction {
  id: string;
  txid: string;
  address: string;
  patternId?: string | null;
  r?: string;
  s?: string;
  z?: string;
}

interface SignatureHeatmapVisualizationProps {
  transactions: HeatmapTransaction[];
}

// Extracts a particular byte from a hex string
const extractByteAt = (hexString: string, bytePosition: number): string => {
  if (!hexString) return '';
  const startPos = bytePosition * 2;
  return hexString.substring(startPos, startPos + 2);
};

// Define heat map color scale
const getColorScale = (mode: 'rainbow' | 'heatmap' | 'binary', min: number, max: number) => {
  if (mode === 'rainbow') {
    return d3.scaleSequential(d3.interpolateRainbow)
      .domain([min, max]);
  } else if (mode === 'binary') {
    return d3.scaleOrdinal<string>()
      .domain([min.toString(), max.toString()])
      .range(['#e0e0e0', '#1976D2']);
  } else {
    return d3.scaleSequential(d3.interpolateYlOrRd)
      .domain([min, max]);
  }
};

// Convert hex to decimal
const hexToDec = (hex: string): number => parseInt(hex, 16);

// Simple hash function for consistent colors
const simpleHash = (str: string): number => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
};

const SignatureHeatmapVisualization: React.FC<SignatureHeatmapVisualizationProps> = ({
  transactions
}) => {
  const { toast } = useToast();
  const [selectedComponent, setSelectedComponent] = useState<'r' | 's' | 'z'>('r');
  const [colorMode, setColorMode] = useState<'rainbow' | 'heatmap' | 'binary'>('heatmap');
  const [gridSize, setGridSize] = useState<number>(24);
  const [showLabels, setShowLabels] = useState<boolean>(true);
  const [byteRange, setByteRange] = useState<[number, number]>([0, 31]);
  const [searchPattern, setSearchPattern] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const svgRef = useRef<SVGSVGElement>(null);
  
  // Effects for rendering the visualization
  useEffect(() => {
    if (!transactions.length) return;
    
    const validTransactions = transactions.filter(tx => tx[selectedComponent]);
    if (!validTransactions.length) return;
    
    renderHeatmap(validTransactions);
  }, [transactions, selectedComponent, colorMode, gridSize, showLabels, byteRange, searchPattern]);
  
  const renderHeatmap = (validTransactions: typeof transactions) => {
    setIsLoading(true);
    
    // Allow a small delay for loading state
    setTimeout(() => {
      if (!svgRef.current) return;
      
      // Clear previous visualization
      d3.select(svgRef.current).selectAll('*').remove();
      
      const svg = d3.select(svgRef.current);
      const width = svgRef.current.clientWidth || 800;
      const height = Math.max(500, validTransactions.length * gridSize / 2);
      
      svg.attr('width', width).attr('height', height);
      
      // Define margins
      const margin = { top: 60, right: 30, bottom: 50, left: showLabels ? 150 : 50 };
      const innerWidth = width - margin.left - margin.right;
      const innerHeight = height - margin.top - margin.bottom;
      
      // Create a group for the visualization
      const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);
      
      // Set range for bytes to display
      const [startByte, endByte] = byteRange;
      const bytesToShow = endByte - startByte + 1;
      
      // Create scales
      const xScale = d3.scaleBand()
        .domain([...Array(bytesToShow).keys()].map(i => (i + startByte).toString()))
        .range([0, innerWidth])
        .padding(0.1);
        
      const yScale = d3.scaleBand()
        .domain(validTransactions.map(tx => tx.id))
        .range([0, innerHeight])
        .padding(0.1);
      
      // Extract all byte values for coloring
      const allByteValues: number[] = [];
      validTransactions.forEach(tx => {
        const sigComponent = tx[selectedComponent];
        if (sigComponent) {
          for (let i = startByte; i <= endByte; i++) {
            const byteHex = extractByteAt(sigComponent, i);
            if (byteHex) {
              allByteValues.push(hexToDec(byteHex));
            }
          }
        }
      });
      
      // Define color scale based on min/max values
      const min = Math.min(...allByteValues);
      const max = Math.max(...allByteValues);
      const colorScale = getColorScale(colorMode, min, max);
      
      // Create groups for transactions (rows)
      const rows = g.selectAll('.tx-row')
        .data(validTransactions)
        .enter()
        .append('g')
        .attr('class', 'tx-row')
        .attr('transform', d => `translate(0,${yScale(d.id)!})`);
      
      // Filter function for search highlight
      const matchesSearch = (byteHex: string): boolean => {
        if (!searchPattern) return false;
        return byteHex.toLowerCase().includes(searchPattern.toLowerCase());
      };
      
      // Add cell for each byte
      rows.each(function(tx) {
        const sigComponent = tx[selectedComponent];
        if (!sigComponent) return;
        
        const row = d3.select(this);
        
        for (let i = startByte; i <= endByte; i++) {
          const byteHex = extractByteAt(sigComponent, i);
          if (byteHex) {
            const byteValue = hexToDec(byteHex);
            const cellWidth = xScale.bandwidth();
            const cellHeight = yScale.bandwidth();
            
            const hasHighlight = matchesSearch(byteHex);
            
            // Create cell rect
            row.append('rect')
              .attr('x', xScale((i - startByte + startByte).toString())!)
              .attr('width', cellWidth)
              .attr('height', cellHeight)
              .attr('fill', colorScale(byteValue))
              .attr('stroke', hasHighlight ? '#FF5722' : 'none')
              .attr('stroke-width', hasHighlight ? 2 : 0)
              .attr('data-byte-value', byteHex)
              .attr('data-byte-position', i)
              .attr('class', hasHighlight ? 'highlighted' : '')
              .on('mouseover', function(event) {
                // Show tooltip
                const tooltip = d3.select('#heatmap-tooltip');
                tooltip.style('display', 'block')
                  .style('left', `${event.pageX + 10}px`)
                  .style('top', `${event.pageY + 10}px`)
                  .html(`
                    <div class="font-mono">
                      <div>TX: ${tx.txid.substring(0, 8)}...</div>
                      <div>Byte ${i}: 0x${byteHex} (${byteValue})</div>
                      <div>Address: ${tx.address.substring(0, 8)}...</div>
                    </div>
                  `);
                
                // Highlight cell
                d3.select(this)
                  .attr('stroke', '#FF5722')
                  .attr('stroke-width', 2);
              })
              .on('mouseout', function() {
                // Hide tooltip
                d3.select('#heatmap-tooltip').style('display', 'none');
                
                // Remove highlight if not part of search
                if (!hasHighlight) {
                  d3.select(this)
                    .attr('stroke', 'none')
                    .attr('stroke-width', 0);
                }
              });
            
            // Add text label inside cells if large enough
            if (cellWidth >= 20 && cellHeight >= 20) {
              row.append('text')
                .attr('x', xScale((i - startByte + startByte).toString())! + cellWidth / 2)
                .attr('y', cellHeight / 2)
                .attr('dy', '.35em')
                .attr('text-anchor', 'middle')
                .attr('fill', byteValue > 200 ? '#000' : '#fff')
                .attr('font-size', '10px')
                .text(byteHex);
            }
          }
        }
      });
      
      // Add y axis labels (transaction ids)
      if (showLabels) {
        g.append('g')
          .attr('class', 'y-axis')
          .selectAll('text')
          .data(validTransactions)
          .enter()
          .append('text')
          .attr('x', -5)
          .attr('y', d => yScale(d.id)! + yScale.bandwidth() / 2)
          .attr('text-anchor', 'end')
          .attr('alignment-baseline', 'middle')
          .attr('font-size', '10px')
          .attr('cursor', 'pointer')
          .text(d => {
            if (d.txid.length > 16) {
              return `${d.txid.substring(0, 6)}...${d.txid.substring(d.txid.length - 4)}`;
            }
            return d.txid;
          })
          .on('click', (_, d) => {
            toast({
              title: "Transaction Details",
              description: `Transaction ID: ${d.txid}\nAddress: ${d.address}\nSignature ${selectedComponent.toUpperCase()}-value: ${d[selectedComponent]?.substring(0, 20)}...`,
              duration: 5000
            });
          });
      }
      
      // Add x axis (byte positions)
      g.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(d3.axisBottom(xScale).tickFormat(d => `${+d + startByte}`));
      
      // Add title
      g.append('text')
        .attr('x', innerWidth / 2)
        .attr('y', -30)
        .attr('text-anchor', 'middle')
        .attr('font-size', '16px')
        .attr('font-weight', 'bold')
        .text(`Signature ${selectedComponent.toUpperCase()}-Value Byte Patterns`);
        
      // Add x-axis label
      g.append('text')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight + 40)
        .attr('text-anchor', 'middle')
        .text('Byte Position');
        
      // Add color legend
      if (colorMode !== 'binary') {
        const legendWidth = innerWidth / 3;
        const legendHeight = 20;
        const legendX = innerWidth - legendWidth;
        const legendY = -50;
        
        // Create gradient
        const defs = svg.append('defs');
        const gradient = defs.append('linearGradient')
          .attr('id', 'legend-gradient')
          .attr('x1', '0%')
          .attr('x2', '100%')
          .attr('y1', '0%')
          .attr('y2', '0%');
          
        // Set gradient colors
        const numStops = 10;
        for (let i = 0; i < numStops; i++) {
          const offset = `${i / (numStops - 1) * 100}%`;
          const value = min + (i / (numStops - 1)) * (max - min);
          gradient.append('stop')
            .attr('offset', offset)
            .attr('stop-color', colorScale(value));
        }
        
        // Draw legend rectangle
        g.append('rect')
          .attr('x', legendX)
          .attr('y', legendY)
          .attr('width', legendWidth)
          .attr('height', legendHeight)
          .style('fill', 'url(#legend-gradient)');
          
        // Add legend labels
        g.append('text')
          .attr('x', legendX)
          .attr('y', legendY - 5)
          .attr('text-anchor', 'start')
          .attr('font-size', '12px')
          .text(`${min} (0x${min.toString(16).padStart(2, '0')})`);
          
        g.append('text')
          .attr('x', legendX + legendWidth)
          .attr('y', legendY - 5)
          .attr('text-anchor', 'end')
          .attr('font-size', '12px')
          .text(`${max} (0x${max.toString(16).padStart(2, '0')})`);
          
        g.append('text')
          .attr('x', legendX + legendWidth / 2)
          .attr('y', legendY - 5)
          .attr('text-anchor', 'middle')
          .attr('font-size', '12px')
          .text('Byte Value');
      }
      
      setIsLoading(false);
    }, 10);
  };

  const exportSvg = () => {
    if (!svgRef.current) return;
    
    try {
      // Get SVG element
      const svgData = new XMLSerializer().serializeToString(svgRef.current);
      const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const svgUrl = URL.createObjectURL(svgBlob);
      
      // Create download link
      const downloadLink = document.createElement('a');
      downloadLink.href = svgUrl;
      downloadLink.download = `signature-${selectedComponent}-heatmap.svg`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      
      toast({
        title: "Export Successful",
        description: "Heatmap visualization has been exported as SVG",
        duration: 3000
      });
    } catch (err) {
      toast({
        title: "Export Failed",
        description: "Failed to export heatmap: " + (err instanceof Error ? err.message : String(err)),
        variant: "destructive"
      });
    }
  };

  // Handler for byte range change
  const handleByteRangeChange = (values: number[]) => {
    setByteRange([values[0], values[1]]);
  };

  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold flex items-center">
          <ThermometerIcon className="h-5 w-5 mr-2" />
          Signature Byte Heatmap Visualization
        </h2>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            className="bg-white/10 hover:bg-white/20 text-white border-white/20"
            onClick={exportSvg}
          >
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
        </div>
      </div>
      
      <div className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
          <div className="space-y-2">
            <Label>Signature Component</Label>
            <Tabs 
              value={selectedComponent} 
              onValueChange={(v) => setSelectedComponent(v as 'r' | 's' | 'z')}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="r">R Value</TabsTrigger>
                <TabsTrigger value="s">S Value</TabsTrigger>
                <TabsTrigger value="z">Z Value</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <div className="space-y-2">
            <Label>Color Mode</Label>
            <Tabs 
              value={colorMode} 
              onValueChange={(v) => setColorMode(v as 'rainbow' | 'heatmap' | 'binary')}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="heatmap">Heat</TabsTrigger>
                <TabsTrigger value="rainbow">Rainbow</TabsTrigger>
                <TabsTrigger value="binary">Binary</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <div className="space-y-2">
            <Label>Grid Size</Label>
            <Slider
              value={[gridSize]}
              min={12}
              max={36}
              step={4}
              onValueChange={values => setGridSize(values[0])}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Display Options</Label>
            <div className="flex items-center space-x-2">
              <Switch
                checked={showLabels}
                onCheckedChange={setShowLabels}
                id="show-labels"
              />
              <Label htmlFor="show-labels" className="cursor-pointer">
                {showLabels ? <Eye className="h-4 w-4 inline mr-1" /> : <EyeOff className="h-4 w-4 inline mr-1" />}
                Show Labels
              </Label>
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <Label>Byte Range (0-31)</Label>
          <div className="pt-4 px-4">
            <Slider
              value={byteRange}
              min={0}
              max={31}
              step={1}
              minStepsBetweenThumbs={1}
              onValueChange={handleByteRangeChange}
            />
            <div className="flex justify-between mt-1 text-xs text-gray-500">
              <span>Byte {byteRange[0]}</span>
              <span>Byte {byteRange[1]}</span>
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <Label>Search for Byte Pattern</Label>
          <div className="relative mt-1">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search for hex pattern (e.g. ff, 00, a4)"
              className="pl-10 pr-4 py-2 w-full text-sm bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md"
              value={searchPattern}
              onChange={e => setSearchPattern(e.target.value)}
            />
          </div>
        </div>
        
        <div className="relative overflow-auto" style={{ minHeight: '400px' }}>
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/80 dark:bg-gray-800/80 z-10">
              <RefreshCw className="h-8 w-8 text-primary animate-spin" />
            </div>
          )}
          
          {transactions.length === 0 ? (
            <div className="text-center py-12">
              <ThermometerIcon className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No signature data available for visualization.</p>
            </div>
          ) : (
            <>
              <svg ref={svgRef} className="w-full" />
              <div 
                id="heatmap-tooltip" 
                className="absolute hidden p-2 bg-white dark:bg-gray-800 shadow-lg rounded border border-gray-200 dark:border-gray-700 text-xs z-20"
              />
            </>
          )}
        </div>
      </div>
      
      <div className="px-6 py-3 bg-gray-50 dark:bg-gray-800 border-t">
        <div className="flex flex-wrap gap-2">
          <Badge className="bg-[#ffffb2]">
            <div className="w-2 h-2 rounded-full mr-1 inline-block" style={{ backgroundColor: '#ffffb2' }}></div>
            Low Value
          </Badge>
          <Badge className="bg-[#fed976]">
            <div className="w-2 h-2 rounded-full mr-1 inline-block" style={{ backgroundColor: '#fed976' }}></div>
            Medium-Low
          </Badge>
          <Badge className="bg-[#fd8d3c]">
            <div className="w-2 h-2 rounded-full mr-1 inline-block" style={{ backgroundColor: '#fd8d3c' }}></div>
            Medium
          </Badge>
          <Badge className="bg-[#e31a1c]">
            <div className="w-2 h-2 rounded-full mr-1 inline-block" style={{ backgroundColor: '#e31a1c' }}></div>
            High Value
          </Badge>
          {searchPattern && (
            <Badge className="border-2 border-[#FF5722] bg-transparent text-primary dark:text-primary-foreground">
              Search Highlighted
            </Badge>
          )}
        </div>
      </div>
    </Card>
  );
};

export default SignatureHeatmapVisualization;