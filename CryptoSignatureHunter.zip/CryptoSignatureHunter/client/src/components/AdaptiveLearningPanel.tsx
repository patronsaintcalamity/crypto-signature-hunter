import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Brain, Zap, Settings, ChevronDown, 
  CheckCircle, XCircle, HelpCircle, RefreshCw, BrainCircuit 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

interface AdaptiveLearningPanelProps {
  patterns: Array<{
    id: string;
    name: string;
    confidence: number;
    nonceReconstructed?: boolean;
  }>;
  keys?: Array<{
    id: string;
    verification: string;
    patternId: string;
  }>;
  onTrainingComplete?: (improvements: Array<{
    patternId: string;
    oldConfidence: number;
    newConfidence: number;
  }>) => void;
}

const AdaptiveLearningPanel: React.FC<AdaptiveLearningPanelProps> = ({
  patterns,
  keys = [],
  onTrainingComplete
}) => {
  const { toast } = useToast();
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState(0);
  const [trainingResults, setTrainingResults] = useState<Array<{
    patternId: string;
    patternName: string;
    oldConfidence: number;
    newConfidence: number;
    improvement: number;
  }>>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // Training settings
  const [settings, setSettings] = useState({
    useSuccessfulPatterns: true,
    useFailedPatterns: true,
    aggressiveTraining: false,
    updatePatternWeights: true,
    useAI: true
  });
  
  const handleSettingChange = (setting: keyof typeof settings) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };
  
  // Calculate training data
  const getTrainingData = () => {
    // Check for patterns with successful key derivation
    const patternsWithKeys = keys
      .filter(key => key.verification === 'confirmed')
      .map(key => key.patternId);
    
    const successfulPatterns = settings.useSuccessfulPatterns ? 
      patterns.filter(pattern => patternsWithKeys.includes(pattern.id)) : [];
    
    // Patterns with attempted but failed key derivation
    const attemptedButFailedPatterns = settings.useFailedPatterns ?
      patterns.filter(pattern => 
        pattern.nonceReconstructed && 
        !patternsWithKeys.includes(pattern.id)
      ) : [];
    
    return {
      successfulPatterns,
      failedPatterns: attemptedButFailedPatterns,
      totalTrainingPatterns: successfulPatterns.length + attemptedButFailedPatterns.length
    };
  };
  
  const { successfulPatterns, failedPatterns, totalTrainingPatterns } = getTrainingData();
  
  const startTraining = async () => {
    if (totalTrainingPatterns === 0) {
      toast({
        title: "Training Error",
        description: "No valid patterns for training. Need successful or failed key derivation attempts.",
        variant: "destructive"
      });
      return;
    }
    
    setIsTraining(true);
    setTrainingProgress(0);
    
    try {
      // Start progress animation
      const progressInterval = setInterval(() => {
        setTrainingProgress(prev => {
          if (prev >= 95) {
            return 95; // Cap at 95% until we get actual results
          }
          return prev + 5;
        });
      }, 200);
      
      // Call the API to perform adaptive learning
      const response = await fetch('/api/adaptive-learning/train', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patterns,
          settings,
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to apply adaptive learning');
      }
      
      // Get the results and set to 100%
      const data = await response.json();
      clearInterval(progressInterval);
      setTrainingProgress(100);
      
      // Process the results
      if (data.success && data.results) {
        setTrainingResults(data.results.map((result: any) => ({
          patternId: result.patternId,
          patternName: patterns.find(p => p.id === result.patternId)?.name || `Pattern ${result.patternId}`,
          oldConfidence: result.oldConfidence,
          newConfidence: result.newConfidence,
          improvement: result.improvement
        })));
        
        // Call the callback if provided
        if (onTrainingComplete) {
          onTrainingComplete(data.results);
        }
        
        toast({
          title: "Training Complete",
          description: `Adaptive learning improved ${data.results.length} pattern confidence scores`,
        });
      } else {
        throw new Error('No results returned from adaptive learning');
      }
    } catch (error) {
      toast({
        title: "Training Error",
        description: error instanceof Error ? error.message : "Failed to apply adaptive learning",
        variant: "destructive"
      });
      
      // Reset state on error
      setTrainingProgress(0);
    } finally {
      setIsTraining(false);
    }
  };
  
  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold flex items-center">
          <BrainCircuit className="h-5 w-5 mr-2" />
          Adaptive Learning System
        </h2>
        
        <Button 
          variant="outline" 
          size="sm"
          className="bg-white/10 hover:bg-white/20 text-white border-white/20"
          onClick={() => setShowAdvanced(!showAdvanced)}
        >
          <Settings className="h-4 w-4 mr-1" />
          Settings
          <ChevronDown className={`h-4 w-4 ml-1 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
        </Button>
      </div>
      
      {showAdvanced && (
        <div className="px-6 py-3 bg-gray-50 dark:bg-gray-800 border-b">
          <h3 className="text-sm font-medium mb-3">Learning Parameters</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Switch 
                id="use-successful" 
                checked={settings.useSuccessfulPatterns}
                onCheckedChange={() => handleSettingChange('useSuccessfulPatterns')}
              />
              <Label htmlFor="use-successful" className="text-sm">Learn from successful patterns</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="use-failed" 
                checked={settings.useFailedPatterns}
                onCheckedChange={() => handleSettingChange('useFailedPatterns')}
              />
              <Label htmlFor="use-failed" className="text-sm">Learn from failed attempts</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="aggressive" 
                checked={settings.aggressiveTraining}
                onCheckedChange={() => handleSettingChange('aggressiveTraining')}
              />
              <Label htmlFor="aggressive" className="text-sm">Aggressive training mode</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="update-weights" 
                checked={settings.updatePatternWeights}
                onCheckedChange={() => handleSettingChange('updatePatternWeights')}
              />
              <Label htmlFor="update-weights" className="text-sm">Update pattern weights</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="use-ai" 
                checked={settings.useAI}
                onCheckedChange={() => handleSettingChange('useAI')}
              />
              <Label htmlFor="use-ai" className="text-sm">Use AI enhancement</Label>
            </div>
          </div>
        </div>
      )}
      
      <div className="px-6 py-6">
        <div className="flex flex-col items-center mb-6">
          <div className="bg-indigo-50 dark:bg-indigo-950/30 p-4 rounded-full mb-4">
            <Brain className="h-12 w-12 text-indigo-600 dark:text-indigo-400" />
          </div>
          
          <h3 className="text-lg font-medium mb-1">Pattern Recognition Training</h3>
          <p className="text-sm text-gray-500 text-center mb-4">
            Improve pattern detection by learning from successful key derivations
          </p>
          
          {isTraining ? (
            <div className="w-full max-w-md mb-4">
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Training in progress...</span>
                <span className="text-sm">{trainingProgress}%</span>
              </div>
              <Progress value={trainingProgress} className="h-2" />
            </div>
          ) : (
            <div className="flex flex-col sm:flex-row gap-4 mb-4 w-full max-w-md">
              <Button 
                className="bg-indigo-600 hover:bg-indigo-700 text-white flex-1"
                onClick={startTraining}
                disabled={patterns.length === 0 || totalTrainingPatterns === 0}
              >
                <Zap className="h-4 w-4 mr-2" />
                Start Training
              </Button>
              
              <Button 
                variant="outline" 
                className="border-indigo-200 text-indigo-600 hover:bg-indigo-50 flex-1"
                disabled={true}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Auto-Train
              </Button>
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 flex flex-col items-center">
              <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
              <div className="text-2xl font-bold mb-1">{successfulPatterns.length}</div>
              <div className="text-sm text-center text-gray-600 dark:text-gray-300">Successful Patterns</div>
            </div>
            
            <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4 flex flex-col items-center">
              <XCircle className="h-8 w-8 text-red-500 mb-2" />
              <div className="text-2xl font-bold mb-1">{failedPatterns.length}</div>
              <div className="text-sm text-center text-gray-600 dark:text-gray-300">Failed Patterns</div>
            </div>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 flex flex-col items-center">
              <HelpCircle className="h-8 w-8 text-blue-500 mb-2" />
              <div className="text-2xl font-bold mb-1">{patterns.length - totalTrainingPatterns}</div>
              <div className="text-sm text-center text-gray-600 dark:text-gray-300">Untested Patterns</div>
            </div>
          </div>
        </div>
        
        {trainingResults.length > 0 && (
          <div className="mt-6">
            <h3 className="text-md font-medium mb-3">Training Results</h3>
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 max-h-[300px] overflow-y-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-gray-500">
                    <th className="pb-2">Pattern</th>
                    <th className="pb-2">Before</th>
                    <th className="pb-2">After</th>
                    <th className="pb-2">Change</th>
                  </tr>
                </thead>
                <tbody>
                  {trainingResults.map((result, index) => (
                    <tr key={index} className="border-t border-gray-200 dark:border-gray-700">
                      <td className="py-2 text-sm">{result.patternName}</td>
                      <td className="py-2 text-sm">{result.oldConfidence}%</td>
                      <td className="py-2 text-sm">{result.newConfidence}%</td>
                      <td className="py-2 text-sm">
                        <span className={`font-medium ${
                          result.improvement > 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {result.improvement > 0 ? '+' : ''}{result.improvement}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
      
      <div className="px-6 py-3 bg-gray-50 dark:bg-gray-800 border-t">
        <div className="text-sm text-gray-500">
          {patterns.length > 0 ? (
            <div className="flex justify-between">
              <span>Pattern Model: v1.0.0</span>
              <span>Available Training Data: {totalTrainingPatterns}/{patterns.length} patterns</span>
            </div>
          ) : (
            <div className="text-center">
              Start an analysis to unlock adaptive learning capabilities
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default AdaptiveLearningPanel;