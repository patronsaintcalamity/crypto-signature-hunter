import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Upload, X, Copy, FileText } from 'lucide-react';

interface InputPanelProps {
  onStartAnalysis: (params: AnalysisParams) => void;
  isAnalysisRunning: boolean;
}

export interface AnalysisParams {
  address: string;
  files: File[];
  speedLevel: number;
  usePartialNonce: boolean;
  usePatternRecognition: boolean;
  useAI: boolean;
  patternDepth: number;
}

const InputPanel: React.FC<InputPanelProps> = ({ onStartAnalysis, isAnalysisRunning }) => {
  const { toast } = useToast();
  const [address, setAddress] = useState<string>('');
  const [files, setFiles] = useState<File[]>([]);
  const [speedLevel, setSpeedLevel] = useState<number>(3);
  const [speedMode, setSpeedMode] = useState<string>('Balanced');
  const [usePartialNonce, setUsePartialNonce] = useState<boolean>(false);
  const [usePatternRecognition, setUsePatternRecognition] = useState<boolean>(true);
  const [useAI, setUseAI] = useState<boolean>(true);
  const [patternDepth, setPatternDepth] = useState<string>('4');
  const [isFetching, setIsFetching] = useState<boolean>(false);

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAddress(e.target.value);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles([...files, ...newFiles]);
    }
  };

  const handleRemoveFile = (index: number) => {
    const newFiles = [...files];
    newFiles.splice(index, 1);
    setFiles(newFiles);
  };

  const handleSliderChange = (value: number[]) => {
    const level = value[0];
    setSpeedLevel(level);
    
    let mode = 'Balanced';
    if (level === 1) mode = 'Fastest';
    else if (level === 2) mode = 'Fast';
    else if (level === 4) mode = 'Thorough';
    else if (level === 5) mode = 'Most Thorough';
    
    setSpeedMode(mode);
  };

  const handleFetchAddress = async () => {
    if (!address) {
      toast({
        title: "Address is required",
        description: "Please enter a Bitcoin address",
        variant: "destructive",
      });
      return;
    }

    setIsFetching(true);
    try {
      const res = await apiRequest('GET', `/api/transactions/fetch?address=${address}`, undefined);
      const data = await res.json();
      toast({
        title: "Transactions fetched",
        description: `Found ${data.count} transactions for analysis`,
      });
    } catch (error) {
      toast({
        title: "Error fetching transactions",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsFetching(false);
    }
  };

  const handleStartAnalysis = () => {
    if (!address && files.length === 0) {
      toast({
        title: "Input required",
        description: "Please enter a Bitcoin address or upload transaction files",
        variant: "destructive",
      });
      return;
    }

    const params: AnalysisParams = {
      address,
      files,
      speedLevel,
      usePartialNonce,
      usePatternRecognition,
      useAI,
      patternDepth: parseInt(patternDepth),
    };

    onStartAnalysis(params);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      const newFiles = Array.from(e.dataTransfer.files);
      setFiles([...files, ...newFiles]);
    }
  };

  return (
    <div className="lg:col-span-1">
      <div className="sticky top-8">
        <Card className="overflow-hidden mb-6">
          <div className="bg-primary text-white px-6 py-4">
            <h2 className="text-lg font-semibold">Input Data</h2>
          </div>
          <CardContent className="p-6">
            {/* Address Input */}
            <div className="mb-6">
              <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-2">
                Bitcoin Public Address
              </label>
              <div className="flex">
                <Input
                  id="address"
                  value={address}
                  onChange={handleAddressChange}
                  className="rounded-r-none"
                  placeholder="Enter Bitcoin address"
                />
                <Button 
                  onClick={handleFetchAddress} 
                  disabled={isFetching} 
                  className="rounded-l-none"
                >
                  {isFetching ? 'Fetching...' : 'Fetch'}
                </Button>
              </div>
              <p className="text-xs text-mid-gray mt-1">Pulls transaction history from Bitcoin mainnet</p>
            </div>

            {/* File Upload */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Transaction Files</label>
              <div 
                className="border-2 border-dashed border-light-gray rounded-md px-6 py-8 text-center"
                onDragOver={handleDragOver}
                onDrop={handleDrop}
              >
                <Upload className="mx-auto h-12 w-12 text-mid-gray" />
                <div className="mt-2">
                  <p className="text-sm text-mid-gray">Drag & drop files or</p>
                  <label className="relative cursor-pointer">
                    <span className="mt-2 inline-block text-sm font-medium text-secondary hover:text-blue-600">
                      Browse files
                    </span>
                    <input type="file" className="sr-only" multiple onChange={handleFileChange} />
                  </label>
                </div>
                <p className="text-xs text-mid-gray mt-1">
                  Accepts .json, .csv files with r,s,z,pubkey signature data
                </p>
              </div>
              
              {files.length > 0 && (
                <div className="mt-4 text-sm">
                  {files.map((file, index) => (
                    <div key={index} className="bg-background rounded-md p-3 mb-2 flex justify-between items-center">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-secondary mr-2" />
                        <span>{file.name}</span>
                      </div>
                      <button 
                        onClick={() => handleRemoveFile(index)} 
                        className="text-error hover:text-red-700"
                      >
                        <X className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Analysis Controls */}
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Analysis Controls</h3>
              
              {/* Speed/Thoroughness Slider */}
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <label htmlFor="analysis-speed" className="text-xs font-medium text-gray-700">
                    Speed vs. Thoroughness
                  </label>
                  <span className="text-xs px-2 py-1 bg-secondary text-white rounded-full">
                    {speedMode}
                  </span>
                </div>
                <div className="relative">
                  <Slider
                    id="analysis-speed"
                    min={1}
                    max={5}
                    step={1}
                    value={[speedLevel]}
                    onValueChange={handleSliderChange}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-mid-gray mt-1">
                    <span>Faster</span>
                    <span>Balanced</span>
                    <span>Thorough</span>
                  </div>
                </div>
              </div>

              {/* Brute Force Options */}
              <div className="mb-4">
                <label className="text-xs font-medium text-gray-700 mb-2 block">Brute Force Options</label>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox 
                      id="brute-partial" 
                      checked={usePartialNonce} 
                      onCheckedChange={(checked) => setUsePartialNonce(checked === true)}
                    />
                    <label htmlFor="brute-partial" className="ml-2 text-xs text-gray-700">
                      Partial Nonce Recovery
                    </label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox 
                      id="brute-pattern" 
                      checked={usePatternRecognition} 
                      onCheckedChange={(checked) => setUsePatternRecognition(checked === true)}
                    />
                    <label htmlFor="brute-pattern" className="ml-2 text-xs text-gray-700">
                      Pattern Recognition
                    </label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox 
                      id="brute-ai" 
                      checked={useAI} 
                      onCheckedChange={(checked) => setUseAI(checked === true)}
                    />
                    <label htmlFor="brute-ai" className="ml-2 text-xs text-gray-700">
                      AI-Enhanced Analysis
                    </label>
                  </div>
                </div>
              </div>

              {/* Pattern Recognition */}
              <div className="mb-6">
                <label className="text-xs font-medium text-gray-700 mb-2 block">
                  Pattern Recognition Depth
                </label>
                <Select value={patternDepth} onValueChange={setPatternDepth}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select pattern depth" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">Minimal (3 character groups)</SelectItem>
                    <SelectItem value="4">Standard (4 character groups)</SelectItem>
                    <SelectItem value="5">Deep (5 character groups)</SelectItem>
                    <SelectItem value="6">Custom (6+ character groups)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                className="w-full py-6 bg-secondary hover:bg-blue-600"
                onClick={handleStartAnalysis}
                disabled={isAnalysisRunning}
              >
                <Copy className="h-5 w-5 mr-2" />
                {isAnalysisRunning ? 'Analysis Running...' : 'Start Analysis'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InputPanel;
