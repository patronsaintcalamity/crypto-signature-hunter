import React, { useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';
import { ChevronDown, RefreshCw, TrendingUp, Network, Fingerprint, Share2, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

interface Node {
  id: string;
  name: string;
  type: 'transaction' | 'pattern' | 'address' | 'nonce';
  value: number;
  color?: string;
  userData?: {
    r?: string;
    s?: string;
    z?: string;
    confidence?: number;
    patternId?: string;
  };
}

interface Link {
  source: string;
  target: string;
  value: number;
  color?: string;
  type?: 'signature' | 'pattern' | 'address' | 'derived';
}

interface SignatureFlowVisualizationProps {
  transactions: Array<{
    id: string;
    txid: string;
    address: string;
    r?: string;
    s?: string;
    z?: string;
    patternId?: string | null;
    patternName?: string | null;
    confidence?: number;
  }>;
  patterns: Array<{
    id: string;
    name: string;
    confidence: number;
    affectedAddresses: string[];
    nonceReconstructed?: boolean;
    nonceValue?: string | null;
  }>;
}

const SignatureFlowVisualization: React.FC<SignatureFlowVisualizationProps> = ({
  transactions,
  patterns
}) => {
  const { toast } = useToast();
  const [graphData, setGraphData] = useState<{ nodes: Node[], links: Link[] }>({ nodes: [], links: [] });
  const [isExpanded, setIsExpanded] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const graphRef = useRef<any>(null);
  
  // Generate graph data from transactions and patterns
  useEffect(() => {
    if (transactions.length === 0 && patterns.length === 0) return;
    
    // Generate nodes and links
    let nodes: Node[] = [];
    let links: Link[] = [];
    
    // Add transaction nodes
    transactions.forEach(tx => {
      const confidence = tx.confidence || 0;
      const color = getConfidenceColor(confidence);
      
      nodes.push({
        id: tx.id,
        name: `TX: ${tx.txid.substring(0, 6)}...`,
        type: 'transaction',
        value: 1,
        color,
        userData: {
          r: tx.r,
          s: tx.s,
          z: tx.z,
          confidence,
          patternId: tx.patternId || undefined
        }
      });
      
      // Add address node if not already added
      if (!nodes.some(n => n.id === tx.address)) {
        nodes.push({
          id: tx.address,
          name: `Addr: ${tx.address.substring(0, 6)}...`,
          type: 'address',
          value: 2,
          color: '#5C6BC0'
        });
      }
      
      // Link transaction to address
      links.push({
        source: tx.id,
        target: tx.address,
        value: 1,
        color: '#B0BEC5',
        type: 'address'
      });
    });
    
    // Add pattern nodes
    patterns.forEach(pattern => {
      const color = getConfidenceColor(pattern.confidence);
      
      nodes.push({
        id: `pattern-${pattern.id}`,
        name: pattern.name,
        type: 'pattern',
        value: 3,
        color
      });
      
      // Link patterns to transactions
      transactions.forEach(tx => {
        if (tx.patternId === pattern.id) {
          links.push({
            source: `pattern-${pattern.id}`,
            target: tx.id,
            value: 2,
            color: color,
            type: 'pattern'
          });
        }
      });
      
      // Add nonce nodes if available
      if (pattern.nonceReconstructed && pattern.nonceValue) {
        const nonceId = `nonce-${pattern.id}`;
        nodes.push({
          id: nonceId,
          name: `Nonce: ${pattern.nonceValue.substring(0, 6)}...`,
          type: 'nonce',
          value: 4,
          color: '#43A047'
        });
        
        links.push({
          source: nonceId,
          target: `pattern-${pattern.id}`,
          value: 3,
          color: '#43A047',
          type: 'derived'
        });
      }
    });
    
    // Group by pattern first
    const newGraphData = { nodes, links };
    setGraphData(newGraphData);
    
    // If the graph ref exists and has the zoom function, adjust zoom
    if (graphRef.current) {
      setTimeout(() => {
        graphRef.current.zoomToFit(500, 50);
      }, 500);
    }
  }, [transactions, patterns]);
  
  const getConfidenceColor = (confidence: number): string => {
    if (confidence >= 90) return '#43A047';  // High confidence - green
    if (confidence >= 50) return '#FB8C00';  // Medium confidence - orange
    return '#E53935';  // Low confidence - red
  };

  const handleNodeClick = (node: Node) => {
    // Display node info
    const nodeType = node.type.charAt(0).toUpperCase() + node.type.slice(1);
    const nodeInfo = `${nodeType}: ${node.name}\n${
      node.userData?.r ? `R: ${node.userData.r.substring(0, 10)}...\n` : ''
    }${
      node.userData?.s ? `S: ${node.userData.s.substring(0, 10)}...\n` : ''
    }${
      node.userData?.confidence ? `Confidence: ${node.userData.confidence}%\n` : ''
    }`;
    
    toast({
      title: `${nodeType} Information`,
      description: nodeInfo,
      duration: 5000
    });
  };
  
  const startAnimation = () => {
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 5000);
  };
  
  // Render a simplified visualization with connected cards
  const renderNode = (node: Node) => {
    const nodeClass = `relative p-3 rounded-lg shadow-md cursor-pointer border-2 text-sm font-medium mb-2 ${
      node.type === 'transaction' ? 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800' :
      node.type === 'address' ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' :
      node.type === 'pattern' ? 'bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800' :
      'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
    }`;

    const iconType = 
      node.type === 'transaction' ? <TrendingUp className="h-4 w-4" /> :
      node.type === 'address' ? <Fingerprint className="h-4 w-4" /> :
      node.type === 'pattern' ? <Share2 className="h-4 w-4" /> :
      <Key className="h-4 w-4" />;

    return (
      <div 
        key={node.id} 
        className={nodeClass}
        onClick={() => handleNodeClick(node)}
        style={{ borderColor: node.color }}
      >
        <div className="flex items-center gap-2">
          {iconType}
          <span>{node.name}</span>
        </div>
        {node.userData?.confidence && (
          <div className="mt-1 text-xs">
            Confidence: {node.userData.confidence}%
          </div>
        )}
      </div>
    );
  };

  return (
    <Card className="overflow-hidden mb-6">
      <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold flex items-center">
          <Network className="h-5 w-5 mr-2" />
          Signature Flow Visualization
        </h2>
        <Button 
          variant="outline" 
          size="sm"
          className="bg-white/10 hover:bg-white/20 text-white border-white/20"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? 'Collapse' : 'Expand'}
          <ChevronDown className={`h-4 w-4 ml-1 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
        </Button>
      </div>
      
      <div className={`p-4 transition-all duration-300 ease-in-out ${isExpanded ? 'max-h-[600px]' : 'max-h-[300px]'} overflow-auto`}>
        {graphData.nodes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <h3 className="font-medium text-sm mb-3 text-gray-500">Patterns ({
                graphData.nodes.filter(n => n.type === 'pattern').length
              })</h3>
              {graphData.nodes
                .filter(node => node.type === 'pattern')
                .map(node => renderNode(node))}
            </div>
            
            <div>
              <h3 className="font-medium text-sm mb-3 text-gray-500">Transactions ({
                graphData.nodes.filter(n => n.type === 'transaction').length
              })</h3>
              {graphData.nodes
                .filter(node => node.type === 'transaction')
                .map(node => renderNode(node))}
            </div>
            
            <div>
              <h3 className="font-medium text-sm mb-3 text-gray-500">Addresses & Nonces ({
                graphData.nodes.filter(n => n.type === 'address' || n.type === 'nonce').length
              })</h3>
              {graphData.nodes
                .filter(node => node.type === 'address' || node.type === 'nonce')
                .map(node => renderNode(node))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12">
            <Network className="h-16 w-16 text-gray-300 mb-4" />
            <p className="text-gray-500 text-center">
              No signature data to visualize. Start an analysis to see signature relationships.
            </p>
          </div>
        )}
      </div>
      
      <div className="px-6 py-2 bg-gray-50 dark:bg-slate-800 border-t">
        <div className="flex flex-wrap gap-3">
          <Badge className="bg-[#5C6BC0]">Address</Badge>
          <Badge className="bg-[#43A047]">High Confidence</Badge>
          <Badge className="bg-[#FB8C00]">Medium Confidence</Badge>
          <Badge className="bg-[#E53935]">Low Confidence</Badge>
          <Badge className="bg-[#43A047]">Nonce</Badge>
        </div>
      </div>
    </Card>
  );
};

export default SignatureFlowVisualization;