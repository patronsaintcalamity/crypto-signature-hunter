/**
 * Address Patterns Module
 * 
 * Analyzes Bitcoin address patterns to optimize key search:
 * - Address type detection (P2PKH, P2SH, Bech32)
 * - Key pattern identification
 * - Optimization strategies
 */

// SECP256K1 order (the maximum value a private key can have)
export const SECP256K1_ORDER = 'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141';

/**
 * Address type enumeration
 */
export enum AddressType {
  P2PKH = 'p2pkh',    // Legacy addresses starting with 1
  P2SH = 'p2sh',      // Script addresses starting with 3
  BECH32 = 'bech32',  // SegWit addresses starting with bc1
  UNKNOWN = 'unknown' // Unrecognized format
}

/**
 * Address information type
 */
export interface AddressInfo {
  address: string;
  type: AddressType;
  isCompressed: boolean;
  creationMethod?: string;
  hashFunction?: string;
  metadata?: Record<string, any>;
}

/**
 * Key search optimization parameters
 */
export interface KeySearchOptimizations {
  keyPrefixes?: string[];
  keyRanges?: Array<{ start: string; end: string }>;
  noncePatterns?: string[];
  signatureOptimizations?: Record<string, any>;
}

/**
 * Get address information from a Bitcoin address
 * @param address Bitcoin address to analyze
 * @returns Address information or null if invalid
 */
export function getAddressInfo(address: string): AddressInfo | null {
  // Validate input
  if (!address || typeof address !== 'string') {
    return null;
  }
  
  // Determine address type
  let type: AddressType;
  let isCompressed = false;
  let creationMethod: string | undefined;
  let hashFunction: string | undefined;
  
  if (address.startsWith('1')) {
    type = AddressType.P2PKH;
    isCompressed = address.length < 34; // Approximate heuristic
    hashFunction = 'RIPEMD160(SHA256)';
    creationMethod = 'Standard P2PKH';
  } else if (address.startsWith('3')) {
    type = AddressType.P2SH;
    isCompressed = true; // Usually compressed
    hashFunction = 'RIPEMD160(SHA256)';
    creationMethod = 'P2SH (possibly multisig)';
  } else if (address.startsWith('bc1')) {
    type = AddressType.BECH32;
    isCompressed = true; // Always compressed
    hashFunction = 'RIPEMD160(SHA256)';
    creationMethod = 'Bech32 SegWit';
  } else {
    type = AddressType.UNKNOWN;
  }
  
  return {
    address,
    type,
    isCompressed,
    creationMethod,
    hashFunction
  };
}

/**
 * Get key search optimizations for an address
 * @param address Bitcoin address to optimize for
 * @returns Key search optimizations
 */
export function getKeySearchOptimizations(address: string): KeySearchOptimizations {
  const addressInfo = getAddressInfo(address);
  
  if (!addressInfo) {
    return {};
  }
  
  const optimizations: KeySearchOptimizations = {
    keyPrefixes: [],
    keyRanges: [],
    noncePatterns: []
  };
  
  // Add type-specific optimizations
  switch (addressInfo.type) {
    case AddressType.P2PKH:
      // Legacy addresses
      if (isPotentiallyVulnerable(address)) {
        optimizations.keyPrefixes = ['00', '01', '02', '03', '04'];
        
        // Add specialized patterns
        const patterns = getSpecializedPatterns(address);
        if (patterns.length > 0) {
          optimizations.keyPrefixes.push(...patterns);
        }
      }
      break;
      
    case AddressType.P2SH:
      // Script hash addresses - usually need script scanning
      optimizations.signatureOptimizations = {
        multisigFocus: true,
        scriptPatterns: ['76a914', '5121'] // Common script patterns
      };
      break;
      
    case AddressType.BECH32:
      // SegWit addresses - usually more recent
      optimizations.keyRanges = [
        { start: '800000', end: 'FFFFFF' } // Upper range focus
      ];
      break;
  }
  
  return optimizations;
}

/**
 * Check if an address might be vulnerable to pattern-based attacks
 * @param address Bitcoin address to check
 * @returns True if potentially vulnerable
 */
export function isPotentiallyVulnerable(address: string): boolean {
  // Simple heuristic: legacy addresses with specific patterns are more likely vulnerable
  
  if (address.startsWith('1')) {
    // Count repeating character groups
    const groups = address.match(/(.)\1{2,}/g);
    if (groups && groups.length > 0) {
      return true;
    }
    
    // Check for ascending/descending patterns
    for (let i = 0; i < address.length - 3; i++) {
      const a = address.charCodeAt(i);
      const b = address.charCodeAt(i+1);
      const c = address.charCodeAt(i+2);
      
      if ((a + 1 === b && b + 1 === c) || (a - 1 === b && b - 1 === c)) {
        return true;
      }
    }
    
    // Check if it's a known early address (2009-2011)
    if (address.startsWith('1AAAA') || address.startsWith('1BANK') || 
        address.startsWith('1BitcoiN') || address.startsWith('1BURN') || 
        address.startsWith('1DICE') || address.startsWith('1GOLD')) {
      return true;
    }
  }
  
  return false;
}

/**
 * Get specialized search patterns for a specific address
 * @param address Bitcoin address
 * @returns Array of specialized search patterns
 */
export function getSpecializedPatterns(address: string): string[] {
  const patterns: string[] = [];
  
  // Extract potential pattern hints from the address
  const digits = address.replace(/[^0-9]/g, '');
  
  // If there are 4+ consecutive digits, they might be part of a pattern
  if (digits.length >= 4) {
    const digitGroups = digits.match(/(.{4,})/g);
    if (digitGroups) {
      // Convert digit groups to potential hex prefixes
      for (const group of digitGroups) {
        if (group.length >= 4) {
          const hexGroup = parseInt(group.substring(0, 4), 10).toString(16).padStart(4, '0');
          patterns.push(hexGroup);
        }
      }
    }
  }
  
  // Check for year patterns (might indicate when key was generated)
  const yearMatches = address.match(/(19\d\d|20[0-1]\d)/);
  if (yearMatches) {
    const year = yearMatches[0];
    // Convert year to hex as potential pattern
    const hexYear = parseInt(year, 10).toString(16);
    patterns.push(hexYear);
  }
  
  return patterns;
}

/**
 * Generate key ranges for brute force attempts
 * @param address Bitcoin address
 * @param segmentCount Number of segments to divide key space into
 * @returns Array of key ranges for parallel processing
 */
export function generateKeyRanges(
  address: string,
  segmentCount: number = 8
): Array<{ start: string; end: string }> {
  const ranges: Array<{ start: string; end: string }> = [];
  
  // Get potential optimizations
  const addressInfo = getAddressInfo(address);
  
  if (!addressInfo) {
    return ranges;
  }
  
  // Determine start and end of key space
  let start = '00000000000000000000000000000000000000000000000000000000000000001';
  let end = SECP256K1_ORDER;
  
  // Adjust range based on address type
  if (addressInfo.type === AddressType.P2PKH && !addressInfo.isCompressed) {
    // Uncompressed keys are more likely to be in lower ranges
    end = '7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0';
  } else if (addressInfo.type === AddressType.BECH32) {
    // SegWit addresses more likely in upper ranges
    start = '5555555555555555555555555555555555555555555555555555555555555555';
  }
  
  // Create range segments
  const range = BigInt('0x' + end) - BigInt('0x' + start);
  const segmentSize = range / BigInt(segmentCount);
  
  for (let i = 0; i < segmentCount; i++) {
    const segmentStart = BigInt('0x' + start) + (segmentSize * BigInt(i));
    let segmentEnd = segmentStart + segmentSize - BigInt(1);
    
    // Ensure the last segment includes the end
    if (i === segmentCount - 1) {
      segmentEnd = BigInt('0x' + end);
    }
    
    ranges.push({
      start: segmentStart.toString(16).padStart(64, '0'),
      end: segmentEnd.toString(16).padStart(64, '0')
    });
  }
  
  return ranges;
}