/**
 * In-memory Storage Implementation
 * 
 * Provides in-memory data storage for the application:
 * - CRUD operations for transactions, keys, patterns, etc.
 * - Persistence simulation
 * - Query capabilities
 */

import { IStorage, Transaction, Key, Pattern, Analysis, insertTransactionSchema } from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';

/**
 * In-memory storage implementation
 */
export class MemStorage implements IStorage {
  private transactions: Map<string, Transaction> = new Map();
  private keys: Map<string, Key> = new Map();
  private patterns: Map<string, Pattern> = new Map();
  private analyses: Map<string, Analysis> = new Map();
  
  /**
   * Constructor with optional initial data
   */
  constructor(
    initialData?: {
      transactions?: Transaction[];
      keys?: Key[];
      patterns?: Pattern[];
      analyses?: Analysis[];
    }
  ) {
    // Initialize with data if provided
    if (initialData) {
      if (initialData.transactions) {
        for (const tx of initialData.transactions) {
          this.transactions.set(tx.id, tx);
        }
      }
      
      if (initialData.keys) {
        for (const key of initialData.keys) {
          this.keys.set(key.id, key);
        }
      }
      
      if (initialData.patterns) {
        for (const pattern of initialData.patterns) {
          this.patterns.set(pattern.id, pattern);
        }
      }
      
      if (initialData.analyses) {
        for (const analysis of initialData.analyses) {
          this.analyses.set(analysis.id, analysis);
        }
      }
    }
  }
  
  // Transaction operations
  
  async createTransaction(data: Omit<Transaction, 'id' | 'createdAt'>): Promise<Transaction> {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    const transaction: Transaction = {
      ...data,
      id,
      createdAt: now
    };
    
    this.transactions.set(id, transaction);
    return transaction;
  }
  
  async getTransactionById(id: string): Promise<Transaction | null> {
    return this.transactions.get(id) || null;
  }
  
  async getTransactionsByAddress(address: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(tx => tx.address === address);
  }
  
  async getAllTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values());
  }
  
  async updateTransaction(id: string, data: Partial<Transaction>): Promise<Transaction | null> {
    const transaction = this.transactions.get(id);
    if (!transaction) return null;
    
    const updated: Transaction = {
      ...transaction,
      ...data
    };
    
    this.transactions.set(id, updated);
    return updated;
  }
  
  async deleteTransaction(id: string): Promise<boolean> {
    return this.transactions.delete(id);
  }
  
  // Key operations
  
  async createKey(data: Omit<Key, 'id' | 'createdAt'>): Promise<Key> {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    const key: Key = {
      ...data,
      id,
      createdAt: now
    };
    
    this.keys.set(id, key);
    return key;
  }
  
  async getKeyById(id: string): Promise<Key | null> {
    return this.keys.get(id) || null;
  }
  
  async getKeysByAddress(address: string): Promise<Key[]> {
    return Array.from(this.keys.values())
      .filter(key => key.address === address);
  }
  
  async getAllKeys(): Promise<Key[]> {
    return Array.from(this.keys.values());
  }
  
  async updateKey(id: string, data: Partial<Key>): Promise<Key | null> {
    const key = this.keys.get(id);
    if (!key) return null;
    
    const updated: Key = {
      ...key,
      ...data
    };
    
    this.keys.set(id, updated);
    return updated;
  }
  
  async deleteKey(id: string): Promise<boolean> {
    return this.keys.delete(id);
  }
  
  // Pattern operations
  
  async createPattern(data: Omit<Pattern, 'id' | 'createdAt' | 'updatedAt'>): Promise<Pattern> {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    const pattern: Pattern = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.patterns.set(id, pattern);
    return pattern;
  }
  
  async getPatternById(id: string): Promise<Pattern | null> {
    return this.patterns.get(id) || null;
  }
  
  async getAllPatterns(): Promise<Pattern[]> {
    return Array.from(this.patterns.values());
  }
  
  async updatePattern(id: string, data: Partial<Pattern>): Promise<Pattern | null> {
    const pattern = this.patterns.get(id);
    if (!pattern) return null;
    
    const now = new Date().toISOString();
    
    const updated: Pattern = {
      ...pattern,
      ...data,
      updatedAt: now
    };
    
    this.patterns.set(id, updated);
    return updated;
  }
  
  async deletePattern(id: string): Promise<boolean> {
    return this.patterns.delete(id);
  }
  
  // Analysis operations
  
  async createAnalysis(data: Omit<Analysis, 'id' | 'startTime' | 'endTime'>): Promise<Analysis> {
    const id = uuidv4();
    const now = new Date().toISOString();
    
    const analysis: Analysis = {
      ...data,
      id,
      startTime: now
    };
    
    this.analyses.set(id, analysis);
    return analysis;
  }
  
  async getAnalysisById(id: string): Promise<Analysis | null> {
    return this.analyses.get(id) || null;
  }
  
  async getAllAnalyses(): Promise<Analysis[]> {
    return Array.from(this.analyses.values());
  }
  
  async updateAnalysis(id: string, data: Partial<Analysis>): Promise<Analysis | null> {
    const analysis = this.analyses.get(id);
    if (!analysis) return null;
    
    const updated: Analysis = {
      ...analysis,
      ...data
    };
    
    this.analyses.set(id, updated);
    return updated;
  }
  
  async deleteAnalysis(id: string): Promise<boolean> {
    return this.analyses.delete(id);
  }
}

// Create a singleton instance
export const storage = new MemStorage();