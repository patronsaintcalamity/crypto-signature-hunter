import { Transaction } from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';

/**
 * Check if OpenAI API key is available in environment
 * @returns Boolean indicating if OpenAI API is available
 */
export function isOpenAIAvailable(): boolean {
  return !!process.env.OPENAI_API_KEY;
}

/**
 * Parse TXT file content into Transaction objects
 * 
 * Expected TXT format:
 * [Bitcoin Address]
 * Index X
 * R = [value]
 * S = [value]
 * Z = [value]
 * PublicKey = [value]
 * 
 * @param txtContent Text file content as string
 * @returns Array of Transaction objects
 */
export function parseTXT(txtContent: string): Transaction[] {
  const transactions: Transaction[] = [];
  const lines = txtContent.split('\n').map(line => line.trim());
  
  let currentAddress: string | null = null;
  let currentTransaction: Partial<Transaction> = {};
  
  // Regular expressions for matching expected patterns
  const addressRegex = /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/;
  const indexRegex = /^Index\s+(\d+)$/i;
  const sequenceRegex = /^Sequence(?:\s+Number)?\s*=?\s*(\d+)$/i;
  const inputValueRegex = /^Input\s+Value\s*=?\s*([\d.]+)$/i;
  const outputValueRegex = /^Output\s+Value\s*=?\s*([\d.]+)$/i;
  const rValueRegex = /^R\s*=\s*([0-9a-fA-F]+)$/i;
  const sValueRegex = /^S\s*=\s*([0-9a-fA-F]+)$/i;
  const zValueRegex = /^Z\s*=\s*([0-9a-fA-F]+)$/i;
  const pubKeyRegex = /^PublicKey\s*=\s*([0-9a-fA-F]+)$/i;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Skip empty lines
    if (!line) continue;
    
    // Check for address
    if (addressRegex.test(line)) {
      // If we were processing a transaction, save it
      if (currentTransaction.address && currentTransaction.r && currentTransaction.s) {
        const txid = uuidv4();
        transactions.push({
          ...currentTransaction as Transaction,
          id: txid,
          txid: txid
        });
      }
      
      // Start a new transaction
      currentAddress = line;
      currentTransaction = { address: currentAddress };
      continue;
    }
    
    // Parse index
    const indexMatch = line.match(indexRegex);
    if (indexMatch && currentTransaction.address) {
      const indexValue = parseInt(indexMatch[1]);
      currentTransaction = { ...currentTransaction, index: indexValue };
      continue;
    }
    
    // Parse R value
    const rMatch = line.match(rValueRegex);
    if (rMatch && currentTransaction.address) {
      currentTransaction.r = rMatch[1];
      continue;
    }
    
    // Parse S value
    const sMatch = line.match(sValueRegex);
    if (sMatch && currentTransaction.address) {
      currentTransaction.s = sMatch[1];
      continue;
    }
    
    // Parse Z value
    const zMatch = line.match(zValueRegex);
    if (zMatch && currentTransaction.address) {
      currentTransaction.z = zMatch[1];
      continue;
    }
    
    // Parse sequence number
    const seqMatch = line.match(sequenceRegex);
    if (seqMatch && currentTransaction.address) {
      const seqValue = parseInt(seqMatch[1]);
      currentTransaction = { ...currentTransaction, sequenceNumber: seqValue };
      continue;
    }
    
    // Parse input value
    const inputMatch = line.match(inputValueRegex);
    if (inputMatch && currentTransaction.address) {
      const inputValue = parseFloat(inputMatch[1]);
      currentTransaction = { ...currentTransaction, inputValue };
      continue;
    }
    
    // Parse output value
    const outputMatch = line.match(outputValueRegex);
    if (outputMatch && currentTransaction.address) {
      const outputValue = parseFloat(outputMatch[1]);
      currentTransaction = { ...currentTransaction, outputValue };
      continue;
    }
    
    // Parse public key
    const pubKeyMatch = line.match(pubKeyRegex);
    if (pubKeyMatch && currentTransaction.address) {
      currentTransaction.pubkey = pubKeyMatch[1];
      continue;
    }
  }
  
  // Add the last transaction if it's valid
  if (currentTransaction.address && currentTransaction.r && currentTransaction.s) {
    const txid = uuidv4();
    transactions.push({
      ...currentTransaction as Transaction,
      id: txid,
      txid: txid
    });
  }
  
  // Add timestamp and set defaults for additional fields
  return transactions.map(tx => ({
    ...tx,
    timestamp: new Date().toISOString(),
    blockHeight: tx.blockHeight || null,
    index: tx.index || null,
    sequenceNumber: tx.sequenceNumber || null,
    inputValue: tx.inputValue || null,
    outputValue: tx.outputValue || null,
    patternId: tx.patternId || null,
    patternName: tx.patternName || null,
    confidence: tx.confidence || 0,
    status: tx.status || 'imported',
    createdAt: new Date().toISOString()
  }));
}

/**
 * Parse CSV file content into Transaction objects
 * 
 * Expected CSV format:
 * txid,address,r,s,z,pubkey
 * 
 * @param csvContent CSV content as string
 * @returns Array of Transaction objects
 */
export function parseCSV(csvContent: string): Transaction[] {
  const transactions: Transaction[] = [];
  const lines = csvContent.split('\n').map(line => line.trim()).filter(Boolean);
  
  // Skip header
  if (lines.length > 0) {
    const headerLine = lines[0].toLowerCase();
    const hasHeader = headerLine.includes('address') || 
                     headerLine.includes('txid') || 
                     headerLine.includes('id');
    
    const startIndex = hasHeader ? 1 : 0;
    
    for (let i = startIndex; i < lines.length; i++) {
      const parts = lines[i].split(',').map(part => part.trim());
      
      if (parts.length >= 6) {
        const [txid, address, r, s, z, pubkey, ...rest] = parts;
        
        if (address && r && s) {
          const id = txid || uuidv4();
          transactions.push({
            id,
            txid: id,
            address,
            r,
            s,
            z,
            pubkey,
            timestamp: new Date().toISOString(),
            blockHeight: null,
            index: null,
            sequenceNumber: null,
            inputValue: null,
            outputValue: null,
            patternId: null,
            patternName: null,
            confidence: 0,
            status: 'imported',
            createdAt: new Date().toISOString()
          } as Transaction);
        }
      }
    }
  }
  
  return transactions;
}

/**
 * Parse JSON file content into Transaction objects
 * 
 * @param jsonContent JSON content as string
 * @returns Array of Transaction objects
 */
export function parseJSON(jsonContent: string): Transaction[] {
  try {
    const parsed = JSON.parse(jsonContent);
    
    // Handle array format
    if (Array.isArray(parsed)) {
      return parsed.map(item => {
        // Ensure required fields
        const id = item.id || uuidv4();
        
        return {
          ...item,
          id,
          txid: item.txid || id,
          timestamp: item.timestamp || new Date().toISOString(),
          blockHeight: item.blockHeight || null,
          index: item.index || null,
          sequenceNumber: item.sequenceNumber || null,
          inputValue: item.inputValue || null,
          outputValue: item.outputValue || null,
          patternId: item.patternId || null,
          patternName: item.patternName || null,
          confidence: item.confidence || 0,
          status: item.status || 'imported',
          createdAt: item.createdAt || new Date().toISOString()
        } as Transaction;
      });
    }
    
    // Handle single object format
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      if (parsed.transactions && Array.isArray(parsed.transactions)) {
        return parsed.transactions.map((tx: any) => {
          const id = tx.id || uuidv4();
          
          return {
            ...tx,
            id,
            txid: tx.txid || id,
            timestamp: tx.timestamp || new Date().toISOString(),
            blockHeight: tx.blockHeight || null,
            index: tx.index || null,
            sequenceNumber: tx.sequenceNumber || null,
            inputValue: tx.inputValue || null,
            outputValue: tx.outputValue || null,
            patternId: tx.patternId || null,
            patternName: tx.patternName || null,
            confidence: tx.confidence || 0,
            status: tx.status || 'imported',
            createdAt: tx.createdAt || new Date().toISOString()
          } as Transaction;
        });
      }
    }
    
    return [];
  } catch (error) {
    console.error('Error parsing JSON content:', error);
    return [];
  }
}

/**
 * Formats a hex string to ensure even length and proper format
 * @param hex Hex string to format
 * @returns Formatted hex string
 */
export function formatHexString(hex: string): string {
  // Remove '0x' prefix if present
  let formattedHex = hex.startsWith('0x') ? hex.slice(2) : hex;
  
  // Ensure even length
  if (formattedHex.length % 2 !== 0) {
    formattedHex = '0' + formattedHex;
  }
  
  return formattedHex.toLowerCase();
}

/**
 * Convert a decimal string to a hex string
 * @param decStr Decimal string
 * @returns Hex string (without 0x prefix)
 */
export function decimalToHex(decStr: string): string {
  try {
    const bn = BigInt(decStr);
    let hex = bn.toString(16);
    
    // Ensure even length
    if (hex.length % 2 !== 0) {
      hex = '0' + hex;
    }
    
    return hex;
  } catch (e) {
    console.error('Error converting decimal to hex:', e);
    return '';
  }
}

/**
 * Check if a string is a valid hex string
 * @param str String to check
 * @returns True if valid hex string
 */
export function isValidHex(str: string): boolean {
  return /^[0-9a-fA-F]+$/.test(str);
}

/**
 * Split a string into groups of specified size
 * @param str String to split
 * @param size Size of each group
 * @returns Array of string groups
 */
export function chunkString(str: string, size: number): string[] {
  const chunks = [];
  for (let i = 0; i < str.length; i += size) {
    chunks.push(str.slice(i, i + size));
  }
  return chunks;
}

/**
 * Find repeating patterns in a string
 * @param str String to analyze
 * @param minLength Minimum pattern length to look for
 * @param maxLength Maximum pattern length to look for
 * @returns Array of found patterns with frequency counts
 */
export function findRepeatingPatterns(
  str: string, 
  minLength: number = 2, 
  maxLength: number = 8
): Array<{ pattern: string; count: number }> {
  const patterns: Record<string, number> = {};
  
  // Check for patterns of different lengths
  for (let len = minLength; len <= maxLength; len++) {
    for (let i = 0; i <= str.length - len; i++) {
      const pattern = str.substr(i, len);
      
      // Count occurrences of this pattern
      let count = 0;
      let pos = str.indexOf(pattern);
      while (pos !== -1) {
        count++;
        pos = str.indexOf(pattern, pos + 1);
      }
      
      // Only include if pattern appears multiple times
      if (count > 1) {
        patterns[pattern] = count;
      }
    }
  }
  
  // Convert to array and sort by count (descending)
  return Object.entries(patterns)
    .map(([pattern, count]) => ({ pattern, count }))
    .sort((a, b) => b.count - a.count);
}