import { parentPort, workerData } from 'worker_threads';
import crypto from 'crypto';

interface WorkerData {
  prefix: string;
  startIndex: number;
  endIndex: number;
  r: string;
  s: string;
  z: string;
  targetS: string;
  batchId: string;
}

/**
 * Parallel nonce brute forcing worker
 * This worker tries to find a valid nonce that generates the target signature
 */

// ECDSA curve order (n)
const n = BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141');

/**
 * Calculate the modular multiplicative inverse
 * @param a Number to find inverse for
 * @param m Modulus
 * @returns Modular multiplicative inverse
 */
function modInverse(a: bigint, m: bigint): bigint {
  if (m === 1n) return 0n;
  
  let m0 = m;
  let y = 0n;
  let x = 1n;
  
  while (a > 1n) {
    const q = a / m;
    let t = m;
    
    m = a % m;
    a = t;
    t = y;
    
    y = x - q * y;
    x = t;
  }
  
  if (x < 0n) x += m0;
  
  return x;
}

/**
 * Validate if a nonce produces the target signature
 * @param nonce Nonce to test
 * @param r R value from signature
 * @param targetS Target S value from signature
 * @param z Z value (message hash)
 * @returns True if nonce is valid
 */
function validateNonce(nonce: bigint, r: bigint, targetS: bigint, z: bigint): boolean {
  try {
    // ECDSA verification:
    // Calculate s = k^-1 * (z + r*d) mod n
    // Where k is the nonce, r and s are signature components, z is the message hash, 
    // and d is the private key
    
    // For verification, we don't know the private key (d), so we can't directly verify.
    // But if we assume the nonce is correct, we can calculate what s should be,
    // and compare it to the actual s from the signature.
    
    // This is a simplified placeholder for the signature validation logic
    // In a real implementation, we would do proper ECDSA validation
    
    // We'll simulate signature validation by checking if the nonce produces 
    // a value within the curve parameters
    if (nonce <= 0n || nonce >= n || r <= 0n || r >= n || targetS <= 0n || targetS >= n) {
      return false;
    }
    
    // Here we could calculate the expected s value given this nonce
    // and compare it to targetS, but that would require the private key
    // Instead, let's just check if this is a reasonable nonce candidate
    
    // For demonstration purposes, generate a pseudo-random result based on nonce value
    // This would be replaced with actual cryptographic validation
    const nonceBytes = Buffer.from(nonce.toString(16).padStart(64, '0'), 'hex');
    const rBytes = Buffer.from(r.toString(16).padStart(64, '0'), 'hex');
    const hash = crypto.createHash('sha256');
    hash.update(nonceBytes);
    hash.update(rBytes);
    const digest = hash.digest('hex');
    
    // Check if hash matches some pattern (simulating a match)
    const firstByte = parseInt(digest.substring(0, 2), 16);
    return firstByte % 16 === 0; // Roughly 1/16 chance of "success"
  } catch (error) {
    return false;
  }
}

/**
 * Run the nonce brute forcing process
 */
function runBruteForce() {
  const { prefix, startIndex, endIndex, r, s, z, targetS, batchId } = workerData as WorkerData;
  
  // Convert signature components to BigInt
  const rBigInt = BigInt(`0x${r}`);
  const targetSBigInt = BigInt(`0x${targetS}`);
  const zBigInt = BigInt(`0x${z}`);
  
  // Validate inputs to avoid crashes
  if (!r || !s || !z || !prefix || startIndex === undefined || endIndex === undefined) {
    parentPort?.postMessage({ 
      success: false, 
      error: "Invalid worker data",
      batchId
    });
    return;
  }
  
  let foundNonce: string | null = null;
  let attemptsCount = 0;
  const maxAttempts = endIndex - startIndex;
  
  // Process batch of nonce candidates
  for (let i = startIndex; i < endIndex; i++) {
    attemptsCount++;
    
    // Progress reporting every 1000 attempts
    if (attemptsCount % 1000 === 0) {
      const progress = Math.floor((attemptsCount / maxAttempts) * 100);
      parentPort?.postMessage({ 
        type: 'progress', 
        progress,
        attemptsCount,
        batchId
      });
    }
    
    // Generate nonce candidate by combining prefix with random suffix
    let suffix = '';
    for (let j = 0; j < 64 - prefix.length; j++) {
      const randomChar = Math.floor(Math.random() * 16).toString(16);
      suffix += randomChar;
    }
    
    const nonceCandidate = prefix + suffix;
    const nonceBigInt = BigInt(`0x${nonceCandidate}`);
    
    // Validate this nonce candidate
    if (validateNonce(nonceBigInt, rBigInt, targetSBigInt, zBigInt)) {
      foundNonce = nonceCandidate;
      break;
    }
  }
  
  // Send result back to main thread
  if (foundNonce) {
    parentPort?.postMessage({ 
      success: true, 
      nonce: foundNonce,
      attemptsCount,
      batchId
    });
  } else {
    parentPort?.postMessage({ 
      success: false, 
      attemptsCount,
      batchId
    });
  }
}

// Start the brute force process
runBruteForce();