/**
 * File Parser Module
 * 
 * Parses signature data from various file formats:
 * - Plain text (line-based)
 * - JSON
 * - CSV
 * - Custom formats
 */

import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

/**
 * Transaction data structure (simplified)
 */
export interface Transaction {
  id: string;
  address: string;
  r: string;
  s: string;
  z?: string;
  pubKey?: string;
  hash?: string;
  source?: string;
  timestamp?: number;
  searchHints?: {
    keyPrefixes?: string[];
    keyRanges?: Array<{ start: string; end: string }>;
    noncePatterns?: string[];
    signatureCorrelations?: any;
    timePeriod?: { start: number; end: number };
  };
}

/**
 * File parser for signature data extraction
 */
export class FileParser {
  /**
   * Parse a file and extract transaction data
   * @param filePath Path to the file
   * @returns Array of parsed transactions
   */
  async parseFile(filePath: string): Promise<Transaction[]> {
    try {
      const extension = path.extname(filePath).toLowerCase();
      
      // Read file content
      const content = await fs.promises.readFile(filePath, 'utf8');
      
      // Parse based on file extension
      switch (extension) {
        case '.json':
          return this.parseJsonContent(content);
        case '.csv':
          return this.parseCsvContent(content);
        case '.txt':
        default:
          return this.parseTextContent(content, path.basename(filePath));
      }
    } catch (err) {
      console.error(`Error parsing file ${filePath}:`, err);
      return [];
    }
  }
  
  /**
   * Parse JSON content
   * @param content JSON content
   * @returns Array of parsed transactions
   */
  private parseJsonContent(content: string): Transaction[] {
    try {
      const data = JSON.parse(content);
      
      // Handle array format
      if (Array.isArray(data)) {
        return data.map(item => this.normalizeTransaction(item));
      }
      
      // Handle object format with transactions array
      if (data.transactions && Array.isArray(data.transactions)) {
        return data.transactions.map(tx => this.normalizeTransaction(tx));
      }
      
      // Handle single transaction object
      if (data.address && (data.r || data.signature)) {
        return [this.normalizeTransaction(data)];
      }
      
      return [];
    } catch (err) {
      console.error('Error parsing JSON content:', err);
      return [];
    }
  }
  
  /**
   * Parse CSV content
   * @param content CSV content
   * @returns Array of parsed transactions
   */
  private parseCsvContent(content: string): Transaction[] {
    try {
      const lines = content.trim().split('\n');
      
      // Skip empty file
      if (lines.length === 0) return [];
      
      // Extract header
      const header = lines[0].split(',').map(h => h.trim().toLowerCase());
      
      // Identify column indices
      const addrIdx = header.findIndex(h => h.includes('addr'));
      const rIdx = header.findIndex(h => 
        h === 'r' || h.includes('nonce') || h.includes('signature'));
      const sIdx = header.findIndex(h => 
        h === 's' || h.includes('signature'));
      const zIdx = header.findIndex(h => 
        h === 'z' || h.includes('hash') || h.includes('message'));
      const keyIdx = header.findIndex(h => 
        h.includes('pub') && h.includes('key'));
        
      // At least address and r (or equivalent) are required
      if (addrIdx === -1 || rIdx === -1) return [];
      
      // Parse data rows
      const transactions: Transaction[] = [];
      
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        
        // Skip incomplete rows
        if (values.length < Math.max(addrIdx, rIdx, sIdx) + 1) continue;
        
        // Extract values
        const address = values[addrIdx];
        const r = values[rIdx];
        const s = sIdx !== -1 ? values[sIdx] : undefined;
        const z = zIdx !== -1 ? values[zIdx] : undefined;
        const pubKey = keyIdx !== -1 ? values[keyIdx] : undefined;
        
        // Skip rows without required fields
        if (!address || !r) continue;
        
        // Create transaction
        transactions.push({
          id: uuidv4(),
          address,
          r,
          s: s || '',
          z,
          pubKey
        });
      }
      
      return transactions;
    } catch (err) {
      console.error('Error parsing CSV content:', err);
      return [];
    }
  }
  
  /**
   * Parse plain text content
   * @param content Text content
   * @param filename Source filename
   * @returns Array of parsed transactions
   */
  private parseTextContent(content: string, filename: string): Transaction[] {
    try {
      const lines = content.trim().split('\n');
      const transactions: Transaction[] = [];
      
      // Check if it's a Bitcoin address in the filename
      const addressMatch = filename.match(/^([13][a-km-zA-HJ-NP-Z1-9]{25,34})\.txt$/);
      const filenameAddress = addressMatch ? addressMatch[1] : null;
      
      // Check if content contains "Index" pattern with R, S, Z, and PublicKey fields
      if (content.includes('Index') && (content.includes('R =') || content.includes('S =') || content.includes('Z ='))) {
        return this.parseIndexFormat(content, filenameAddress);
      }
      // Handle different text formats
      else if (content.includes('signature') && content.includes('message')) {
        // Format with labeled fields
        return this.parseLabeledFormat(content, filenameAddress);
      } else if (content.includes('==') || content.includes(':')) {
        // Key-value pairs format
        return this.parseKeyValueFormat(content, filenameAddress);
      } else {
        // Simple line format - assume r,s,z on separate lines
        let address = filenameAddress || '';
        let r = '';
        let s = '';
        let z = '';
        
        for (const line of lines) {
          const trimmedLine = line.trim();
          
          // Skip empty lines and comments
          if (!trimmedLine || trimmedLine.startsWith('#')) continue;
          
          // Check if line is a Bitcoin address
          if (this.isBitcoinAddress(trimmedLine)) {
            // If we have collected data for a transaction, save it
            if (address && r) {
              transactions.push({
                id: uuidv4(),
                address,
                r,
                s: s || '',
                z: z || undefined
              });
            }
            
            // Start new transaction
            address = trimmedLine;
            r = '';
            s = '';
            z = '';
          } 
          // Check if line is hex value (r, s, or z component)
          else if (this.isHexString(trimmedLine)) {
            if (!r) {
              r = trimmedLine;
            } else if (!s) {
              s = trimmedLine;
            } else if (!z) {
              z = trimmedLine;
            }
          }
        }
        
        // Add the last transaction if it has required fields
        if (address && r) {
          transactions.push({
            id: uuidv4(),
            address,
            r,
            s: s || '',
            z: z || undefined
          });
        }
      }
      
      return transactions;
    } catch (err) {
      console.error('Error parsing text content:', err);
      return [];
    }
  }
  
  /**
   * Parse text in Index format with R, S, Z, PublicKey fields
   * @param content Text content
   * @param defaultAddress Default Bitcoin address
   * @returns Array of parsed transactions
   */
  private parseIndexFormat(content: string, defaultAddress: string | null): Transaction[] {
    const transactions: Transaction[] = [];
    const lines = content.trim().split('\n');
    
    let address = defaultAddress || '';
    let currentIndex = '';
    let r = '';
    let s = '';
    let z = '';
    let pubKey = '';
    
    // First line might be the Bitcoin address
    if (lines.length > 0 && this.isBitcoinAddress(lines[0].trim())) {
      address = lines[0].trim();
    }
    
    for (let i = 0; i < lines.length; i++) {
      const trimmedLine = lines[i].trim();
      
      // Skip empty lines and comments
      if (!trimmedLine || trimmedLine.startsWith('#')) continue;
      
      // Check if line is a Bitcoin address (can appear anywhere in the file)
      if (this.isBitcoinAddress(trimmedLine)) {
        // Save current transaction if needed before updating the address
        if (address && r && s) {
          transactions.push({
            id: uuidv4(),
            address,
            r,
            s,
            z: z || undefined,
            pubKey: pubKey || undefined
          });
          
          // Reset values for new transaction
          r = '';
          s = '';
          z = '';
          pubKey = '';
        }
        
        address = trimmedLine;
        continue;
      }
      
      // Check for Index line
      const indexMatch = trimmedLine.match(/^Index\s+(\d+)$/);
      if (indexMatch) {
        // Save previous transaction before starting a new one
        if (address && r && s) {
          transactions.push({
            id: uuidv4(),
            address,
            r,
            s,
            z: z || undefined,
            pubKey: pubKey || undefined
          });
        }
        
        // Start a new transaction but keep the address
        currentIndex = indexMatch[1];
        r = '';
        s = '';
        z = '';
        pubKey = '';
        continue;
      }
      
      // Extract R, S, Z, and PublicKey values
      if (trimmedLine.startsWith('R =')) {
        const value = trimmedLine.substring(3).trim();
        if (this.isHexString(value)) {
          r = value;
        }
      }
      else if (trimmedLine.startsWith('S =')) {
        const value = trimmedLine.substring(3).trim();
        if (this.isHexString(value)) {
          s = value;
        }
      }
      else if (trimmedLine.startsWith('Z =')) {
        const value = trimmedLine.substring(3).trim();
        if (this.isHexString(value)) {
          z = value;
        }
      }
      else if (trimmedLine.startsWith('PublicKey =')) {
        const value = trimmedLine.substring(11).trim();
        if (this.isHexString(value)) {
          pubKey = value;
        }
      }
    }
    
    // Add the last transaction if it has required fields
    if (address && r && s) {
      transactions.push({
        id: uuidv4(),
        address,
        r,
        s,
        z: z || undefined,
        pubKey: pubKey || undefined
      });
    }
    
    return transactions;
  }
  
  /**
   * Parse content with labeled fields
   * @param content Text content
   * @param defaultAddress Default Bitcoin address
   * @returns Array of parsed transactions
   */
  private parseLabeledFormat(content: string, defaultAddress: string | null): Transaction[] {
    const transactions: Transaction[] = [];
    const lines = content.trim().split('\n');
    
    let address = defaultAddress || '';
    let r = '';
    let s = '';
    let z = '';
    let pubKey = '';
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      
      // Skip empty lines and comments
      if (!trimmedLine || trimmedLine.startsWith('#')) continue;
      
      // Check for labeled fields
      if (trimmedLine.toLowerCase().includes('address:')) {
        const addrParts = trimmedLine.split(':');
        const addrPart = addrParts.length > 1 ? addrParts[1].trim() : '';
        
        if (addrPart && this.isBitcoinAddress(addrPart)) {
          // If we have data for a transaction, save it before starting a new one
          if (address && r) {
            transactions.push({
              id: uuidv4(),
              address,
              r,
              s: s || '',
              z: z || undefined,
              pubKey: pubKey || undefined
            });
          }
          
          // Start new transaction
          address = addrPart;
          r = '';
          s = '';
          z = '';
          pubKey = '';
        }
      } 
      else if (
        trimmedLine.toLowerCase().includes('r:') || 
        trimmedLine.toLowerCase().includes('signature r:')
      ) {
        const parts = trimmedLine.split(':');
        const match = parts.length > 1 ? parts[1].trim() : '';
        
        if (match && this.isHexString(match)) {
          r = match;
        }
      }
      else if (
        trimmedLine.toLowerCase().includes('s:') || 
        trimmedLine.toLowerCase().includes('signature s:')
      ) {
        const parts = trimmedLine.split(':');
        const match = parts.length > 1 ? parts[1].trim() : '';
        
        if (match && this.isHexString(match)) {
          s = match;
        }
      }
      else if (
        trimmedLine.toLowerCase().includes('z:') || 
        trimmedLine.toLowerCase().includes('message:') || 
        trimmedLine.toLowerCase().includes('hash:')
      ) {
        const parts = trimmedLine.split(':');
        const match = parts.length > 1 ? parts[1].trim() : '';
        
        if (match && this.isHexString(match)) {
          z = match;
        }
      }
      else if (
        trimmedLine.toLowerCase().includes('pubkey:') || 
        trimmedLine.toLowerCase().includes('public key:')
      ) {
        const parts = trimmedLine.split(':');
        const match = parts.length > 1 ? parts[1].trim() : '';
        
        if (match && this.isHexString(match)) {
          pubKey = match;
        }
      }
    }
    
    // Add the last transaction if it has required fields
    if (address && r) {
      transactions.push({
        id: uuidv4(),
        address,
        r,
        s: s || '',
        z: z || undefined,
        pubKey: pubKey || undefined
      });
    }
    
    return transactions;
  }
  
  /**
   * Parse content with key-value pairs
   * @param content Text content
   * @param defaultAddress Default Bitcoin address
   * @returns Array of parsed transactions
   */
  private parseKeyValueFormat(content: string, defaultAddress: string | null): Transaction[] {
    const transactions: Transaction[] = [];
    const lines = content.trim().split('\n');
    
    let address = defaultAddress || '';
    let r = '';
    let s = '';
    let z = '';
    let pubKey = '';
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      
      // Skip empty lines and comments
      if (!trimmedLine || trimmedLine.startsWith('#')) continue;
      
      // Look for key-value separator (: or ==)
      const separatorIdx = trimmedLine.includes(':') 
        ? trimmedLine.indexOf(':') 
        : trimmedLine.indexOf('==');
        
      if (separatorIdx === -1) continue;
      
      const key = trimmedLine.substring(0, separatorIdx).trim().toLowerCase();
      const value = trimmedLine.substring(separatorIdx + 1).trim();
      
      if (!value) continue;
      
      // Extract fields
      if (
        key === 'address' || 
        key === 'bitcoin address' || 
        key === 'addr'
      ) {
        if (this.isBitcoinAddress(value)) {
          // If we have data for a transaction, save it before starting a new one
          if (address && r) {
            transactions.push({
              id: uuidv4(),
              address,
              r,
              s: s || '',
              z: z || undefined,
              pubKey: pubKey || undefined
            });
          }
          
          // Start new transaction
          address = value;
          r = '';
          s = '';
          z = '';
          pubKey = '';
        }
      }
      else if (
        key === 'r' || 
        key === 'signature r' || 
        key === 'r signature' ||
        key === 'nonce'
      ) {
        if (this.isHexString(value)) {
          r = value;
        }
      }
      else if (
        key === 's' || 
        key === 'signature s' || 
        key === 's signature'
      ) {
        if (this.isHexString(value)) {
          s = value;
        }
      }
      else if (
        key === 'z' || 
        key === 'message' || 
        key === 'hash' ||
        key === 'message hash'
      ) {
        if (this.isHexString(value)) {
          z = value;
        }
      }
      else if (
        key === 'pubkey' || 
        key === 'public key' || 
        key === 'pub'
      ) {
        if (this.isHexString(value)) {
          pubKey = value;
        }
      }
    }
    
    // Add the last transaction if it has required fields
    if (address && r) {
      transactions.push({
        id: uuidv4(),
        address,
        r,
        s: s || '',
        z: z || undefined,
        pubKey: pubKey || undefined
      });
    }
    
    return transactions;
  }
  
  /**
   * Check if a string is a valid Bitcoin address
   * @param str String to check
   * @returns True if valid Bitcoin address
   */
  private isBitcoinAddress(str: string): boolean {
    // Basic check for legacy, script hash, and bech32 formats
    return /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(str) || 
           /^bc1[a-zA-HJ-NP-Z0-9]{25,89}$/.test(str);
  }
  
  /**
   * Check if a string is a hex string
   * @param str String to check
   * @returns True if valid hex string
   */
  private isHexString(str: string): boolean {
    return /^[0-9a-fA-F]{16,}$/.test(str);
  }
  
  /**
   * Normalize a transaction object
   * @param tx Transaction data
   * @returns Normalized transaction
   */
  private normalizeTransaction(tx: Record<string, any>): Transaction {
    return {
      id: tx.id || uuidv4(),
      address: tx.address || tx.addr || '',
      r: tx.r || tx.R || tx.signature_r || tx.signatureR || '',
      s: tx.s || tx.S || tx.signature_s || tx.signatureS || '',
      z: tx.z || tx.Z || tx.message || tx.hash || undefined,
      pubKey: tx.pubKey || tx.publicKey || tx.public_key || undefined,
      timestamp: tx.timestamp || tx.time || undefined
    };
  }
}