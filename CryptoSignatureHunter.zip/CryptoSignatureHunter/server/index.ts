/**
 * Server Entry Point
 * 
 * Main entry point for the application server:
 * - Express setup
 * - Route configuration
 * - Error handling
 */

import express from 'express';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { cpus } from 'os';
import { AddressType, getAddressInfo } from './addressPatterns';
import { FileParser, Transaction } from './fileParser';
import { parallelProcessingManager } from './parallelProcessing';
import { BlockchainOptimizer } from './blockchainOptimizations';
import { aiService } from './aiService';
import { SignatureClusterAnalyzer, Cluster } from './signatureClustering';
import { RainbowTableManager } from './rainbowTables';
import { v4 as uuidv4 } from 'uuid';

// Create Express application
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT) : 5000;

// File upload configuration
const uploadDir = path.join(process.cwd(), 'uploads');
const attachedDir = path.join(process.cwd(), 'attached_assets');

// Ensure upload directory exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ storage });

// In-memory data stores
const transactions = new Map<string, Transaction>();
const analyses = new Map<string, any>();
const keys = new Map<string, any>();
const clusters = new Map<string, Cluster>();

// Parse JSON bodies
app.use(express.json());

// Serve static assets from client directory
app.use(express.static(path.join(process.cwd(), 'client')));

// API routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '1.0.0' });
});

// Get all transactions
app.get('/api/transactions', (req, res) => {
  res.json(Array.from(transactions.values()));
});

// Get a specific transaction
app.get('/api/transactions/:id', (req, res) => {
  const tx = transactions.get(req.params.id);
  if (!tx) {
    return res.status(404).json({ error: 'Transaction not found' });
  }
  res.json(tx);
});

// Upload transaction files
app.post('/api/transactions/upload', upload.array('file'), async (req, res) => {
  try {
    const files = req.files as Express.Multer.File[];
    
    // Track valid transactions count
    let validCount = 0;
    
    // Parse each uploaded file
    for (const file of files) {
      const fileParser = new FileParser();
      const parsedTxs = await fileParser.parseFile(file.path);
      
      // Store valid transactions
      for (const tx of parsedTxs) {
        if (tx.address && tx.r && tx.s) {
          transactions.set(tx.id, tx);
          validCount++;
        }
      }
    }
    
    res.json({ success: true, validCount });
  } catch (error) {
    console.error('Error uploading files:', error);
    res.status(500).json({ error: 'File upload failed' });
  }
});

// Parse attached sample files
app.post('/api/transactions/parse-attached', async (req, res) => {
  try {
    // Find all attached txt files
    const files = fs.readdirSync(attachedDir)
      .filter(f => f.endsWith('.txt'))
      .map(f => path.join(attachedDir, f));
    
    // Skip if no files found
    if (files.length === 0) {
      return res.json({ success: false, error: 'No sample files found' });
    }
    
    // Track valid transactions count
    let validCount = 0;
    
    // Parse each attached file
    for (const filePath of files) {
      const fileParser = new FileParser();
      const parsedTxs = await fileParser.parseFile(filePath);
      
      // Store valid transactions
      for (const tx of parsedTxs) {
        if (tx.address && tx.r && tx.s) {
          tx.source = path.basename(filePath);
          transactions.set(tx.id, tx);
          validCount++;
        }
      }
    }
    
    res.json({ success: true, validCount });
  } catch (error) {
    console.error('Error parsing attached files:', error);
    res.status(500).json({ error: 'File parsing failed' });
  }
});

// Get all analyses
app.get('/api/analyses', (req, res) => {
  res.json(Array.from(analyses.values()));
});

// Get a specific analysis
app.get('/api/analyses/:id', (req, res) => {
  const analysis = analyses.get(req.params.id);
  if (!analysis) {
    return res.status(404).json({ error: 'Analysis not found' });
  }
  res.json(analysis);
});

// Create a new analysis
app.post('/api/analyses', async (req, res) => {
  try {
    const { name, speed, useAI } = req.body;
    
    // Create analysis record
    const analysis = {
      id: uuidv4(),
      name: name || 'Unnamed Analysis',
      status: 'running',
      progress: 0,
      speed: speed || 'balanced',
      useAI: useAI !== false,
      transactionCount: transactions.size,
      keyCount: 0,
      startTime: Date.now(),
      endTime: null,
      results: null
    };
    
    // Store analysis
    analyses.set(analysis.id, analysis);
    
    // Return immediately
    res.json(analysis);
    
    // Process analysis in background
    runAnalysis(analysis.id);
  } catch (error) {
    console.error('Error creating analysis:', error);
    res.status(500).json({ error: 'Failed to create analysis' });
  }
});

// Get all keys
app.get('/api/keys', (req, res) => {
  res.json(Array.from(keys.values()));
});

// Get clusters
app.get('/api/clusters', (req, res) => {
  res.json(Array.from(clusters.values()));
});

// Get a specific cluster
app.get('/api/clusters/:id', (req, res) => {
  const cluster = clusters.get(req.params.id);
  if (!cluster) {
    return res.status(404).json({ error: 'Cluster not found' });
  }
  res.json(cluster);
});

// Save key
app.post('/api/keys', (req, res) => {
  try {
    const { privateKey, address, confidence } = req.body;
    
    // Validate required fields
    if (!privateKey || !address) {
      return res.status(400).json({ error: 'Private key and address are required' });
    }
    
    // Create key record
    const key = {
      id: uuidv4(),
      privateKey,
      address,
      confidence: confidence || 0,
      verified: false,
      createdAt: Date.now()
    };
    
    // Store key
    keys.set(key.id, key);
    
    // Return created key
    res.status(201).json(key);
  } catch (error) {
    console.error('Error saving key:', error);
    res.status(500).json({ error: 'Failed to save key' });
  }
});

// Export analysis results
app.get('/api/analyses/:id/export', (req, res) => {
  const analysis = analyses.get(req.params.id);
  if (!analysis) {
    return res.status(404).json({ error: 'Analysis not found' });
  }
  
  // Generate JSON export
  const exportData = {
    analysis,
    keys: Array.from(keys.values()).filter((key: any) => key.analysisId === analysis.id),
    clusters: Array.from(clusters.values()).filter((cluster: Cluster) => cluster.analysisId === analysis.id)
  };
  
  // Set headers for file download
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename="analysis-${analysis.id.substring(0, 8)}.json"`);
  
  // Send JSON data
  res.json(exportData);
});

// Error handler
app.use((err: any, req: any, res: any, next: any) => {
  console.error('Server error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log(`Server listening on port ${port}`);
  console.log(`Mode: ${process.env.NODE_ENV || 'development'}`);
  console.log(`API available at http://localhost:${port}/api/health`);
  
  // Initialize worker pool
  const cpuCount = cpus().length;
  parallelProcessingManager.initializeWorkerPool(Math.max(2, cpuCount - 1));
  console.log(`Initialized worker pool with ${Math.max(2, cpuCount - 1)} workers`);
});

/**
 * Background task to run cryptographic analysis
 * @param analysisId Analysis ID
 */
async function runAnalysis(analysisId: string) {
  const analysis = analyses.get(analysisId);
  if (!analysis) return;
  
  try {
    // Get all transactions
    const txArray = Array.from(transactions.values());
    
    // Update progress
    analysis.progress = 5;
    analyses.set(analysisId, analysis);
    
    // Skip if no transactions
    if (txArray.length === 0) {
      analysis.status = 'completed';
      analysis.progress = 100;
      analysis.endTime = Date.now();
      analysis.results = { message: 'No transactions to analyze' };
      analyses.set(analysisId, analysis);
      return;
    }
    
    // Apply blockchain optimizations
    const optimizations = BlockchainOptimizer.findOptimizations(txArray);
    const optimizedTxs = BlockchainOptimizer.applyOptimizations(txArray, optimizations);
    
    // Update progress
    analysis.progress = 20;
    analyses.set(analysisId, analysis);
    
    // Perform signature clustering
    const detectedClusters = await SignatureClusterAnalyzer.analyzeTransactions(
      optimizedTxs
    );
    
    // Store clusters
    for (const cluster of detectedClusters) {
      cluster.analysisId = analysisId;
      clusters.set(cluster.id, cluster);
    }
    
    // Update progress
    analysis.progress = 40;
    analyses.set(analysisId, analysis);
    
    // Analyze signature patterns with AI (if enabled)
    let patternAnalysis = null;
    if (analysis.useAI) {
      try {
        patternAnalysis = await aiService.analyzeSignaturePatterns(
          optimizedTxs,
          { speed: analysis.speed }
        );
      } catch (error) {
        console.error('AI analysis failed, using fallback:', error);
        patternAnalysis = aiService.generateFallbackSignatureAnalysis(optimizedTxs);
      }
    } else {
      patternAnalysis = aiService.generateFallbackSignatureAnalysis(optimizedTxs);
    }
    
    // Update progress
    analysis.progress = 60;
    analyses.set(analysisId, analysis);
    
    // Detect nonce reuse
    let nonceReuseResult = null;
    try {
      nonceReuseResult = await aiService.detectNonceReuse(optimizedTxs);
    } catch (error) {
      console.error('Nonce reuse detection failed, using fallback:', error);
      nonceReuseResult = aiService.generateFallbackNonceReuseResult(optimizedTxs);
    }
    
    // Update progress
    analysis.progress = 80;
    analyses.set(analysisId, analysis);
    
    // Store results
    analysis.results = {
      optimizations,
      clusters: detectedClusters.map(c => c.id),
      patternAnalysis,
      nonceReuseResult
    };
    
    // Update analysis record
    analysis.status = 'completed';
    analysis.progress = 100;
    analysis.endTime = Date.now();
    analyses.set(analysisId, analysis);
    
  } catch (error) {
    console.error('Analysis failed:', error);
    
    // Update analysis record
    analysis.status = 'failed';
    analysis.progress = 0;
    analysis.endTime = Date.now();
    analysis.results = { error: 'Analysis failed' };
    analyses.set(analysisId, analysis);
  }
}