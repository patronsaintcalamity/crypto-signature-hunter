import { Transaction, Pattern, WizardStep, WizardState, PatternExplanation, PotentialVulnerability, AIAnalysisSuggestion } from '../shared/schema';
import { aiService } from './aiService';
import { cryptoAnalyzer } from './cryptoAnalyzer';
import { getAddressInfo } from './addressPatterns';
import * as crypto from 'crypto';

/**
 * Service for handling the pattern discovery wizard workflow
 */
export const wizardService = {
  /**
   * Initialize a new wizard session
   * @param transactions - Array of transactions to analyze
   * @returns Initial wizard state
   */
  async initializeWizard(transactions: Transaction[]): Promise<WizardState> {
    // Generate a unique session ID
    const sessionId = crypto.randomUUID();
    
    // Create the initial wizard state
    const initialState: WizardState = {
      sessionId,
      currentStep: 'initialize',
      progress: 0,
      transactions,
      detectedPatterns: [],
      selectedPatterns: [],
      potentialVulnerabilities: [],
      aiSuggestions: [],
      explanations: {},
      completed: false,
      createdAt: new Date().toISOString()
    };
    
    return initialState;
  },
  
  /**
   * Process the next step in the wizard
   * @param state - Current wizard state
   * @returns Updated wizard state
   */
  async processNextStep(state: WizardState): Promise<WizardState> {
    // Clone the state to avoid modifying the input
    const newState = { ...state };
    
    try {
      // Process based on current step
      switch (state.currentStep) {
        case 'initialize':
          return await this.performInitialAnalysis(newState);
          
        case 'pattern_detection':
          return await this.detectPatterns(newState);
          
        case 'pattern_selection':
          return await this.analyzeSelectedPatterns(newState);
          
        case 'vulnerability_analysis':
          return await this.explainVulnerabilities(newState);
          
        case 'exploitation_strategy':
          return await this.suggestExploitationStrategies(newState);
          
        case 'final_summary':
          // Mark the wizard as completed
          newState.completed = true;
          newState.progress = 100;
          return newState;
          
        default:
          throw new Error(`Unknown wizard step: ${state.currentStep}`);
      }
    } catch (error: any) {
      console.error(`Error processing wizard step ${state.currentStep}:`, error);
      newState.error = `Error in step ${state.currentStep}: ${error.message || 'Unknown error'}`;
      return newState;
    }
  },
  
  /**
   * Perform initial analysis of transactions
   * @param state - Current wizard state
   * @returns Updated wizard state with initial analysis
   */
  async performInitialAnalysis(state: WizardState): Promise<WizardState> {
    console.log(`Starting initial analysis for ${state.transactions.length} transactions`);
    
    // Update state
    const newState = { ...state };
    newState.progress = 10;
    
    // Group transactions by address
    const addressGroups: Record<string, Transaction[]> = {};
    state.transactions.forEach(tx => {
      if (tx.address) {
        if (!addressGroups[tx.address]) {
          addressGroups[tx.address] = [];
        }
        addressGroups[tx.address].push(tx);
      }
    });
    
    // Get address metadata
    const addressInfo = Object.keys(addressGroups).map(address => {
      const info = getAddressInfo(address);
      return {
        address,
        type: info?.name || 'Unknown',
        era: info?.yearIntroduced ? `${info.yearIntroduced}` : 'Unknown',
        transactionCount: addressGroups[address].length,
        knownVulnerabilities: info?.likelyVulnerabilities || []
      };
    });
    
    // Add to state
    newState.addressInfo = addressInfo;
    
    // Look for any direct nonce reuse (quick check)
    const nonceReuseResult = await aiService.detectNonceReuse(state.transactions);
    if (nonceReuseResult.detectedReuse && nonceReuseResult.confidence > 0.6) {
      newState.potentialVulnerabilities.push({
        type: 'nonce_reuse',
        confidence: nonceReuseResult.confidence,
        description: 'Potential nonce reuse detected',
        details: nonceReuseResult.explanation,
        affectedTransactions: nonceReuseResult.affectedTransactions,
        severity: 'critical'
      });
    }
    
    // Move to the next step
    newState.currentStep = 'pattern_detection';
    newState.progress = 20;
    
    return newState;
  },
  
  /**
   * Detect cryptographic patterns in the transactions
   * @param state - Current wizard state
   * @returns Updated wizard state with detected patterns
   */
  async detectPatterns(state: WizardState): Promise<WizardState> {
    console.log('Detecting cryptographic patterns');
    
    // Update state
    const newState = { ...state };
    newState.progress = 30;
    
    try {
      // Use the pattern recognition from cryptoAnalyzer
      const patterns = await cryptoAnalyzer.performPatternRecognition(
        state.transactions, 
        8 // Higher depth for more thorough analysis
      );
      
      // Sort patterns by confidence (descending)
      patterns.sort((a, b) => (b.confidence || 0) - (a.confidence || 0));
      
      // Store detected patterns
      newState.detectedPatterns = patterns;
      
      try {
        // Get AI insights for the patterns
        const aiAnalysis = await aiService.analyzeSignaturePatterns(state.transactions);
        
        // Add AI suggestions
        newState.aiSuggestions = aiAnalysis.patterns.map(p => ({
          name: p.name,
          description: p.description,
          confidence: p.confidence,
          suggestedAction: p.suggestedAction,
          affectedTransactions: p.transactions
        }));
        
        // Update risk assessment
        newState.overallRisk = aiAnalysis.overallRisk;
        newState.riskSummary = aiAnalysis.summary;
      } catch (aiError) {
        console.error('AI analysis error:', aiError);
        // Continue with basic analysis if AI fails
        newState.aiSuggestions = [];
        newState.riskSummary = "AI analysis unavailable. Basic pattern detection applied.";
      }
      
      // Move to the next step
      newState.currentStep = 'pattern_selection';
      newState.progress = 40;
      
      return newState;
    } catch (error: any) {
      console.error('Error detecting patterns:', error);
      newState.error = `Error detecting patterns: ${error.message || 'Unknown error'}`;
      return newState;
    }
  },
  
  /**
   * Analyze selected patterns in more depth
   * @param state - Current wizard state
   * @returns Updated wizard state with detailed pattern analysis
   */
  async analyzeSelectedPatterns(state: WizardState): Promise<WizardState> {
    console.log(`Analyzing ${state.selectedPatterns.length} selected patterns`);
    
    // Update state
    const newState = { ...state };
    newState.progress = 60;
    
    // If no patterns were selected, use the highest confidence ones
    if (!state.selectedPatterns || state.selectedPatterns.length === 0) {
      newState.selectedPatterns = state.detectedPatterns
        .filter(p => (p.confidence || 0) > 0.7)
        .slice(0, 3)
        .map(p => p.id);
    }
    
    try {
      // Get the full pattern objects for the selected IDs
      const selectedPatternObjects = state.detectedPatterns.filter(
        p => newState.selectedPatterns.includes(p.id)
      );
      
      // Generate explanations for each selected pattern
      const explanations: Record<string, PatternExplanation> = {};
      
      for (const pattern of selectedPatternObjects) {
        // Skip patterns without transactions
        if (!pattern.transactions || !Array.isArray(pattern.transactions)) continue;
        
        // Find transactions relevant to this pattern
        const relevantTransactions = state.transactions.filter(
          tx => pattern.transactions && pattern.transactions.includes(tx.id)
        );
        
        try {
          // Get AI explanation
          const explanation = await aiService.explainPatternWeakness(pattern, relevantTransactions);
          
          // Store formatted explanation
          explanations[pattern.id] = {
            patternId: pattern.id,
            title: explanation.title,
            technicalDescription: explanation.technicalDescription,
            simplifiedDescription: explanation.simplifiedDescription,
            exploitDifficulty: explanation.exploitDifficulty,
            mitigationSuggestions: explanation.mitigationSuggestions,
            historicalContext: explanation.historicalContext,
            references: explanation.references
          };
        } catch (aiError) {
          console.error(`Error getting AI explanation for pattern ${pattern.id}:`, aiError);
          // Provide a fallback explanation
          explanations[pattern.id] = {
            patternId: pattern.id,
            title: `${pattern.name || 'Unknown Pattern'} Analysis`,
            technicalDescription: "AI analysis unavailable. This pattern may contain cryptographic vulnerabilities.",
            simplifiedDescription: "AI explanation service unavailable. Basic analysis shows potential signature weaknesses.",
            exploitDifficulty: 3, // Medium difficulty as default
            mitigationSuggestions: ["Use more secure signature algorithms", "Ensure proper randomness in nonce generation"],
            historicalContext: "Similar signature patterns have been exploited in the past.",
            references: ["https://en.bitcoin.it/wiki/Secp256k1"]
          };
        }
      }
      
      // Update state with explanations
      newState.explanations = explanations;
      
      // Move to the next step
      newState.currentStep = 'vulnerability_analysis';
      newState.progress = 70;
      
      return newState;
    } catch (error: any) {
      console.error('Error analyzing selected patterns:', error);
      newState.error = `Error analyzing patterns: ${error.message || 'Unknown error'}`;
      return newState;
    }
  },
  
  /**
   * Generate detailed explanations of the detected vulnerabilities
   * @param state - Current wizard state
   * @returns Updated wizard state with vulnerability explanations
   */
  async explainVulnerabilities(state: WizardState): Promise<WizardState> {
    console.log('Generating vulnerability explanations');
    
    // Update state
    const newState = { ...state };
    newState.progress = 80;
    
    try {
      // For each selected pattern, optimize a brute force strategy
      const strategies: Record<string, any> = {};
      
      for (const patternId of state.selectedPatterns) {
        // Find the pattern and related transactions
        const pattern = state.detectedPatterns.find(p => p.id === patternId);
        
        if (pattern && pattern.transactions && Array.isArray(pattern.transactions)) {
          const relatedTransactions = state.transactions.filter(
            tx => pattern.transactions && pattern.transactions.includes(tx.id)
          );
          
          try {
            // Get brute force strategy recommendation from AI
            const strategy = await aiService.optimizeBruteForceStrategy(pattern, relatedTransactions);
            
            // Store strategy
            strategies[patternId] = strategy;
          } catch (aiError) {
            console.error(`Error getting brute force strategy for pattern ${pattern.id}:`, aiError);
            // Provide a fallback strategy
            strategies[patternId] = {
              suggestedPrefixes: [(pattern.name || "").substring(0, 3).toLowerCase()],
              prefixConfidence: 0.5,
              nonceEstimatedLength: 32,
              recommendedAlgorithm: "incremental-search",
              expectedTimeToComplete: "Unknown (AI analysis unavailable)",
              parallelizationSuggestion: "Use multiple CPU cores if available"
            };
          }
        }
      }
      
      // Update state with strategies
      newState.exploitationStrategies = strategies;
      
      // Move to the next step
      newState.currentStep = 'exploitation_strategy';
      newState.progress = 90;
      
      return newState;
    } catch (error: any) {
      console.error('Error explaining vulnerabilities:', error);
      newState.error = `Error explaining vulnerabilities: ${error.message || 'Unknown error'}`;
      return newState;
    }
  },
  
  /**
   * Suggest strategies for exploiting the detected vulnerabilities
   * @param state - Current wizard state
   * @returns Updated wizard state with exploitation strategies
   */
  async suggestExploitationStrategies(state: WizardState): Promise<WizardState> {
    console.log('Suggesting exploitation strategies');
    
    // Update state
    const newState = { ...state };
    newState.progress = 95;
    
    try {
      // Estimate success probability for each pattern
      const successProbabilities: Record<string, number> = {};
      const estimatedTimeToKeys: Record<string, string> = {};
      
      for (const patternId of state.selectedPatterns) {
        const pattern = state.detectedPatterns.find(p => p.id === patternId);
        const strategy = state.exploitationStrategies?.[patternId];
        
        if (pattern && strategy && pattern.confidence !== null && pattern.confidence !== undefined) {
          // Calculate a success probability based on pattern confidence and strategy
          const successProbability = (pattern.confidence || 0) * (strategy.prefixConfidence || 0.5);
          successProbabilities[patternId] = parseFloat(successProbability.toFixed(2));
          
          // Store estimated time
          estimatedTimeToKeys[patternId] = strategy.expectedTimeToComplete || 'Unknown';
        }
      }
      
      // Update state
      newState.successProbabilities = successProbabilities;
      newState.estimatedTimeToKeys = estimatedTimeToKeys;
      
      // Move to final step
      newState.currentStep = 'final_summary';
      newState.progress = 98;
      
      return newState;
    } catch (error: any) {
      console.error('Error suggesting exploitation strategies:', error);
      newState.error = `Error suggesting strategies: ${error.message || 'Unknown error'}`;
      return newState;
    }
  }
};