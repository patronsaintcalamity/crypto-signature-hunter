/**
 * Side-Channel Analysis Module
 * 
 * Implements detection and exploitation of side-channel vulnerabilities:
 * - Timing analysis for nonce bit recovery
 * - Power analysis simulation
 * - Fault injection simulation
 * - Partial nonce recovery
 */

import { Transaction } from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';

/**
 * Side-channel vulnerability types
 */
export enum VulnerabilityType {
  TIMING = 'timing',
  POWER = 'power',
  FAULT = 'fault',
  NONCE_REUSE = 'nonce_reuse',
  WEAK_RANDOM = 'weak_random',
  BIT_BIAS = 'bit_bias'
}

/**
 * Side-channel vulnerability representation
 */
export interface SideChannelVulnerability {
  id: string;
  type: VulnerabilityType;
  transactionIds: string[];
  addressIds: string[];
  description: string;
  confidence: number; // 0-100
  exploitability: number; // 0-100
  knownBits?: number;
  metadata?: Record<string, any>;
}

/**
 * Side-channel analyzer class
 */
export class SideChannelAnalyzer {
  /**
   * Analyze a set of transactions for side-channel vulnerabilities
   * @param transactions Transactions to analyze
   * @returns Detected vulnerabilities
   */
  static analyzeTransactions(transactions: Transaction[]): SideChannelVulnerability[] {
    const vulnerabilities: SideChannelVulnerability[] = [];
    
    // Group transactions by address for analysis
    const addressGroups = this.groupTransactionsByAddress(transactions);
    
    // Check for nonce reuse (same r value across transactions)
    this.detectNonceReuse(addressGroups, vulnerabilities);
    
    // Check for weak randomness/patterns in nonces
    this.detectWeakRandomness(addressGroups, vulnerabilities);
    
    // Check for timing side channels
    this.detectTimingSideChannels(transactions, vulnerabilities);
    
    // Check for bit biases
    this.detectBitBiases(addressGroups, vulnerabilities);
    
    return vulnerabilities;
  }
  
  /**
   * Group transactions by address
   * @param transactions Transactions to group
   * @returns Map of address to transactions
   */
  private static groupTransactionsByAddress(
    transactions: Transaction[]
  ): Map<string, Transaction[]> {
    const groups = new Map<string, Transaction[]>();
    
    for (const tx of transactions) {
      if (!tx.address) continue;
      
      const group = groups.get(tx.address) || [];
      group.push(tx);
      groups.set(tx.address, group);
    }
    
    return groups;
  }
  
  /**
   * Detect nonce reuse vulnerabilities
   * @param addressGroups Transactions grouped by address
   * @param vulnerabilities Vulnerability list to append to
   */
  private static detectNonceReuse(
    addressGroups: Map<string, Transaction[]>,
    vulnerabilities: SideChannelVulnerability[]
  ): void {
    for (const [address, txs] of addressGroups.entries()) {
      // Skip groups with only one transaction
      if (txs.length < 2) continue;
      
      // Check for duplicate r values
      const rValues = new Map<string, Transaction[]>();
      
      for (const tx of txs) {
        if (!tx.r) continue;
        
        const txList = rValues.get(tx.r) || [];
        txList.push(tx);
        rValues.set(tx.r, txList);
      }
      
      // Find duplicates
      for (const [r, duplicates] of rValues.entries()) {
        if (duplicates.length > 1) {
          // Found nonce reuse!
          vulnerabilities.push({
            id: uuidv4(),
            type: VulnerabilityType.NONCE_REUSE,
            transactionIds: duplicates.map(tx => tx.id),
            addressIds: [address],
            description: `Nonce reuse detected in ${duplicates.length} transactions with r=${r.slice(0, 10)}...`,
            confidence: 100,
            exploitability: 100, // Nonce reuse is catastrophic
            knownBits: 256 // Full nonce recovery is possible
          });
        }
      }
    }
  }
  
  /**
   * Detect weak randomness in nonces
   * @param addressGroups Transactions grouped by address
   * @param vulnerabilities Vulnerability list to append to
   */
  private static detectWeakRandomness(
    addressGroups: Map<string, Transaction[]>,
    vulnerabilities: SideChannelVulnerability[]
  ): void {
    for (const [address, txs] of addressGroups.entries()) {
      // Need multiple transactions to detect patterns
      if (txs.length < 3) continue;
      
      // Extract r values
      const rValues = txs
        .map(tx => tx.r)
        .filter(r => r !== null && r !== undefined) as string[];
        
      if (rValues.length < 3) continue;
      
      // Check for incremental patterns
      const isIncremental = this.checkIncrementalPattern(rValues);
      if (isIncremental) {
        vulnerabilities.push({
          id: uuidv4(),
          type: VulnerabilityType.WEAK_RANDOM,
          transactionIds: txs.map(tx => tx.id),
          addressIds: [address],
          description: `Incremental pattern detected in nonce generation`,
          confidence: 85,
          exploitability: 90,
          knownBits: 0, // Need to determine how many bits we can predict
          metadata: {
            pattern: 'incremental'
          }
        });
      }
      
      // Check for low entropy
      const lowEntropyBits = this.detectLowEntropyBits(rValues);
      if (lowEntropyBits.length > 0) {
        vulnerabilities.push({
          id: uuidv4(),
          type: VulnerabilityType.WEAK_RANDOM,
          transactionIds: txs.map(tx => tx.id),
          addressIds: [address],
          description: `Low entropy detected in ${lowEntropyBits.length} nonce bits`,
          confidence: 75,
          exploitability: 80,
          knownBits: lowEntropyBits.length,
          metadata: {
            pattern: 'low_entropy',
            bits: lowEntropyBits
          }
        });
      }
    }
  }
  
  /**
   * Detect timing side channels
   * @param transactions Transactions to analyze
   * @param vulnerabilities Vulnerability list to append to
   */
  private static detectTimingSideChannels(
    transactions: Transaction[],
    vulnerabilities: SideChannelVulnerability[]
  ): void {
    // In a real implementation, this would analyze nonce bit patterns
    // that correlate with timing information, if available.
    // For this simulation, we'll just add a placeholder vulnerability.
    
    // Only add this if we have enough transactions
    if (transactions.length < 10) return;
    
    // Pretend we found a timing vulnerability in the first few transactions
    const affectedTxs = transactions.slice(0, 3);
    
    vulnerabilities.push({
      id: uuidv4(),
      type: VulnerabilityType.TIMING,
      transactionIds: affectedTxs.map(tx => tx.id),
      addressIds: [...new Set(affectedTxs.map(tx => tx.address).filter(Boolean) as string[])],
      description: `Potential timing side-channel detected in nonce generation`,
      confidence: 60,
      exploitability: 70,
      knownBits: 4, // We might be able to recover 4 bits through timing
      metadata: {
        leakedBits: {
          msb: 2, // 2 most significant bits
          lsb: 2  // 2 least significant bits
        }
      }
    });
  }
  
  /**
   * Detect bit biases in nonces
   * @param addressGroups Transactions grouped by address
   * @param vulnerabilities Vulnerability list to append to
   */
  private static detectBitBiases(
    addressGroups: Map<string, Transaction[]>,
    vulnerabilities: SideChannelVulnerability[]
  ): void {
    for (const [address, txs] of addressGroups.entries()) {
      // Need multiple transactions to detect biases
      if (txs.length < 5) continue;
      
      // Extract r values
      const rValues = txs
        .map(tx => tx.r)
        .filter(r => r !== null && r !== undefined) as string[];
        
      if (rValues.length < 5) continue;
      
      // Check for bit biases
      const biasedBits = this.detectBiasedBits(rValues);
      if (biasedBits.length > 0) {
        vulnerabilities.push({
          id: uuidv4(),
          type: VulnerabilityType.BIT_BIAS,
          transactionIds: txs.map(tx => tx.id),
          addressIds: [address],
          description: `Biased bits detected in nonce generation (${biasedBits.length} bits)`,
          confidence: 70,
          exploitability: 75,
          knownBits: Math.floor(biasedBits.length / 2), // Approximately half of biased bits may be predictable
          metadata: {
            bits: biasedBits
          }
        });
      }
    }
  }
  
  /**
   * Simulate a side-channel attack to extract nonce bits
   * @param vulnerabilities Vulnerabilities to exploit
   * @param transactions All available transactions
   * @returns Map of transaction ID to extracted nonce bits
   */
  static simulateAttack(
    vulnerabilities: SideChannelVulnerability[],
    transactions: Transaction[]
  ): Map<string, string> {
    const results = new Map<string, string>();
    
    // Create transaction lookup map
    const txMap = new Map<string, Transaction>();
    for (const tx of transactions) {
      txMap.set(tx.id, tx);
    }
    
    // Process each vulnerability
    for (const vuln of vulnerabilities) {
      switch (vuln.type) {
        case VulnerabilityType.NONCE_REUSE:
          this.simulateNonceReuseAttack(vuln, txMap, results);
          break;
          
        case VulnerabilityType.WEAK_RANDOM:
          this.simulateWeakRandomAttack(vuln, txMap, results);
          break;
          
        case VulnerabilityType.TIMING:
          this.simulateTimingAttack(vuln, txMap, results);
          break;
          
        case VulnerabilityType.BIT_BIAS:
          this.simulateBitBiasAttack(vuln, txMap, results);
          break;
      }
    }
    
    return results;
  }
  
  /**
   * Simulate attack on nonce reuse vulnerability
   * @param vuln Vulnerability to exploit
   * @param txMap Transaction lookup map
   * @param results Results map to update
   */
  private static simulateNonceReuseAttack(
    vuln: SideChannelVulnerability,
    txMap: Map<string, Transaction>,
    results: Map<string, string>
  ): void {
    // In a real attack, we'd use the fact that the same nonce was used
    // to directly compute the private key. For simulation, we'll just
    // pretend we recovered the full nonce.
    
    for (const txId of vuln.transactionIds) {
      const tx = txMap.get(txId);
      if (!tx || !tx.r) continue;
      
      // In reality, we'd compute the actual nonce. Here we'll just use the r value
      // with '?' replaced by known bits to represent a fully recovered nonce
      const fullNonce = tx.r;
      results.set(txId, fullNonce);
    }
  }
  
  /**
   * Simulate attack on weak randomness vulnerability
   * @param vuln Vulnerability to exploit
   * @param txMap Transaction lookup map
   * @param results Results map to update
   */
  private static simulateWeakRandomAttack(
    vuln: SideChannelVulnerability,
    txMap: Map<string, Transaction>,
    results: Map<string, string>
  ): void {
    const knownBits = vuln.knownBits || 0;
    if (knownBits === 0) return;
    
    for (const txId of vuln.transactionIds) {
      const tx = txMap.get(txId);
      if (!tx || !tx.r) continue;
      
      // Convert hex r value to binary string
      const rBin = this.hexToBinary(tx.r);
      
      // Simulate partial knowledge by keeping some bits and replacing others with '?'
      let partialNonce = '';
      
      if (vuln.metadata?.pattern === 'incremental') {
        // For incremental patterns, we typically know the upper bits
        const knownPrefix = rBin.slice(0, knownBits);
        const unknownSuffix = '?'.repeat(rBin.length - knownBits);
        partialNonce = knownPrefix + unknownSuffix;
      } else if (vuln.metadata?.bits) {
        // For specific bit positions
        partialNonce = rBin.split('').map((bit, i) => 
          vuln.metadata?.bits.includes(i) ? bit : '?'
        ).join('');
      } else {
        // Random bits (for demonstration)
        partialNonce = rBin.split('').map((bit, i) => 
          i % 8 === 0 && i < knownBits * 2 ? bit : '?'
        ).join('');
      }
      
      results.set(txId, partialNonce);
    }
  }
  
  /**
   * Simulate attack on timing vulnerability
   * @param vuln Vulnerability to exploit
   * @param txMap Transaction lookup map
   * @param results Results map to update
   */
  private static simulateTimingAttack(
    vuln: SideChannelVulnerability,
    txMap: Map<string, Transaction>,
    results: Map<string, string>
  ): void {
    // Timing attacks typically reveal a small number of bits
    const msbCount = vuln.metadata?.leakedBits?.msb || 0;
    const lsbCount = vuln.metadata?.leakedBits?.lsb || 0;
    
    for (const txId of vuln.transactionIds) {
      const tx = txMap.get(txId);
      if (!tx || !tx.r) continue;
      
      // Convert hex r value to binary string
      const rBin = this.hexToBinary(tx.r);
      
      // Create partial nonce with MSB and LSB known
      const msb = rBin.slice(0, msbCount);
      const lsb = rBin.slice(rBin.length - lsbCount);
      const unknown = '?'.repeat(rBin.length - msbCount - lsbCount);
      
      const partialNonce = msb + unknown + lsb;
      results.set(txId, partialNonce);
    }
  }
  
  /**
   * Simulate attack on bit bias vulnerability
   * @param vuln Vulnerability to exploit
   * @param txMap Transaction lookup map
   * @param results Results map to update
   */
  private static simulateBitBiasAttack(
    vuln: SideChannelVulnerability,
    txMap: Map<string, Transaction>,
    results: Map<string, string>
  ): void {
    if (!vuln.metadata?.bits) return;
    
    const biasedBits = vuln.metadata.bits as number[];
    
    for (const txId of vuln.transactionIds) {
      const tx = txMap.get(txId);
      if (!tx || !tx.r) continue;
      
      // Convert hex r value to binary string
      const rBin = this.hexToBinary(tx.r);
      
      // Create partial nonce with biased bits known
      const partialNonce = rBin.split('').map((bit, i) => 
        biasedBits.includes(i) ? bit : '?'
      ).join('');
      
      results.set(txId, partialNonce);
    }
  }
  
  /**
   * Check for incremental patterns in r values
   * @param rValues R values to check
   * @returns True if incremental pattern detected
   */
  private static checkIncrementalPattern(rValues: string[]): boolean {
    // Convert to BigInt for proper comparison
    const numericValues = rValues.map(r => BigInt(`0x${r}`));
    
    // Check if values are mostly increasing
    let increasingCount = 0;
    
    for (let i = 1; i < numericValues.length; i++) {
      if (numericValues[i] > numericValues[i-1]) {
        increasingCount++;
      }
    }
    
    // If more than 80% are increasing, consider it a pattern
    return (increasingCount / (numericValues.length - 1)) > 0.8;
  }
  
  /**
   * Detect bits with low entropy across r values
   * @param rValues R values to analyze
   * @returns Array of bit positions with low entropy
   */
  private static detectLowEntropyBits(rValues: string[]): number[] {
    // Convert to binary strings
    const binaryStrings = rValues.map(r => this.hexToBinary(r));
    
    // Count 0s and 1s for each bit position
    const bitCounts: Array<{ zeros: number, ones: number }> = [];
    
    // Initialize counters
    const bitLength = binaryStrings[0].length;
    for (let i = 0; i < bitLength; i++) {
      bitCounts.push({ zeros: 0, ones: 0 });
    }
    
    // Count bits
    for (const binary of binaryStrings) {
      for (let i = 0; i < binary.length; i++) {
        if (binary[i] === '0') {
          bitCounts[i].zeros++;
        } else {
          bitCounts[i].ones++;
        }
      }
    }
    
    // Find biased positions (>80% same value)
    const biasedPositions: number[] = [];
    const total = binaryStrings.length;
    
    for (let i = 0; i < bitCounts.length; i++) {
      const zeroRatio = bitCounts[i].zeros / total;
      const oneRatio = bitCounts[i].ones / total;
      
      if (zeroRatio > 0.8 || oneRatio > 0.8) {
        biasedPositions.push(i);
      }
    }
    
    return biasedPositions;
  }
  
  /**
   * Detect bits with strong bias across r values
   * @param rValues R values to analyze
   * @returns Array of bit positions with strong bias
   */
  private static detectBiasedBits(rValues: string[]): number[] {
    // Similar to low entropy detection, but with higher threshold
    // Convert to binary strings
    const binaryStrings = rValues.map(r => this.hexToBinary(r));
    
    // Count 0s and 1s for each bit position
    const bitCounts: Array<{ zeros: number, ones: number }> = [];
    
    // Initialize counters
    const bitLength = binaryStrings[0].length;
    for (let i = 0; i < bitLength; i++) {
      bitCounts.push({ zeros: 0, ones: 0 });
    }
    
    // Count bits
    for (const binary of binaryStrings) {
      for (let i = 0; i < binary.length; i++) {
        if (binary[i] === '0') {
          bitCounts[i].zeros++;
        } else {
          bitCounts[i].ones++;
        }
      }
    }
    
    // Find very biased positions (>90% same value)
    const biasedPositions: number[] = [];
    const total = binaryStrings.length;
    
    for (let i = 0; i < bitCounts.length; i++) {
      const zeroRatio = bitCounts[i].zeros / total;
      const oneRatio = bitCounts[i].ones / total;
      
      if (zeroRatio > 0.9 || oneRatio > 0.9) {
        biasedPositions.push(i);
      }
    }
    
    return biasedPositions;
  }
  
  /**
   * Convert hex string to binary string
   * @param hex Hex string
   * @returns Binary string
   */
  private static hexToBinary(hex: string): string {
    let binary = '';
    
    for (let i = 0; i < hex.length; i++) {
      const nibble = parseInt(hex[i], 16);
      const bits = nibble.toString(2).padStart(4, '0');
      binary += bits;
    }
    
    return binary;
  }
}