// Simple test for our cryptographic functions
import { cryptoAnalyzer } from './cryptoAnalyzer';
import { blockchainAPI } from './blockchainAPI';
import { storage } from './storage';

// Example Bitcoin transaction signature components
// These are just examples - not real transaction data
const mockTransaction = {
  id: "test-tx-1",
  txid: "c1ae92f67d0ca19e9cbcec1d0a4a5cc4ac95048b52d3b137bfa5a2c7c0ef7a0e",
  address: "1NUnbngzRB2SeMqZLrLrypoYW5FrusVU3X",
  r: "c987db3f3e55e94d0c92e797d0a359157ae80a597893ffc1c2e42ac695be8a4e",
  s: "2dd74e08ca2d0b1ce54b83c4cc9a6067b7b61d79b3fb097c8c5a0f0f2c7c79b5",
  z: "21d1f707c0cc16cd6577c99fd38a47d1ba07391e67db9c8b56a50642f1e91d87",
  pubkey: "0470be51d46e22a2c9a4b4be3e5358c3e2500b350c4e1d0fc2be79c9f27c37c5c398c32c87d411d1e769bdcce16f2d4d5a8f99215cff4f4e18d92aa2db5cb6ede7",
  blockHeight: 680000,
  patternId: null,
  patternName: null,
  confidence: 75,
  status: "confirmed",
  createdAt: new Date().toISOString()
};

// Create a mock pattern for testing
const mockPattern = {
  id: "test-pattern-1",
  name: "Test Pattern #1",
  confidence: 80,
  transactionCount: 1,
  characteristics: "Test pattern for simulation",
  affectedAddresses: [mockTransaction.address],
  transactions: [mockTransaction.id],
  nonceReconstructed: false,
  nonceValue: null,
  partialNonce: null,
  bruteForcedNonces: null,
  reconstructionProgress: 0,
  bruteForcingProgress: 0,
  discoveredAt: new Date().toISOString()
};

async function runTests() {
  console.log("Starting cryptographic function tests...");

  // 1. Test nonce validation
  console.log("\n1. Testing Nonce Validation");
  const testNonce = "7f" + cryptoAnalyzer.generateHexString(62);
  const validationResult = cryptoAnalyzer.validateNonce(testNonce, mockTransaction, true);
  console.log(`Nonce validation result: ${validationResult ? "Valid" : "Invalid"}`);

  // 2. Test WIF key generation
  console.log("\n2. Testing WIF key generation");
  const privateKeyHex = "ef235aadcedae0af930b6ca91b0fd458831f4a800c6a2e3a109b789e6860ab90";
  const wifKey = cryptoAnalyzer.privateKeyToWIF(privateKeyHex);
  console.log(`Generated WIF key: ${wifKey}`);

  // 3. Test key verification
  console.log("\n3. Testing key verification");
  const verificationResult = await blockchainAPI.verifyPrivateKey(
    mockTransaction.address,
    privateKeyHex
  );
  console.log(`Key verification result: ${verificationResult ? "Valid" : "Invalid"}`);

  // 4. Store the mock transaction and pattern for testing
  console.log("\n4. Storing mock data for testing");
  await storage.saveTransactions([mockTransaction]);
  await storage.savePatterns([mockPattern]);
  console.log("Mock data stored successfully");

  // 5. Test nonce reconstruction
  console.log("\n5. Testing nonce reconstruction");
  await cryptoAnalyzer.reconstructNonces(mockPattern, true);
  const updatedPattern = await storage.getPatternById(mockPattern.id);
  console.log(`Nonce reconstruction completed. Result:`, {
    nonceReconstructed: updatedPattern?.nonceReconstructed,
    reconstructionProgress: updatedPattern?.reconstructionProgress,
    nonceValue: updatedPattern?.nonceValue ? updatedPattern.nonceValue.substring(0, 10) + '...' : null
  });
  
  // Update pattern confidence for key derivation test
  if (updatedPattern) {
    // Get the updated pattern with the new nonce value
    const refreshedPattern = await storage.getPatternById(updatedPattern.id);
    if (refreshedPattern) {
      await storage.updatePattern(refreshedPattern.id, {
        ...refreshedPattern,
        confidence: 90 // Boosting confidence to pass the filter threshold
      });
      
      // Fetch the transaction and update it with the derived pattern info
      const tx = await storage.getTransactionsByIds([mockTransaction.id]);
      if (tx.length > 0) {
        await storage.updateTransaction(tx[0].id, {
          ...tx[0],
          patternId: refreshedPattern.id,
          patternName: refreshedPattern.name,
          confidence: 95
        });
      }
    }
  }

  // 6. Test private key derivation with manual approach
  console.log("\n6. Testing private key derivation with manual approach");
  
  // Get the refreshed pattern to make sure we have the latest data
  const finalPattern = await storage.getPatternById(mockPattern.id);
  const finalTransaction = await storage.getTransactionsByIds([mockTransaction.id]);
  
  if (finalPattern && finalTransaction.length > 0) {
    try {
      const tx = finalTransaction[0];
      
      // Get signature components
      const r = BigInt(`0x${tx.r}`);
      const s = BigInt(`0x${tx.s}`);
      const z = BigInt(`0x${tx.z}`);
      
      // Get nonce from the pattern
      if (finalPattern.nonceValue && /^[0-9a-f]+$/i.test(finalPattern.nonceValue)) {
        const k = BigInt(`0x${finalPattern.nonceValue}`);
        
        // Calculate private key
        const n = BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141');
        
        // d = ((s * k - z) * modInverse(r, n)) % n
        const sk = (s * k) % n;
        let intermediate = (sk - z) % n;
        if (intermediate < 0n) intermediate = (intermediate + n) % n;
        
        const rInverse = cryptoAnalyzer.modInverse(r, n);
        const privateKey = (intermediate * rInverse) % n;
        
        // Convert to hex
        let privateKeyHex = privateKey.toString(16);
        while (privateKeyHex.length < 64) privateKeyHex = '0' + privateKeyHex;
        
        // Generate WIF
        const wifKey = cryptoAnalyzer.privateKeyToWIF(privateKeyHex);
        
        // Verify key
        const verified = await blockchainAPI.verifyPrivateKey(tx.address, privateKeyHex);
        
        console.log(`Manually derived key for address ${tx.address}, verification: ${verified ? 'Valid' : 'Invalid'}`);
        console.log(`Key (hex): ${privateKeyHex.substring(0, 12)}...${privateKeyHex.substring(52)}`);
        console.log(`WIF key: ${wifKey.substring(0, 15)}...${wifKey.substring(wifKey.length - 10)}`);
        
        // Test the actual function
        const keys = await cryptoAnalyzer.derivePrivateKeys([{
          ...finalPattern,
          confidence: 90 // Ensure confidence is high enough
        }]);
        
        console.log(`Derived ${keys.length} keys using derivePrivateKeys function`);
        if (keys.length > 0) {
          console.log(`First key details: address=${keys[0].address}, verification=${keys[0].verification}`);
          const keyPreview = keys[0].privateKey.substring(0, 15) + '...';
          console.log(`Key preview: ${keyPreview}`);
        }
      } else {
        console.log('No valid nonce available for key derivation test');
      }
    } catch (error) {
      console.error('Error in manual key derivation:', error);
    }
  }

  console.log("\nAll tests completed");
}

// Run the tests
runTests().catch(error => {
  console.error("Error during tests:", error);
});