import fs from 'fs';
import path from 'path';
import { Transaction, Pattern, Key } from '@shared/schema';
import { storage } from './storage';

/**
 * Service for handling export and import of analysis data
 */
export const exportImportService = {
  /**
   * Export patterns and their associated data
   * @param patternIds Array of pattern IDs to export
   * @returns JSON string with exported data
   */
  async exportPatterns(patternIds: string[]): Promise<string> {
    try {
      // Get patterns to export
      const allPatterns = await storage.getPatterns();
      const patternsToExport = allPatterns.filter(pattern => patternIds.includes(pattern.id));
      
      if (patternsToExport.length === 0) {
        throw new Error('No valid patterns found for export');
      }
      
      // Get all transactions
      const transactionIds = patternsToExport.flatMap(p => p.transactions ? p.transactions : []);
      const transactions = await storage.getTransactionsByIds(transactionIds);
      
      // Get keys associated with these patterns
      const allKeys = await storage.getKeys();
      const keys = allKeys.filter(key => key.patternId && patternIds.includes(key.patternId));
      
      // Create export object
      const exportData = {
        exportDate: new Date().toISOString(),
        patterns: patternsToExport,
        transactions,
        keys,
        version: '1.0'
      };
      
      return JSON.stringify(exportData, null, 2);
    } catch (error) {
      console.error('Error exporting patterns:', error);
      throw error;
    }
  },
  
  /**
   * Export patterns to a file
   * @param patternIds Array of pattern IDs to export
   * @param filePath Path to save the export file
   * @returns Path to the saved file
   */
  async exportPatternsToFile(patternIds: string[], filePath: string): Promise<string> {
    try {
      const exportData = await this.exportPatterns(patternIds);
      
      // Ensure directory exists
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      // Write export file
      await fs.promises.writeFile(filePath, exportData, 'utf8');
      
      return filePath;
    } catch (error) {
      console.error('Error exporting patterns to file:', error);
      throw error;
    }
  },
  
  /**
   * Import patterns from a JSON string
   * @param jsonData JSON string with pattern data
   * @returns Import summary
   */
  async importPatterns(jsonData: string): Promise<{
    patternsImported: number;
    transactionsImported: number;
    keysImported: number;
  }> {
    try {
      // Parse import data
      const importData = JSON.parse(jsonData);
      
      if (!importData.patterns || !importData.transactions) {
        throw new Error('Invalid import format: missing required data');
      }
      
      // Import transactions first
      await storage.saveTransactions(importData.transactions);
      
      // Import patterns
      await storage.savePatterns(importData.patterns);
      
      // Import keys if present
      const keysImported = importData.keys?.length || 0;
      if (keysImported > 0) {
        await storage.saveKeys(importData.keys);
      }
      
      return {
        patternsImported: importData.patterns.length,
        transactionsImported: importData.transactions.length,
        keysImported
      };
    } catch (error) {
      console.error('Error importing patterns:', error);
      throw error;
    }
  },
  
  /**
   * Import patterns from a file
   * @param filePath Path to the import file
   * @returns Import summary
   */
  async importPatternsFromFile(filePath: string): Promise<{
    patternsImported: number;
    transactionsImported: number;
    keysImported: number;
  }> {
    try {
      // Read and parse file
      const fileData = await fs.promises.readFile(filePath, 'utf8');
      return await this.importPatterns(fileData);
    } catch (error) {
      console.error('Error importing patterns from file:', error);
      throw error;
    }
  },
  
  /**
   * Export partially reconstructed nonces for external processing
   * @param patternIds Array of pattern IDs to export
   * @returns JSON string with partial nonce data
   */
  async exportPartialNonces(patternIds: string[]): Promise<string> {
    try {
      // Get patterns with partial nonces
      const allPatterns = await storage.getPatterns();
      const patternsWithNonces = allPatterns.filter(
        pattern => patternIds.includes(pattern.id) && pattern.partialNonce
      );
      
      if (patternsWithNonces.length === 0) {
        throw new Error('No patterns with partial nonces found');
      }
      
      // Create export object with only the necessary data
      const exportData = {
        exportDate: new Date().toISOString(),
        version: '1.0',
        partialNonces: patternsWithNonces.map(pattern => ({
          patternId: pattern.id,
          partialNonce: pattern.partialNonce,
          transactions: pattern.transactions,
          reconstructionProgress: pattern.reconstructionProgress
        }))
      };
      
      return JSON.stringify(exportData, null, 2);
    } catch (error) {
      console.error('Error exporting partial nonces:', error);
      throw error;
    }
  },
  
  /**
   * Import reconstructed nonces from external processing
   * @param jsonData JSON string with reconstructed nonce data
   * @returns Import summary
   */
  async importReconstructedNonces(jsonData: string): Promise<{
    patternsUpdated: number;
    noncesImported: number;
  }> {
    try {
      // Parse import data
      const importData = JSON.parse(jsonData);
      
      if (!importData.reconstructedNonces) {
        throw new Error('Invalid import format: missing reconstructed nonce data');
      }
      
      let patternsUpdated = 0;
      let noncesImported = 0;
      
      // Update patterns with the reconstructed nonces
      for (const item of importData.reconstructedNonces) {
        try {
          const pattern = await storage.getPatternById(item.patternId);
          
          if (pattern) {
            await storage.updatePattern(pattern.id, {
              nonceReconstructed: true,
              nonceValue: item.nonceValue,
              reconstructionProgress: 100
            });
            
            patternsUpdated++;
            noncesImported++;
          }
        } catch (patternError) {
          console.error(`Error updating pattern ${item.patternId}:`, patternError);
        }
      }
      
      return {
        patternsUpdated,
        noncesImported
      };
    } catch (error) {
      console.error('Error importing reconstructed nonces:', error);
      throw error;
    }
  }
};