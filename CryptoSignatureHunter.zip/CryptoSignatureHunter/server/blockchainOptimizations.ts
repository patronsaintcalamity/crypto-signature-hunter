/**
 * Blockchain Optimizations Module
 * 
 * Optimizes blockchain data processing:
 * - Transaction batching
 * - Caching of common operations
 * - Data preprocessing for analysis
 */

import { Transaction } from './fileParser';
import { getAddressInfo, getKeySearchOptimizations } from './addressPatterns';

/**
 * Optimizations found in blockchain data
 */
export interface BlockchainOptimizations {
  addressGroups: Map<string, string[]>;
  transactionIndexes: Map<string, number[]>;
  timeRanges: Map<string, { start: number; end: number }>;
  potentialPatterns: Map<string, string[]>;
  keyRangeHints: Map<string, { start: string; end: string }[]>;
  keyPrefixHints: Map<string, string[]>;
}

/**
 * Blockchain optimization utility
 */
export class BlockchainOptimizer {
  /**
   * Find optimizations in transaction data
   * @param transactions Transactions to analyze
   * @returns Optimization data
   */
  static findOptimizations(transactions: Transaction[]): BlockchainOptimizations {
    const addressGroups = new Map<string, string[]>();
    const transactionIndexes = new Map<string, number[]>();
    const timeRanges = new Map<string, { start: number; end: number }>();
    const potentialPatterns = new Map<string, string[]>();
    const keyRangeHints = new Map<string, { start: string; end: string }[]>();
    const keyPrefixHints = new Map<string, string[]>();
    
    // Group transactions by address
    for (let i = 0; i < transactions.length; i++) {
      const tx = transactions[i];
      
      // Add to address groups
      if (!addressGroups.has(tx.address)) {
        addressGroups.set(tx.address, []);
      }
      addressGroups.get(tx.address)!.push(tx.id);
      
      // Add to transaction indexes
      if (!transactionIndexes.has(tx.address)) {
        transactionIndexes.set(tx.address, []);
      }
      transactionIndexes.get(tx.address)!.push(i);
      
      // Get address info and add optimization hints
      const addressInfo = getAddressInfo(tx.address);
      if (addressInfo) {
        // Add key search optimizations
        const searchOpts = getKeySearchOptimizations(tx.address);
        
        if (searchOpts.keyRanges && searchOpts.keyRanges.length > 0) {
          keyRangeHints.set(tx.address, searchOpts.keyRanges);
        }
        
        if (searchOpts.keyPrefixes && searchOpts.keyPrefixes.length > 0) {
          keyPrefixHints.set(tx.address, searchOpts.keyPrefixes);
        }
      }
      
      // Find time ranges
      if (tx.timestamp) {
        if (!timeRanges.has(tx.address)) {
          timeRanges.set(tx.address, { start: tx.timestamp, end: tx.timestamp });
        } else {
          const range = timeRanges.get(tx.address)!;
          range.start = Math.min(range.start, tx.timestamp);
          range.end = Math.max(range.end, tx.timestamp);
        }
      }
    }
    
    // Find potential patterns
    for (const [address, txIds] of addressGroups.entries()) {
      const patterns: string[] = [];
      
      if (txIds.length > 1) {
        // Multiple transactions from same address might indicate patterns
        patterns.push('multiple_tx');
      }
      
      // Look for R value patterns
      const addressTxs = txIds.map(id => transactions.find(tx => tx.id === id)!);
      const rValues = addressTxs.map(tx => tx.r);
      
      // Check for duplicate R values
      if (new Set(rValues).size < rValues.length) {
        patterns.push('duplicate_r');
      }
      
      // Check for sequential R values (simplified)
      for (let i = 1; i < rValues.length; i++) {
        // For demonstration - actually checking sequential would be more complex
        if (rValues[i].startsWith(rValues[i-1].substring(0, 10))) {
          patterns.push('sequential_r');
          break;
        }
      }
      
      // Add patterns if found
      if (patterns.length > 0) {
        potentialPatterns.set(address, patterns);
      }
    }
    
    return {
      addressGroups,
      transactionIndexes,
      timeRanges,
      potentialPatterns,
      keyRangeHints,
      keyPrefixHints
    };
  }
  
  /**
   * Apply optimizations to transaction data
   * @param transactions Original transactions
   * @param optimizations Optimization data
   * @returns Optimized transactions
   */
  static applyOptimizations(
    transactions: Transaction[],
    optimizations: BlockchainOptimizations
  ): Transaction[] {
    const optimizedTxs = [...transactions];
    
    // Apply key range hints to transactions
    for (let i = 0; i < optimizedTxs.length; i++) {
      const tx = optimizedTxs[i];
      
      // Add key range hints
      if (optimizations.keyRangeHints.has(tx.address)) {
        if (!tx.searchHints) {
          tx.searchHints = {};
        }
        tx.searchHints.keyRanges = optimizations.keyRangeHints.get(tx.address);
      }
      
      // Add key prefix hints
      if (optimizations.keyPrefixHints.has(tx.address)) {
        if (!tx.searchHints) {
          tx.searchHints = {};
        }
        tx.searchHints.keyPrefixes = optimizations.keyPrefixHints.get(tx.address);
      }
      
      // Add time period hints
      if (optimizations.timeRanges.has(tx.address)) {
        if (!tx.searchHints) {
          tx.searchHints = {};
        }
        tx.searchHints.timePeriod = optimizations.timeRanges.get(tx.address);
      }
    }
    
    return optimizedTxs;
  }
}