// This file contains type definitions for tests only

export interface Transaction {
  id: string;
  txid: string | null;
  address: string;
  r: string | null;
  s: string | null;
  z: string | null;
  pubkey: string | null;
  blockHeight: number | null;
  index: number | null;
  timestamp: string | null;
  sequenceNumber: number | null;
  inputValue: number | null;
  outputValue: number | null;
  patternId: string | null;
  patternName: string | null;
  confidence: number;
  status: string | null;
  createdAt: string | null;
}

export interface Pattern {
  id: string;
  name: string;
  confidence?: number;
  transactionCount: number;
  characteristics?: string;
  affectedAddresses: string[];
  transactions?: string[];
  nonceReconstructed: boolean;
  nonceValue: string | null;
  partialNonce: string | null;
  bruteForcedNonces?: string[] | null;
  reconstructionProgress?: number;
  bruteForcingProgress?: number;
  discoveredAt: string;
}

export interface Key {
  id: string;
  privateKey: string;
  address: string;
  patternId: string;
  verification: string;
  wif: string | null;
  format: string | null;
  publicKey: string | null;
  confidence: number | null;
  verified: boolean | null;
  transactions: string[] | null;
  discoveredAt: string;
}

export interface AnalysisStep {
  id: string;
  status: 'completed' | 'in-progress' | 'waiting';
  name: string;
  details: string;
}

export interface AnalysisStatus {
  id: string;
  progress: number;
  status: string;
  completed: boolean;
  error?: boolean;
  keysFound?: number;
  steps: AnalysisStep[];
}