/**
 * Parallel Processing Module
 * 
 * Manages parallel computation tasks using worker threads:
 * - Worker pool management
 * - Task queuing and distribution
 * - Result collection and aggregation
 */

import { Worker } from 'worker_threads';
import { v4 as uuidv4 } from 'uuid';
import { cpus } from 'os';
import path from 'path';

/**
 * Task priority levels
 */
export enum TaskPriority {
  LOW = 0,
  NORMAL = 1,
  HIGH = 2
}

/**
 * Task status values
 */
export enum TaskStatus {
  PENDING = 'pending',
  RUNNING = 'running',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled'
}

/**
 * Computation status
 */
export enum ComputationStatus {
  WAITING = 'waiting',
  COMPUTING = 'computing',
  FINISHED = 'finished',
  ERROR = 'error'
}

/**
 * Task interface
 */
export interface Task {
  id: string;
  type: string;
  params: any;
  priority: TaskPriority;
  status: TaskStatus;
  workerId?: number;
  result?: any;
  error?: string;
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
}

/**
 * Worker interface
 */
interface WorkerInfo {
  id: number;
  worker: Worker;
  busy: boolean;
  currentTaskId?: string;
  tasksCompleted: number;
}

/**
 * Task factory for creating different types of computation tasks
 */
export class TaskFactory {
  /**
   * Create a key search task
   */
  static createKeySearchTask(
    rangeStart: string,
    rangeEnd: string, 
    targetAddresses: string[],
    options?: {
      priority?: TaskPriority,
      prefixes?: string[],
      suffixes?: string[]
    }
  ): Task {
    return {
      id: uuidv4(),
      type: 'keySearch',
      params: {
        rangeStart,
        rangeEnd,
        targetAddresses,
        prefixes: options?.prefixes || [],
        suffixes: options?.suffixes || []
      },
      priority: options?.priority || TaskPriority.NORMAL,
      status: TaskStatus.PENDING,
      createdAt: Date.now()
    };
  }
  
  /**
   * Create a nonce recovery task
   */
  static createNonceRecoveryTask(
    transactions: any[],
    options?: {
      priority?: TaskPriority,
      method?: string,
      partialBits?: number[]
    }
  ): Task {
    return {
      id: uuidv4(),
      type: 'nonceRecovery',
      params: {
        transactions,
        method: options?.method || 'biased',
        partialBits: options?.partialBits || []
      },
      priority: options?.priority || TaskPriority.NORMAL,
      status: TaskStatus.PENDING,
      createdAt: Date.now()
    };
  }
  
  /**
   * Create a pattern detection task
   */
  static createPatternDetectionTask(
    transactions: any[],
    options?: {
      priority?: TaskPriority,
      patterns?: string[]
    }
  ): Task {
    return {
      id: uuidv4(),
      type: 'patternDetection',
      params: {
        transactions,
        patterns: options?.patterns || ['reuse', 'biased', 'sequential']
      },
      priority: options?.priority || TaskPriority.NORMAL,
      status: TaskStatus.PENDING,
      createdAt: Date.now()
    };
  }
}

/**
 * Manages parallel processing using worker threads
 */
class ParallelProcessingManager {
  private workers: WorkerInfo[] = [];
  private taskQueue: Task[] = [];
  private completedTasks: Map<string, Task> = new Map();
  private maxWorkers: number;
  private initialized: boolean = false;
  private taskCallbacks: Map<string, (task: Task) => void> = new Map();
  
  constructor() {
    this.maxWorkers = Math.max(2, cpus().length - 1);
  }
  
  /**
   * Initialize the worker pool
   * @param numWorkers Number of worker threads to create
   */
  initializeWorkerPool(numWorkers: number = this.maxWorkers): void {
    if (this.initialized) {
      console.warn('Worker pool already initialized');
      return;
    }
    
    const actualWorkers = Math.min(numWorkers, this.maxWorkers);
    console.log(`Initializing worker pool with ${actualWorkers} workers`);
    
    for (let i = 0; i < actualWorkers; i++) {
      try {
        const worker = new Worker(path.join(process.cwd(), 'server', 'computeWorker.js'));
        
        worker.on('message', (message: any) => {
          this.handleWorkerMessage(i, message);
        });
        
        worker.on('error', (err: Error) => {
          console.error(`Worker ${i} error:`, err);
          this.handleWorkerError(i, err);
        });
        
        this.workers.push({
          id: i,
          worker,
          busy: false,
          tasksCompleted: 0
        });
        
        console.log(`Worker ${i} initialized`);
      } catch (err) {
        console.error(`Failed to initialize worker ${i}:`, err);
      }
    }
    
    this.initialized = true;
    this.processQueue();
  }
  
  /**
   * Submit a task for processing
   * @param task Task to process
   * @param callback Optional callback for task completion
   * @returns Task ID
   */
  submitTask(task: Task, callback?: (task: Task) => void): string {
    if (!this.initialized) {
      throw new Error('Worker pool not initialized. Call initializeWorkerPool() first.');
    }
    
    this.taskQueue.push(task);
    
    if (callback) {
      this.taskCallbacks.set(task.id, callback);
    }
    
    // Sort queue by priority
    this.taskQueue.sort((a, b) => b.priority - a.priority);
    
    // Process queue if workers available
    this.processQueue();
    
    return task.id;
  }
  
  /**
   * Get all queued tasks
   * @returns Array of queued tasks
   */
  getQueuedTasks(): Task[] {
    return [...this.taskQueue];
  }
  
  /**
   * Get all completed tasks
   * @returns Array of completed tasks
   */
  getCompletedTasks(): Task[] {
    return Array.from(this.completedTasks.values());
  }
  
  /**
   * Get the status of a specific task
   * @param taskId Task ID
   * @returns Task object or null if not found
   */
  getTaskStatus(taskId: string): Task | null {
    // Check active tasks
    for (const worker of this.workers) {
      if (worker.currentTaskId === taskId) {
        const activeTask = this.workers.find(w => w.currentTaskId === taskId);
        if (activeTask) {
          return {
            id: taskId,
            type: 'unknown',
            params: {},
            priority: TaskPriority.NORMAL,
            status: TaskStatus.RUNNING,
            workerId: worker.id,
            createdAt: Date.now()
          };
        }
      }
    }
    
    // Check queued tasks
    const queuedTask = this.taskQueue.find(t => t.id === taskId);
    if (queuedTask) {
      return queuedTask;
    }
    
    // Check completed tasks
    const completedTask = this.completedTasks.get(taskId);
    if (completedTask) {
      return completedTask;
    }
    
    return null;
  }
  
  /**
   * Cancel a specific task
   * @param taskId Task ID
   * @returns True if task was cancelled
   */
  cancelTask(taskId: string): boolean {
    // Check if task is in queue
    const queueIndex = this.taskQueue.findIndex(t => t.id === taskId);
    if (queueIndex >= 0) {
      const task = this.taskQueue[queueIndex];
      task.status = TaskStatus.CANCELLED;
      this.taskQueue.splice(queueIndex, 1);
      this.completedTasks.set(taskId, task);
      
      if (this.taskCallbacks.has(taskId)) {
        this.taskCallbacks.get(taskId)!(task);
        this.taskCallbacks.delete(taskId);
      }
      
      return true;
    }
    
    // Check if task is running
    const worker = this.workers.find(w => w.currentTaskId === taskId);
    if (worker) {
      worker.worker.postMessage({
        type: 'cancel',
        taskId
      });
      
      return true;
    }
    
    return false;
  }
  
  /**
   * Clear all completed tasks
   */
  clearCompletedTasks(): void {
    this.completedTasks.clear();
  }
  
  /**
   * Shut down the worker pool
   */
  shutdown(): void {
    if (!this.initialized) return;
    
    for (const worker of this.workers) {
      worker.worker.terminate();
    }
    
    this.workers = [];
    this.initialized = false;
  }
  
  /**
   * Process the task queue
   */
  private processQueue(): void {
    if (this.taskQueue.length === 0) return;
    
    for (const worker of this.workers) {
      if (!worker.busy && this.taskQueue.length > 0) {
        const task = this.taskQueue.shift()!;
        
        task.status = TaskStatus.RUNNING;
        task.startedAt = Date.now();
        task.workerId = worker.id;
        
        worker.busy = true;
        worker.currentTaskId = task.id;
        
        worker.worker.postMessage({
          type: 'task',
          task
        });
      }
    }
  }
  
  /**
   * Handle a message from a worker
   * @param workerId Worker ID
   * @param message Message from worker
   */
  private handleWorkerMessage(workerId: number, message: any): void {
    const worker = this.workers.find(w => w.id === workerId);
    if (!worker) return;
    
    if (message.type === 'result') {
      const task = message.task;
      
      worker.busy = false;
      worker.currentTaskId = undefined;
      worker.tasksCompleted++;
      
      task.completedAt = Date.now();
      this.completedTasks.set(task.id, task);
      
      if (this.taskCallbacks.has(task.id)) {
        this.taskCallbacks.get(task.id)!(task);
        this.taskCallbacks.delete(task.id);
      }
      
      this.processQueue();
    }
  }
  
  /**
   * Handle a worker error
   * @param workerId Worker ID
   * @param error Error object
   */
  private handleWorkerError(workerId: number, error: Error): void {
    const worker = this.workers.find(w => w.id === workerId);
    if (!worker) return;
    
    const taskId = worker.currentTaskId;
    if (taskId) {
      const task = this.getTaskStatus(taskId);
      if (task) {
        task.status = TaskStatus.FAILED;
        task.error = error.message;
        task.completedAt = Date.now();
        
        this.completedTasks.set(taskId, task);
        
        if (this.taskCallbacks.has(taskId)) {
          this.taskCallbacks.get(taskId)!(task);
          this.taskCallbacks.delete(taskId);
        }
      }
    }
    
    // Reset worker state
    worker.busy = false;
    worker.currentTaskId = undefined;
    
    // Process next task
    this.processQueue();
  }
}

// Export singleton instance
export const parallelProcessingManager = new ParallelProcessingManager();
export const workerPool = parallelProcessingManager;