import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { blockchainAPI } from "./blockchainAPI";
import { cryptoAnalyzer } from "./cryptoAnalyzer";
import { parseAttachedAssets } from "./fileParser";
import { wizardService } from "./wizardService";
import { randomUUID } from "crypto";
import path from "path";
import os from "os";
import fs from "fs";
import { isOpenAIAvailable } from "./utils";

// Interface for file uploads
interface MulterRequest extends Request {
  files?: Express.Multer.File[];
}

// Configure multer for file uploads
const upload = multer({
  dest: os.tmpdir(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
    files: 5 // Max 5 files
  },
  fileFilter: (_req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    // Accept various file types for signatures
    const ext = path.extname(file.originalname).toLowerCase();
    console.log(`File upload attempted: ${file.originalname} with MIME type: ${file.mimetype}`);
    
    // Accept files with correct extensions or mime types
    if (ext === '.csv' || ext === '.json' || ext === '.txt' || 
        file.mimetype === 'text/csv' || 
        file.mimetype === 'application/json' ||
        file.mimetype === 'text/plain' ||
        file.mimetype === 'application/octet-stream') {
      console.log(`Accepting file: ${file.originalname}`);
      cb(null, true);
    } else {
      console.log(`Rejecting file: ${file.originalname} with extension ${ext}`);
      cb(null, false); // Don't throw error, just reject the file
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefixed with /api
  
  // Parse attached assets
  app.get("/api/assets/parse", async (_req, res) => {
    try {
      const transactions = await parseAttachedAssets();
      
      // Save transactions to storage
      if (transactions.length > 0) {
        await storage.saveTransactions(transactions);
      }
      
      return res.json({ 
        success: true, 
        count: transactions.length,
        transactions,
        message: `Successfully parsed ${transactions.length} transactions from attached assets`
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to parse attached assets" 
      });
    }
  });
  
  // Fetch transactions for an address
  app.get("/api/transactions/fetch", async (req, res) => {
    try {
      const { address } = req.query;
      
      if (!address || typeof address !== "string") {
        return res.status(400).json({ message: "Address is required" });
      }
      
      const transactions = await blockchainAPI.fetchTransactions(address);
      
      // Save transactions to storage
      await storage.saveTransactions(transactions);
      
      return res.json({ 
        success: true, 
        count: transactions.length,
        message: `Successfully fetched ${transactions.length} transactions`
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch transactions" 
      });
    }
  });
  
  // Get transactions with pagination and filtering
  app.get("/api/transactions", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const filter = req.query.filter as string || 'all';
      const search = req.query.search as string || '';
      const pageSize = 10;
      
      // Get all transactions
      const allTransactions = await storage.getTransactions();
      
      // Apply filtering
      let filteredTransactions = allTransactions;
      if (filter !== 'all') {
        filteredTransactions = allTransactions.filter(tx => tx.status === filter);
      }
      
      // Apply search if provided
      if (search) {
        filteredTransactions = filteredTransactions.filter(tx => 
          tx.txid.includes(search) || 
          tx.address.includes(search) ||
          (tx.patternId && tx.patternId.includes(search))
        );
      }
      
      // Apply pagination
      const total = filteredTransactions.length;
      const start = (page - 1) * pageSize;
      const end = start + pageSize;
      const paginatedTransactions = filteredTransactions.slice(start, end);
      
      return res.json({ 
        transactions: paginatedTransactions, 
        total 
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get transactions" 
      });
    }
  });
  
  // Start a new analysis
  app.post("/api/analysis/start", upload.array('files'), async (req: Request, res) => {
    const multerReq = req as MulterRequest;
    try {
      console.log("Analysis start request received with body:", req.body);
      console.log("Files received:", multerReq.files);
      
      const files = multerReq.files || [];
      const address = req.body.address as string;
      const speedLevel = parseInt(req.body.speedLevel as string) || 3;
      const usePartialNonce = req.body.usePartialNonce === 'true';
      const usePatternRecognition = req.body.usePatternRecognition === 'true';
      const useAI = req.body.useAI === 'true';
      const patternDepth = parseInt(req.body.patternDepth as string) || 4;
      
      if (!address && (!files || files.length === 0)) {
        return res.status(400).json({ message: "Either address or files are required" });
      }
      
      // Generate a unique ID for this analysis
      const analysisId = randomUUID();
      
      // Process files if available
      const processedFiles = Array.isArray(files) ? files.map((file: Express.Multer.File) => ({
        path: file.path,
        name: file.originalname
      })) : [];
      
      // Start the analysis process
      cryptoAnalyzer.startAnalysis({
        analysisId,
        address,
        files: processedFiles,
        options: {
          speedLevel,
          usePartialNonce,
          usePatternRecognition,
          useAI,
          patternDepth
        }
      });
      
      return res.json({
        success: true,
        analysisId,
        message: "Analysis started successfully"
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to start analysis" 
      });
    }
  });
  
  // Get analysis status
  app.get("/api/analysis/status", async (req, res) => {
    try {
      const { analysisId } = req.query;
      
      if (!analysisId || typeof analysisId !== "string") {
        return res.status(400).json({ message: "Analysis ID is required" });
      }
      
      const status = await cryptoAnalyzer.getAnalysisStatus(analysisId);
      
      return res.json(status);
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get analysis status" 
      });
    }
  });
  
  // Get discovered patterns
  app.get("/api/patterns", async (_req, res) => {
    try {
      const patterns = await storage.getPatterns();
      
      return res.json({ patterns });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get patterns" 
      });
    }
  });
  
  // Exploit a specific pattern
  app.post("/api/patterns/exploit", async (req, res) => {
    try {
      const { patternId } = req.body;
      
      if (!patternId) {
        return res.status(400).json({ message: "Pattern ID is required" });
      }
      
      const result = await cryptoAnalyzer.exploitPattern(patternId);
      
      return res.json(result);
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to exploit pattern" 
      });
    }
  });
  
  // Get discovered keys
  app.get("/api/keys", async (_req, res) => {
    try {
      const keys = await storage.getKeys();
      
      return res.json({ keys });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get keys" 
      });
    }
  });
  
  // Get nonce data for a pattern
  app.get("/api/patterns/:patternId/nonce", async (req, res) => {
    try {
      const { patternId } = req.params;
      
      if (!patternId) {
        return res.status(400).json({ message: "Pattern ID is required" });
      }
      
      const pattern = await storage.getPatternById(patternId);
      
      if (!pattern) {
        return res.status(404).json({ message: "Pattern not found" });
      }
      
      // Extract just the nonce-related data
      const nonceData = {
        patternId: pattern.id,
        patternName: pattern.name,
        confidence: pattern.confidence,
        nonceReconstructed: pattern.nonceReconstructed,
        nonceValue: pattern.nonceValue,
        partialNonce: pattern.partialNonce,
        bruteForcedNonces: pattern.bruteForcedNonces,
        reconstructionProgress: pattern.reconstructionProgress,
        bruteForcingProgress: pattern.bruteForcingProgress,
        exportedAt: new Date().toISOString()
      };
      
      return res.json(nonceData);
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get nonce data" 
      });
    }
  });
  
  // Get all achievements
  app.get("/api/achievements", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string) || undefined;
      const type = req.query.type as string || undefined;
      
      let achievements;
      if (userId) {
        achievements = await storage.getAchievementsByUser(userId);
      } else if (type) {
        achievements = await storage.getAchievementsByType(type);
      } else {
        achievements = await storage.getAchievements();
      }
      
      return res.json({ achievements });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get achievements" 
      });
    }
  });
  
  // Create a new achievement
  app.post("/api/achievements", async (req, res) => {
    try {
      const { type, userId, label, description, level, metadata } = req.body;
      
      if (!type || !label || !description || !level) {
        return res.status(400).json({ message: "Missing required fields for achievement" });
      }
      
      const achievement = await storage.saveAchievement({
        type,
        userId: userId || 1, // Default to user 1 if not specified
        label,
        description,
        level,
        metadata: metadata ? JSON.stringify(metadata) : null,
      });
      
      return res.json({ 
        success: true, 
        achievement,
        message: "Achievement created successfully" 
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to create achievement" 
      });
    }
  });
  
  // Get timeline entries
  app.get("/api/timeline", async (_req, res) => {
    try {
      const entries = await storage.getTimelineEntries();
      
      return res.json({ entries });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get timeline entries" 
      });
    }
  });
  
  // Create a timeline entry
  app.post("/api/timeline", async (req, res) => {
    try {
      const { type, title, description, metadata } = req.body;
      
      if (!type || !title || !description) {
        return res.status(400).json({ message: "Missing required fields for timeline entry" });
      }
      
      const entry = {
        id: randomUUID(),
        timestamp: new Date().toISOString(),
        type,
        title,
        description,
        metadata
      };
      
      await storage.saveTimelineEntry(entry);
      
      return res.json({ 
        success: true, 
        entry,
        message: "Timeline entry created successfully" 
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to create timeline entry" 
      });
    }
  });

  // Apply adaptive learning to patterns
  app.post("/api/adaptive-learning/train", async (req: Request, res) => {
    try {
      const { patterns, settings } = req.body;
      
      if (!Array.isArray(patterns)) {
        return res.status(400).json({ message: "Patterns array is required" });
      }
      
      // Apply adaptive learning process
      const results = await cryptoAnalyzer.applyAdaptiveLearning(patterns, settings);
      
      return res.json({ 
        success: true, 
        results,
        message: "Adaptive learning applied successfully" 
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to apply adaptive learning" 
      });
    }
  });

  // Get signature correlation clusters across addresses
  app.get("/api/clusters", async (_req, res) => {
    try {
      // Get all transactions from storage
      const transactions = await storage.getTransactions();
      
      // Skip empty datasets
      if (transactions.length === 0) {
        return res.json({ clusters: [] });
      }
      
      // Perform cluster analysis
      const clusters = await cryptoAnalyzer.performAddressClusterAnalysis(transactions);
      
      return res.json({ 
        clusters,
        count: clusters.length
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to perform cluster analysis" 
      });
    }
  });
  
  // PATTERN DISCOVERY WIZARD ROUTES
  
  // Initialize a new wizard session
  app.post("/api/wizard/initialize", upload.array('files'), async (req: Request, res) => {
    const multerReq = req as MulterRequest;
    try {
      console.log("Wizard initialization request received");
      
      const files = multerReq.files || [];
      
      // Process files if available
      const processedFiles = Array.isArray(files) ? files.map((file: Express.Multer.File) => ({
        path: file.path,
        name: file.originalname
      })) : [];
      
      // Get transactions from files
      let transactions = [];
      
      if (processedFiles.length > 0) {
        // Process uploaded files
        console.log(`Processing ${processedFiles.length} uploaded files`);
        // Implementation would depend on your file processor
        // This is just a placeholder for now
      } else {
        // Use transactions from storage if no files were uploaded
        console.log("No files uploaded, using transactions from storage");
        transactions = await storage.getTransactions();
      }
      
      if (transactions.length === 0) {
        // Try to parse attached assets if no transactions are available
        console.log("No transactions available, trying to parse attached assets");
        transactions = await parseAttachedAssets();
      }
      
      if (transactions.length === 0) {
        return res.status(400).json({ 
          success: false,
          message: "No transactions available. Please upload files or use the 'Parse Assets' feature first."
        });
      }
      
      // Initialize the wizard session
      const wizardState = await wizardService.initializeWizard(transactions);
      
      // Save the wizard state
      await storage.saveWizardState(wizardState);
      
      return res.json({
        success: true,
        sessionId: wizardState.sessionId,
        currentStep: wizardState.currentStep,
        progress: wizardState.progress,
        message: "Wizard session initialized successfully"
      });
    } catch (error) {
      console.error("Wizard initialization error:", error);
      return res.status(500).json({ 
        success: false,
        message: error instanceof Error ? error.message : "Failed to initialize wizard session" 
      });
    }
  });
  
  // Get wizard state
  app.get("/api/wizard/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      if (!sessionId) {
        return res.status(400).json({ 
          success: false,
          message: "Session ID is required" 
        });
      }
      
      const wizardState = await storage.getWizardState(sessionId);
      
      if (!wizardState) {
        return res.status(404).json({ 
          success: false,
          message: "Wizard session not found" 
        });
      }
      
      return res.json({
        success: true,
        wizardState
      });
    } catch (error) {
      console.error("Get wizard state error:", error);
      return res.status(500).json({ 
        success: false,
        message: error instanceof Error ? error.message : "Failed to get wizard state" 
      });
    }
  });
  
  // Process next step in the wizard
  app.post("/api/wizard/:sessionId/next", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { selectedPatterns } = req.body;
      
      if (!sessionId) {
        return res.status(400).json({ 
          success: false,
          message: "Session ID is required" 
        });
      }
      
      // Get current wizard state
      let wizardState = await storage.getWizardState(sessionId);
      
      if (!wizardState) {
        return res.status(404).json({ 
          success: false,
          message: "Wizard session not found" 
        });
      }
      
      // Update selected patterns if provided (for pattern_selection step)
      if (selectedPatterns && Array.isArray(selectedPatterns) && wizardState.currentStep === 'pattern_selection') {
        wizardState.selectedPatterns = selectedPatterns;
        await storage.updateWizardState(sessionId, { selectedPatterns });
      }
      
      // Process the next step
      const updatedState = await wizardService.processNextStep(wizardState);
      
      // Update the wizard state in storage
      await storage.updateWizardState(sessionId, updatedState);
      
      return res.json({
        success: true,
        wizardState: updatedState,
        message: `Successfully processed step: ${wizardState.currentStep}`
      });
    } catch (error) {
      console.error("Process next wizard step error:", error);
      return res.status(500).json({ 
        success: false,
        message: error instanceof Error ? error.message : "Failed to process next wizard step" 
      });
    }
  });
  
  // Get a specific pattern explanation
  app.get("/api/wizard/:sessionId/explanations/:patternId", async (req, res) => {
    try {
      const { sessionId, patternId } = req.params;
      
      if (!sessionId || !patternId) {
        return res.status(400).json({ 
          success: false,
          message: "Session ID and Pattern ID are required" 
        });
      }
      
      const wizardState = await storage.getWizardState(sessionId);
      
      if (!wizardState) {
        return res.status(404).json({ 
          success: false,
          message: "Wizard session not found" 
        });
      }
      
      const explanation = wizardState.explanations && wizardState.explanations[patternId];
      
      if (!explanation) {
        return res.status(404).json({ 
          success: false,
          message: "Explanation not found for the specified pattern" 
        });
      }
      
      return res.json({
        success: true,
        explanation
      });
    } catch (error) {
      console.error("Get pattern explanation error:", error);
      return res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "Failed to get pattern explanation" 
      });
    }
  });
  
  // Get exploitation strategies for a specific pattern
  app.get("/api/wizard/:sessionId/strategies/:patternId", async (req, res) => {
    try {
      const { sessionId, patternId } = req.params;
      
      if (!sessionId || !patternId) {
        return res.status(400).json({ 
          success: false,
          message: "Session ID and Pattern ID are required" 
        });
      }
      
      const wizardState = await storage.getWizardState(sessionId);
      
      if (!wizardState) {
        return res.status(404).json({ 
          success: false,
          message: "Wizard session not found" 
        });
      }
      
      const strategy = wizardState.exploitationStrategies && wizardState.exploitationStrategies[patternId];
      
      if (!strategy) {
        return res.status(404).json({ 
          success: false,
          message: "Exploitation strategy not found for the specified pattern" 
        });
      }
      
      return res.json({
        success: true,
        strategy,
        successProbability: wizardState.successProbabilities?.[patternId] || 0,
        estimatedTime: wizardState.estimatedTimeToKeys?.[patternId] || 'unknown'
      });
    } catch (error) {
      console.error("Get exploitation strategy error:", error);
      return res.status(500).json({ 
        success: false,
        message: error instanceof Error ? error.message : "Failed to get exploitation strategy" 
      });
    }
  });
  
  // Export wizard results as PDF (placeholder for now)
  app.get("/api/wizard/:sessionId/export", async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      if (!sessionId) {
        return res.status(400).json({ 
          success: false,
          message: "Session ID is required" 
        });
      }
      
      const wizardState = await storage.getWizardState(sessionId);
      
      if (!wizardState) {
        return res.status(404).json({ 
          success: false,
          message: "Wizard session not found" 
        });
      }
      
      // For now, just return a JSON version of the results
      // PDF generation would be implemented here
      
      return res.json({
        success: true,
        exportData: {
          sessionId: wizardState.sessionId,
          createdAt: wizardState.createdAt,
          completed: wizardState.completed,
          overallRisk: wizardState.overallRisk,
          riskSummary: wizardState.riskSummary,
          patterns: wizardState.detectedPatterns.map(pattern => ({
            id: pattern.id,
            name: pattern.name,
            confidence: pattern.confidence,
            type: pattern.type,
            description: pattern.description
          })),
          vulnerabilities: wizardState.potentialVulnerabilities.map(vuln => ({
            type: vuln.type,
            confidence: vuln.confidence,
            severity: vuln.severity,
            description: vuln.description
          }))
        },
        message: "Export data generated successfully"
      });
    } catch (error) {
      console.error("Export wizard results error:", error);
      return res.status(500).json({ 
        success: false,
        message: error instanceof Error ? error.message : "Failed to export wizard results" 
      });
    }
  });
  
  // Get advanced visualization data for signatures
  app.get("/api/visualization/signature-graph", async (_req, res) => {
    try {
      // Get all transactions and patterns from storage
      const transactions = await storage.getTransactions();
      const patterns = await storage.getPatterns();
      
      // Skip empty datasets
      if (transactions.length === 0) {
        return res.json({ 
          nodes: [], 
          links: [],
          groups: []
        });
      }
      
      // Prepare nodes (transactions, addresses, patterns)
      const nodes: Array<{
        id: string;
        group: string;
        type: string;
        label: string;
        r?: string;
        s?: string;
        z?: string;
        patternId?: string;
        confidence?: number;
        transactions?: string[];
        size?: number;
      }> = [];
      
      // Prepare links between nodes
      const links: Array<{
        source: string;
        target: string;
        value: number;
        type: string;
      }> = [];
      
      // Add transaction nodes
      transactions.forEach(tx => {
        nodes.push({
          id: tx.id,
          group: 'transaction',
          type: 'transaction',
          label: `TX: ${tx.txid.substring(0, 8)}...`,
          r: tx.r,
          s: tx.s,
          z: tx.z,
          patternId: tx.patternId || undefined,
          confidence: tx.confidence,
          size: 1
        });
        
        // Add links to addresses
        links.push({
          source: tx.id,
          target: tx.address,
          value: 1,
          type: 'address'
        });
      });
      
      // Add address nodes (unique)
      const uniqueAddresses = [...new Set(transactions.map(tx => tx.address))];
      uniqueAddresses.forEach(address => {
        // Find transactions for this address
        const addressTxs = transactions.filter(tx => tx.address === address);
        
        nodes.push({
          id: address,
          group: 'address',
          type: 'address',
          label: `${address.substring(0, 6)}...${address.substring(address.length - 4)}`,
          transactions: addressTxs.map(tx => tx.id),
          size: 2
        });
      });
      
      // Add pattern nodes
      patterns.forEach(pattern => {
        nodes.push({
          id: `pattern-${pattern.id}`,
          group: 'pattern',
          type: 'pattern',
          label: pattern.name,
          confidence: pattern.confidence,
          transactions: pattern.transactions,
          size: 3
        });
        
        // Link patterns to transactions
        if (pattern.transactions) {
          pattern.transactions.forEach(txId => {
            links.push({
              source: `pattern-${pattern.id}`,
              target: txId,
              value: 2,
              type: 'pattern'
            });
          });
        }
        
        // Add nonce nodes if available
        if (pattern.nonceReconstructed && pattern.nonceValue) {
          const nonceId = `nonce-${pattern.id}`;
          nodes.push({
            id: nonceId,
            group: 'nonce',
            type: 'nonce',
            label: `Nonce: ${pattern.nonceValue.substring(0, 8)}...`,
            size: 4
          });
          
          links.push({
            source: nonceId,
            target: `pattern-${pattern.id}`,
            value: 3,
            type: 'derived'
          });
        }
      });
      
      // Add r-value similarity links
      const rValueMap = new Map<string, string[]>();
      
      // Group transactions by r-value
      transactions.forEach(tx => {
        if (tx.r) {
          const rPrefix = tx.r.substring(0, 6); // Use first 6 chars as a similarity group
          if (!rValueMap.has(rPrefix)) {
            rValueMap.set(rPrefix, []);
          }
          rValueMap.get(rPrefix)?.push(tx.id);
        }
      });
      
      // Create links between transactions with similar r values
      rValueMap.forEach((txIds, rPrefix) => {
        if (txIds.length > 1) {
          // Only create links if there are at least 2 transactions with similar r values
          for (let i = 0; i < txIds.length; i++) {
            for (let j = i + 1; j < txIds.length; j++) {
              links.push({
                source: txIds[i],
                target: txIds[j],
                value: 1,
                type: 'similarity'
              });
            }
          }
        }
      });
      
      // Group definition for legends
      const groups = [
        { id: 'transaction', name: 'Transaction', color: '#9C27B0' },
        { id: 'address', name: 'Address', color: '#1976D2' },
        { id: 'pattern', name: 'Pattern', color: '#FF9800' },
        { id: 'nonce', name: 'Nonce', color: '#4CAF50' }
      ];
      
      return res.json({ 
        nodes,
        links,
        groups
      });
    } catch (error) {
      return res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate visualization data" 
      });
    }
  });
  
  // Check if AI services are available
  app.get("/api/ai/status", (_req, res) => {
    const isAvailable = isOpenAIAvailable();
    return res.json({ 
      available: isAvailable,
      message: isAvailable 
        ? "OpenAI services are available" 
        : "OpenAI services are not available - using fallback methods"
    });
  });

  // Create HTTP server
  const httpServer = createServer(app);
  
  return httpServer;
}
