import { z } from 'zod';
import { pgTable, serial, text, timestamp, integer, varchar } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';

// Achievement types
export const achievementTypes = [
  'pattern_discovery',
  'high_confidence',
  'key_found',
  'nonce_reconstructed',
  'multiple_patterns',
  'quick_analysis',
  'first_analysis',
  'master_analyst',
  'accuracy',
  'breakthrough',
  'innovator'
] as const;

// Achievement levels
export const achievementLevels = [
  'bronze',
  'silver',
  'gold',
  'platinum'
] as const;

// Define achievement schema
export const achievements = pgTable('achievements', {
  id: serial('id').primaryKey(),
  type: varchar('type', { length: 50 }).notNull().$type<typeof achievementTypes[number]>(),
  userId: integer('user_id').notNull(),
  label: varchar('label', { length: 100 }).notNull(),
  description: text('description').notNull(),
  level: varchar('level', { length: 20 }).notNull().$type<typeof achievementLevels[number]>(),
  metadata: text('metadata'), // JSON string with additional data
  achievedAt: timestamp('achieved_at').defaultNow().notNull(),
});

// Insert schema for achievements
export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
});

// Achievement type definitions
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

// Achievement triggers based on analysis milestones
export const achievementTriggers = {
  // Pattern Discovery Achievements
  PATTERN_DISCOVERY_FIRST: {
    type: 'pattern_discovery' as const,
    label: 'Pattern Hunter',
    description: 'Discovered your first cryptographic pattern',
    level: 'bronze' as const,
    threshold: 1,
  },
  PATTERN_DISCOVERY_ADVANCED: {
    type: 'pattern_discovery' as const,
    label: 'Pattern Master',
    description: 'Discovered 10+ cryptographic patterns',
    level: 'silver' as const,
    threshold: 10,
  },
  PATTERN_DISCOVERY_EXPERT: {
    type: 'pattern_discovery' as const,
    label: 'Pattern Virtuoso',
    description: 'Discovered 25+ cryptographic patterns with high confidence',
    level: 'gold' as const,
    threshold: 25,
  },
  
  // High Confidence Achievements
  HIGH_CONFIDENCE_PATTERN: {
    type: 'high_confidence' as const,
    label: 'Precision Analyst',
    description: 'Discovered a pattern with 90%+ confidence',
    level: 'silver' as const,
    threshold: 90,
  },
  PERFECT_CONFIDENCE: {
    type: 'high_confidence' as const,
    label: 'Flawless Analyst',
    description: 'Discovered a pattern with 100% confidence',
    level: 'gold' as const,
    threshold: 100,
  },
  
  // Key Recovery Achievements
  FIRST_KEY_FOUND: {
    type: 'key_found' as const,
    label: 'Key Finder',
    description: 'Recovered your first private key',
    level: 'gold' as const,
    threshold: 1,
  },
  MULTIPLE_KEYS: {
    type: 'key_found' as const,
    label: 'Master Key Hunter',
    description: 'Recovered 5+ private keys',
    level: 'platinum' as const,
    threshold: 5,
  },
  
  // Nonce Reconstruction
  FIRST_NONCE_RECONSTRUCTED: {
    type: 'nonce_reconstructed' as const,
    label: 'Nonce Detective',
    description: 'Successfully reconstructed your first nonce',
    level: 'silver' as const,
    threshold: 1,
  },
  NONCE_MASTER: {
    type: 'nonce_reconstructed' as const,
    label: 'Nonce Master',
    description: 'Successfully reconstructed 10+ nonces',
    level: 'gold' as const,
    threshold: 10,
  },
  
  // Multiple Patterns in Single Analysis
  PATTERN_CLUSTER: {
    type: 'multiple_patterns' as const,
    label: 'Pattern Cluster',
    description: 'Discovered 3+ patterns in a single analysis',
    level: 'silver' as const,
    threshold: 3,
  },
  PATTERN_NETWORK: {
    type: 'multiple_patterns' as const,
    label: 'Pattern Network',
    description: 'Discovered 5+ interconnected patterns',
    level: 'gold' as const,
    threshold: 5,
  },
  
  // Quick Analysis
  SPEED_ANALYST: {
    type: 'quick_analysis' as const,
    label: 'Speed Analyst',
    description: 'Completed analysis in under 10 seconds',
    level: 'bronze' as const,
    threshold: 10,
  },
  LIGHTNING_ANALYST: {
    type: 'quick_analysis' as const,
    label: 'Lightning Analyst',
    description: 'Completed analysis in under 5 seconds',
    level: 'silver' as const,
    threshold: 5,
  },
  
  // First Analysis
  FIRST_STEPS: {
    type: 'first_analysis' as const,
    label: 'First Steps',
    description: 'Completed your first cryptographic analysis',
    level: 'bronze' as const,
    threshold: 1,
  },
  
  // Master Analyst
  ANALYSIS_VETERAN: {
    type: 'master_analyst' as const,
    label: 'Analysis Veteran',
    description: 'Completed 25+ cryptographic analyses',
    level: 'silver' as const,
    threshold: 25,
  },
  CRYPTO_GRANDMASTER: {
    type: 'master_analyst' as const,
    label: 'Crypto Grandmaster',
    description: 'Completed 100+ analyses with multiple successful key recoveries',
    level: 'platinum' as const,
    threshold: 100,
  },
  
  // Accuracy
  PRECISION_SPECIALIST: {
    type: 'accuracy' as const,
    label: 'Precision Specialist',
    description: 'Maintained 80%+ accuracy in pattern validation',
    level: 'silver' as const,
    threshold: 80,
  },
  
  // Breakthrough
  CRYPTOGRAPHY_BREAKTHROUGH: {
    type: 'breakthrough' as const,
    label: 'Cryptography Breakthrough',
    description: 'Discovered a critical vulnerability pattern',
    level: 'platinum' as const,
    threshold: 1,
  },
  
  // Innovator
  PATTERN_INNOVATOR: {
    type: 'innovator' as const,
    label: 'Pattern Innovator',
    description: 'Identified a new type of nonce pattern',
    level: 'gold' as const,
    threshold: 1,
  },
};