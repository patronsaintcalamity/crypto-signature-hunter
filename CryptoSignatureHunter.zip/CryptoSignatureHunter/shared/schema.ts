/**
 * Shared Schema Module
 * 
 * Contains shared data types and schemas used by both client and server:
 * - Data model definitions
 * - API request/response types
 * - Common utility types
 */

import { z } from 'zod';

// Re-export Transaction type from fileParser for consistency across server and client
export type { Transaction } from '../server/fileParser';

// Analysis schema
export const analysisSchema = z.object({
  id: z.string(),
  name: z.string(),
  status: z.enum(['pending', 'running', 'completed', 'failed']),
  progress: z.number().min(0).max(100),
  speed: z.enum(['fast', 'balanced', 'thorough']).optional(),
  useAI: z.boolean().optional(),
  transactionCount: z.number(),
  keyCount: z.number(),
  startTime: z.number(),
  endTime: z.number().nullable(),
  results: z.any().nullable()
});

export type Analysis = z.infer<typeof analysisSchema>;

// Cluster schema
export const clusterSchema = z.object({
  id: z.string(),
  algorithm: z.string(),
  transactions: z.array(z.string()),
  addresses: z.array(z.string()),
  confidence: z.number(),
  patternDescription: z.string().optional(),
  similarityScore: z.number().optional(),
  metadata: z.record(z.string(), z.any()).optional(),
  analysisId: z.string().optional()
});

export type Cluster = z.infer<typeof clusterSchema>;

// Key schema
export const keySchema = z.object({
  id: z.string(),
  privateKey: z.string(),
  address: z.string(),
  confidence: z.number(),
  verified: z.boolean(),
  createdAt: z.number(),
  analysisId: z.string().optional()
});

export type Key = z.infer<typeof keySchema>;

// Pattern schema
export const patternSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  confidence: z.number(),
  transactions: z.array(z.string()),
  suggestedAction: z.string().optional()
});

export type Pattern = z.infer<typeof patternSchema>;

// API response schemas

// Analysis creation request
export const analysisCreateRequestSchema = z.object({
  name: z.string().optional(),
  speed: z.enum(['fast', 'balanced', 'thorough']).optional(),
  useAI: z.boolean().optional()
});

export type AnalysisCreateRequest = z.infer<typeof analysisCreateRequestSchema>;

// Analysis response
export const analysisResponseSchema = analysisSchema;

export type AnalysisResponse = z.infer<typeof analysisResponseSchema>;

// Transaction upload response
export const transactionUploadResponseSchema = z.object({
  success: z.boolean(),
  validCount: z.number(),
  error: z.string().optional()
});

export type TransactionUploadResponse = z.infer<typeof transactionUploadResponseSchema>;

// Key creation request
export const keyCreateRequestSchema = z.object({
  privateKey: z.string(),
  address: z.string(),
  confidence: z.number().optional(),
  analysisId: z.string().optional()
});

export type KeyCreateRequest = z.infer<typeof keyCreateRequestSchema>;

// Export data response
export const exportResponseSchema = z.object({
  analysis: analysisSchema,
  keys: z.array(keySchema),
  clusters: z.array(clusterSchema)
});

export type ExportResponse = z.infer<typeof exportResponseSchema>;